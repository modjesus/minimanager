"use strict";
/* ===========================================================================
   MiniManager v002
   One file once built. No framework, no network, no build step at runtime.

   Storage:
     localStorage  'mm.data'    records (small, synchronous, exportable)
     IndexedDB     'mm-photos'  photo and swatch blobs (large)
   =========================================================================== */

const APP_VERSION = 'v015';

/* --- helpers. Declared above everything that calls them: const does not
       hoist, so a helper below a renderer is a crash. --------------------- */
const $  = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c =>
  ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));

let toastTimer = null;
function toast(msg){
  const old = $('.toast'); if (old) old.remove();
  const el = document.createElement('div');
  el.className = 'toast'; el.setAttribute('role','status'); el.textContent = msg;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.remove('in');
    setTimeout(() => el.remove(), 320);
  }, 2600);
}

/* A promise that never settles cannot be caught. On iOS with iCloud Photos on
   "Optimise Storage" a picked photo's bytes are not on the device; a stalled
   fetch never returns and never rejects. Only a clock catches that. */
function deadline(promise, ms, label){
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(label + ' timed out after ' + (ms/1000) + 's')), ms);
    promise.then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
  });
}

/* --- the stored shape ----------------------------------------------------- */
const DEFAULT_STAGES = ['Unbuilt','Built','Primed','Basecoat','Shading','Highlights','Basing','Finished'];
/* UNDERCOAT_PRESETS lives in the presets block above. Anyone who installed an
   earlier version has only the first four, so load() tops theirs up rather
   than replacing it, which would orphan every swatch they have taken. */
const PAINT_TYPES = ['Base','Layer','Wash','Contrast','Shade','Ink','Metallic','Dry','Technical','Primer'];
const STOCK = ['Have it','Running low','Out','Wishlist'];

const BLANK = {
  v:3, systems:[], factions:[], minis:[], stages:DEFAULT_STAGES.slice(),
  paints:[], undercoats:UNDERCOAT_PRESETS.slice(), swatches:[],
  recipes:[], links:[], supplies:[], wishlist:[],
  settings:{ theme:'', currency:'GBP' }
};

let data = BLANK;

function arr(v){ return Array.isArray(v) ? v : []; }

/* Top up a saved undercoat list with any preset it has not seen, keeping the
   person's own entries and their ids untouched. Replacing the list outright
   would leave every existing swatch pointing at an undercoat that no longer
   exists, and the comparison screen is the whole point of this app. */
function mergeUndercoats(saved){
  if (!saved.length) return UNDERCOAT_PRESETS.slice();
  const have = {};
  saved.forEach(u => { if (u && u.id) have[u.id] = true; });
  const out = saved.slice();
  UNDERCOAT_PRESETS.forEach(p => { if (!have[p.id]) out.push(p); });
  /* The first four shipped without colours. Fill them in without touching
     anything the person may have edited. */
  out.forEach(u => {
    if (u && !u.hex){
      const p = UNDERCOAT_PRESETS.find(x => x.id === u.id);
      if (p && p.hex) u.hex = p.hex;
      if (p && !u.brand) u.brand = p.brand;
    }
  });
  return out;
}

function load(){
  let raw = null;
  try { raw = localStorage.getItem('mm.data'); } catch (e) { raw = null; }
  if (!raw){ data = structuredClone(BLANK); return; }
  let p = null;
  try { p = JSON.parse(raw); } catch (e) { p = null; }
  if (!p || typeof p !== 'object'){
    toast('Saved data could not be read. Starting fresh.');
    data = structuredClone(BLANK); return;
  }
  /* Array.isArray on every list, never a truthy or .length check: a string has
     .length, so a corrupted systems:"x" would walk past a loose guard and then
     blank the app on first render. */
  const st = (p.settings && typeof p.settings === 'object') ? p.settings : {};
  data = {
    v:3,
    systems:arr(p.systems), factions:arr(p.factions), minis:arr(p.minis),
    stages: arr(p.stages).length ? p.stages : DEFAULT_STAGES.slice(),
    paints:arr(p.paints),
    undercoats: mergeUndercoats(arr(p.undercoats)),
    swatches:arr(p.swatches), recipes:arr(p.recipes),
    /* Links made before v010 had no id, and the sync only carries records
       that have one, so they never left the device. Give them one now. */
    links:arr(p.links).map(l => l && !l.id ? Object.assign({ id:uid() }, l) : l),
    /* New in v3. Anyone upgrading has neither, so they default to empty
       rather than undefined — every list in this app must be an array by
       the time anything reads it. */
    supplies:arr(p.supplies),
    wishlist:arr(p.wishlist),
    settings:{
      theme: typeof st.theme === 'string' ? st.theme : '',
      /* Pounds unless told otherwise; changeable in Your account. */
      currency: CURRENCIES.some(c => c[0] === st.currency) ? st.currency : 'GBP'
    }
  };
  /* Entries already at Finished from before v015 may count fewer models
     done than they hold; finished means all of them. */
  const last = data.stages[data.stages.length - 1];
  data.minis.forEach(m => {
    if (m && m.stage === last && (Number(m.done)||0) < (Number(m.total)||1)){ m.done = Number(m.total)||1; m.updated = Date.now(); }
  });
}

/* Write to this device only. Used by the sync code when folding changes
   down from the account, where pushing them straight back up would be a
   loop. Everything else calls save(). */
function saveLocalOnly(){
  try { localStorage.setItem('mm.data', JSON.stringify(data)); }
  catch (e) { toast('Could not save. Your device storage may be full.'); }
}

function save(){
  saveLocalOnly();
  if (typeof schedulePush === 'function') schedulePush();
}

/* --- money ----------------------------------------------------------------
   Intl does the work. Hardcoding a symbol in front of the number would be
   wrong for most currencies: kr goes after, yen has no decimals, and the
   thousands separator differs. */
let moneyFmt = null, moneyFmtFor = null;
function money(n){
  const code = (data.settings && data.settings.currency) || 'GBP';
  if (moneyFmtFor !== code){
    try {
      moneyFmt = new Intl.NumberFormat(undefined,
        { style:'currency', currency:code, maximumFractionDigits:2 });
    } catch (e) {
      moneyFmt = null;      /* unknown code: fall back rather than throw */
    }
    moneyFmtFor = code;
  }
  const v = Number(n) || 0;
  if (!moneyFmt) return code + ' ' + v.toFixed(2);
  /* Whole amounts read better without .00 on a small screen. */
  return Number.isInteger(v)
    ? moneyFmt.format(v).replace(/[.,]00(?!\d)/, '')
    : moneyFmt.format(v);
}
function currencyName(code){
  const hit = CURRENCIES.find(c => c[0] === code);
  return hit ? hit[1] : code;
}

/* --- how long something has been waiting ---------------------------------- */
function monthsSince(iso){
  if (!iso) return null;
  const then = new Date(iso + 'T00:00:00');
  if (isNaN(then)) return null;
  const now = new Date();
  let m = (now.getFullYear() - then.getFullYear()) * 12 + (now.getMonth() - then.getMonth());
  if (now.getDate() < then.getDate()) m--;
  return m < 0 ? 0 : m;
}
function waitedFor(iso){
  const m = monthsSince(iso);
  if (m === null) return '';
  if (m < 1) return 'this month';
  if (m < 12) return m + ' mo';
  const y = Math.floor(m / 12), r = m % 12;
  return y + ' yr' + (r ? ' ' + r + ' mo' : '');
}
function waitingSince(iso){
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d)) return '';
  return d.toLocaleDateString(undefined, { month:'long', year:'numeric' });
}

/* A model counts as unfinished until every one of its models is done. */
function isFinished(m){
  return m.stage === data.stages[data.stages.length - 1];
}
function collectionValue(){
  let unpainted = 0, finished = 0, priced = 0;
  arr(data.minis).forEach(m => {
    const p = Number(m.price);
    if (!p) return;
    priced++;
    if (isFinished(m)) finished += p; else unpainted += p;
  });
  const total = unpainted + finished;
  return { unpainted, finished, priced, total,
           pct: total ? Math.round((finished / total) * 100) : 0,
           missing: arr(data.minis).length - priced };
}

/* --- photos: IndexedDB ---------------------------------------------------- */
let idb = null;
function openDB(){
  if (idb) return Promise.resolve(idb);
  return deadline(new Promise((resolve, reject) => {
    const req = indexedDB.open('mm-photos', 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains('photos'))
        req.result.createObjectStore('photos', { keyPath:'id' });
    };
    req.onsuccess = () => { idb = req.result; resolve(idb); };
    req.onerror   = () => reject(req.error || new Error('Photo storage refused to open'));
    req.onblocked = () => reject(new Error('Photo storage is blocked by another tab'));
  }), 15000, 'Opening photo storage');
}
/* IndexedDB settles FOUR ways: complete, error, abort, blocked. WebKit aborts
   a transaction on suspend/resume, which is what opening the picker does. */
function tx(mode, fn){
  return openDB().then(db => deadline(new Promise((resolve, reject) => {
    const t = db.transaction('photos', mode), store = t.objectStore('photos');
    let out;
    t.oncomplete = () => resolve(out);
    t.onerror    = () => reject(t.error || new Error('Photo storage error'));
    t.onabort    = () => reject(t.error || new Error('Photo storage was interrupted'));
    const r = fn(store);
    if (r) r.onsuccess = () => { out = r.result; };
  }), 15000, 'Photo storage'));
}
const putPhoto = (id, blob) => tx('readwrite', s => s.put({ id, blob }));
const getPhoto = id        => tx('readonly',  s => s.get(id));
const delPhoto = id        => tx('readwrite', s => s.delete(id));
/* Deleting a photo the person chose to delete: from this phone, and from
   their account too (queued if offline). Not used by sign-out or by
   clearing the device, which must leave the account's copy alone. */
const forgetPhoto = id => {
  if (typeof queueCloudDelete === 'function') queueCloudDelete(id);
  return delPhoto(id);
};
/* Used only by "delete my account", where everything must really go. */
const clearPhotos = ()     => tx('readwrite', s => s.clear());

/* --- catalogue ------------------------------------------------------------ */
let CAT = null;
function catalogue(){
  if (CAT) return CAT;
  const el = document.getElementById('catalogue');
  let pack = null;
  try { pack = JSON.parse(el.textContent); } catch (e) { pack = null; }
  if (!pack){ CAT = { rows:[], brands:[], ranges:[] }; return CAT; }
  const rows = pack.p.split('\n').map(line => {
    const f = line.split('|');
    return { b:pack.b[+f[0]], rg:pack.r[+f[1]], n:f[2], c:f[3], hex:'#'+f[4] };
  });
  CAT = { rows, brands:pack.b, ranges:pack.r };
  return CAT;
}

/* --- colour maths --------------------------------------------------------- */
function hexRgb(h){
  h = String(h||'').replace('#','');
  if (h.length === 3) h = h.split('').map(c => c+c).join('');
  const n = parseInt(h, 16);
  return isNaN(n) ? [0,0,0] : [(n>>16)&255, (n>>8)&255, n&255];
}
const rgbHex = (r,g,b) => '#' + [r,g,b].map(v =>
  Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2,'0')).join('').toUpperCase();

function rgbLab(r,g,b){
  const f = v => { v/=255; return v>0.04045 ? Math.pow((v+0.055)/1.055,2.4) : v/12.92; };
  r=f(r); g=f(g); b=f(b);
  let x=(r*0.4124+g*0.3576+b*0.1805)/0.95047,
      y=(r*0.2126+g*0.7152+b*0.0722),
      z=(r*0.0193+g*0.1192+b*0.9505)/1.08883;
  const k = v => v>0.008856 ? Math.cbrt(v) : (7.787*v)+16/116;
  x=k(x); y=k(y); z=k(z);
  return [116*y-16, 500*(x-y), 200*(y-z)];
}
const hexLab = h => { const [r,g,b] = hexRgb(h); return rgbLab(r,g,b); };

/* CIEDE2000. The simpler Euclidean distance in Lab ranks obviously-wrong
   paints above obviously-right ones in the yellows and the blues, which is
   exactly where miniature palettes live. */
function deltaE(l1, l2){
  const [L1,a1,b1] = l1, [L2,a2,b2] = l2;
  const avgL = (L1+L2)/2;
  const C1 = Math.hypot(a1,b1), C2 = Math.hypot(a2,b2), avgC = (C1+C2)/2;
  const G = 0.5*(1 - Math.sqrt(Math.pow(avgC,7)/(Math.pow(avgC,7)+Math.pow(25,7))));
  const a1p = a1*(1+G), a2p = a2*(1+G);
  const C1p = Math.hypot(a1p,b1), C2p = Math.hypot(a2p,b2), avgCp = (C1p+C2p)/2;
  const h = (x,y) => { if (x===0 && y===0) return 0; let d = Math.atan2(y,x)*180/Math.PI; return d<0 ? d+360 : d; };
  const h1p = h(a1p,b1), h2p = h(a2p,b2);
  let dhp = h2p-h1p;
  if (C1p*C2p === 0) dhp = 0;
  else if (dhp > 180) dhp -= 360; else if (dhp < -180) dhp += 360;
  const dLp = L2-L1, dCp = C2p-C1p;
  const dHp = 2*Math.sqrt(C1p*C2p)*Math.sin(dhp*Math.PI/360);
  let avghp;
  if (C1p*C2p === 0) avghp = h1p+h2p;
  else if (Math.abs(h1p-h2p) <= 180) avghp = (h1p+h2p)/2;
  else avghp = (h1p+h2p+ (h1p+h2p < 360 ? 360 : -360))/2;
  const T = 1 - 0.17*Math.cos((avghp-30)*Math.PI/180) + 0.24*Math.cos(2*avghp*Math.PI/180)
              + 0.32*Math.cos((3*avghp+6)*Math.PI/180) - 0.20*Math.cos((4*avghp-63)*Math.PI/180);
  const Sl = 1 + (0.015*Math.pow(avgL-50,2))/Math.sqrt(20+Math.pow(avgL-50,2));
  const Sc = 1 + 0.045*avgCp, Sh = 1 + 0.015*avgCp*T;
  const Rt = -2*Math.sqrt(Math.pow(avgCp,7)/(Math.pow(avgCp,7)+Math.pow(25,7)))
              * Math.sin(60*Math.exp(-Math.pow((avghp-275)/25,2))*Math.PI/180);
  return Math.sqrt(Math.pow(dLp/Sl,2)+Math.pow(dCp/Sc,2)+Math.pow(dHp/Sh,2)+Rt*(dCp/Sc)*(dHp/Sh));
}

function rgbHsl(r,g,b){
  r/=255; g/=255; b/=255;
  const mx = Math.max(r,g,b), mn = Math.min(r,g,b), d = mx-mn;
  let hh = 0;
  if (d){ hh = mx===r ? ((g-b)/d)%6 : mx===g ? (b-r)/d+2 : (r-g)/d+4; hh*=60; if (hh<0) hh+=360; }
  const l = (mx+mn)/2;
  const s = d === 0 ? 0 : d/(1-Math.abs(2*l-1));
  return [hh, s, l];
}
function hslRgb(h,s,l){
  h=((h%360)+360)%360;
  const c=(1-Math.abs(2*l-1))*s, x=c*(1-Math.abs((h/60)%2-1)), m=l-c/2;
  let r,g,b;
  if (h<60)      [r,g,b]=[c,x,0];
  else if (h<120)[r,g,b]=[x,c,0];
  else if (h<180)[r,g,b]=[0,c,x];
  else if (h<240)[r,g,b]=[0,x,c];
  else if (h<300)[r,g,b]=[x,0,c];
  else           [r,g,b]=[c,0,x];
  return [(r+m)*255,(g+m)*255,(b+m)*255];
}

const HARMONIES = {
  complementary:      { label:'Complementary',       note:'Opposites intensify each other. Rim lights, gems, spot accents.' },
  split:              { label:'Split-complementary', note:'The tension of a complement with somewhere softer to land.' },
  triadic:            { label:'Triadic',             note:'Three-way balance. Strong on banners, cloaks and shields.' },
  analogous:          { label:'Analogous',           note:'Neighbours on the wheel. Calm, cohesive, easy to blend.' },
  tetradic:           { label:'Tetradic',            note:'Two complementary pairs. Needs one colour to dominate.' },
  monochromatic:      { label:'Monochromatic',       note:'One hue through its range. Reads as disciplined, never busy.' }
};

function scheme(kind, hex){
  const [r,g,b] = hexRgb(hex);
  const [h,s,l] = rgbHsl(r,g,b);
  const mk = (hh, ss, ll, role) => ({ hex: rgbHex(...hslRgb(hh, ss===undefined?s:ss, ll===undefined?l:ll)), role });
  const base = { hex: hex.toUpperCase(), role:'Base' };
  if (kind === 'complementary') return [base, mk(h+180,undefined,undefined,'Complement'),
    mk(h, Math.max(0,s-.25), Math.min(.92,l+.22), 'Highlight'), mk(h, s, Math.max(.08,l-.22), 'Shadow')];
  if (kind === 'split') return [base, mk(h+150,undefined,undefined,'Split one'),
    mk(h+210,undefined,undefined,'Split two'), mk(h, s, Math.max(.08,l-.2), 'Shadow')];
  if (kind === 'triadic') return [base, mk(h+120,undefined,undefined,'Second'),
    mk(h+240,undefined,undefined,'Third'), mk(h, Math.max(0,s-.2), Math.min(.92,l+.2), 'Highlight')];
  if (kind === 'analogous') return [base, mk(h-30,undefined,undefined,'Cooler side'),
    mk(h+30,undefined,undefined,'Warmer side'), mk(h, s, Math.max(.08,l-.2), 'Shadow')];
  if (kind === 'tetradic') return [base, mk(h+90,undefined,undefined,'Second'),
    mk(h+180,undefined,undefined,'Complement'), mk(h+270,undefined,undefined,'Fourth')];
  return [base, mk(h, s, Math.min(.94,l+.26), 'Highlight'), mk(h, s, Math.min(.98,l+.42), 'Extreme light'),
          mk(h, s, Math.max(.06,l-.24), 'Shadow')];
}

/* Nearest paint in the catalogue. A coarse Euclidean pass narrows 9,693 rows
   to 150 before the expensive perceptual comparison runs. */
let CATLAB = null;
function nearestPaint(hex){
  const cat = catalogue();
  if (!cat.rows.length) return null;
  if (!CATLAB) CATLAB = cat.rows.map(p => hexLab(p.hex));
  const t = hexLab(hex);
  const rough = [];
  for (let i = 0; i < cat.rows.length; i++){
    const L = CATLAB[i];
    const d = (L[0]-t[0])**2 + (L[1]-t[1])**2 + (L[2]-t[2])**2;
    rough.push([d, i]);
  }
  rough.sort((a,b) => a[0]-b[0]);
  let best = null, bestD = Infinity;
  for (let k = 0; k < Math.min(150, rough.length); k++){
    const i = rough[k][1], d = deltaE(t, CATLAB[i]);
    if (d < bestD){ bestD = d; best = cat.rows[i]; }
  }
  return { paint: best, de: bestD };
}

/* --- derived -------------------------------------------------------------- */
const sysName = id => (data.systems.find(s => s.id === id) || {}).name || '';
const facName = id => (data.factions.find(f => f.id === id) || {}).name || '';
const ucName  = id => (data.undercoats.find(u => u.id === id) || {}).name || '';
const paintOf = id => data.paints.find(p => p.id === id);
const stageIx = m => { const i = data.stages.indexOf(m.stage); return i < 0 ? 0 : i; };
const isDone  = m => m.stage === data.stages[data.stages.length - 1];

function counts(){
  const total = data.minis.reduce((n,m) => n + (Number(m.total)||1), 0);
  const done  = data.minis.reduce((n,m) => n + (Number(m.done)||0), 0);
  const started = data.minis.filter(m => stageIx(m) > 0 && !isDone(m)).length;
  const backlog = data.minis.filter(m => stageIx(m) === 0).length;
  return { total, done, started, backlog, entries:data.minis.length,
           paints:data.paints.length, swatches:data.swatches.length, recipes:data.recipes.length };
}

/* --- state ---------------------------------------------------------------- */
const state = {
  tab:'home', openMini:null, openPaint:null, openRecipe:null,
  sub:null, openGame:null, q:'', fSys:'', fFac:'', fStage:'', sheet:'',
  /* Armies. openArmy is a "system|faction" key rather than an id, because an
     army is the pair. aStage is kept apart from fStage so that filtering
     inside an army does not silently leave the whole collection filtered
     when you come back out of it. */
  openArmy:null, aStage:'',
  /* Getting started. step 0 means it is not running. */
  setup:{ step:0, only:'', sysPick:[], sysName:'', facName:'', units:[],
          brand:'', range:'', pq:'', picked:{}, added:null },
  pq:'', pStock:'', planner:{ paintId:null, kind:'complementary' },
  cmp:{ mode:'paint', paintId:null, ucId:null }, pending:null,
  /* Deliberately not persisted: the collection value starts hidden on every
     launch, so opening the app never confronts you with it. */
  showValue:false,
  sort:'', shopTab:'need',
  /* Ticked-in-the-shop is session state, never saved. It means "crossed off
     for this trip", which is not the same as "back in the cupboard". */
  ticked:{},
  pick:{ kind:'build', opts:{}, result:null, last:null }
};

function applyTheme(){
  const t = data.settings.theme || '';
  if (t) document.documentElement.setAttribute('data-theme', t);
  else document.documentElement.removeAttribute('data-theme');
}

/* ===========================================================================
   Shared bits
   =========================================================================== */

/* The logo's own drop, lifted straight out of the mark in the page header so
   the two can never drift apart. Used as the progress vessel and as the paint
   swatch. Its box inside the 300x380 artboard is x 119-181, y 86-196. */
const DROP = 'M 150 86 C 144 104 133 124 126 144 C 119 162 121 174 128 183 C 139 198 161 198 172 183 C 179 174 181 162 174 144 C 167 124 156 104 150 86 Z';
const DROP_TOP = 86, DROP_BOT = 196, DROP_H = DROP_BOT - DROP_TOP;
/* The four-point sparkle above the mark. Reserved for finished, and used
   nowhere else, so that it keeps meaning something. */
const SPARKLE = 'M 150 16 C 154 34 160 39 178 43 C 160 47 154 52 150 70 C 146 52 140 47 122 43 C 140 39 146 34 150 16 Z';

/* A small drop, filled or hollow. Decorative: every one of these sits beside
   a word that says the same thing. */
function dropSvg(cls, fill){
  return `<svg class="${cls}" viewBox="112 76 78 130" aria-hidden="true"><path d="${DROP}"
    ${fill ? `fill="${fill}"` : 'fill="none" stroke="var(--warm-grey)" stroke-width="9"'}
    stroke-linejoin="round"/></svg>`;
}

/* The pot. The level is a rectangle clipped to the drop and pushed down out of
   sight; at p=0 it sits on the bottom lip, at p=1 it covers the whole shape.

   The clip needs an id, and the armies screen puts a dozen pots on one page,
   so the id is counted rather than fixed — duplicate ids would be invalid and
   would come back to bite the first time two pots needed different shapes. */
let potSeq = 0;
function potSvg(p, cls){
  const y = (DROP_BOT - 80 - DROP_H * p).toFixed(1);
  const id = 'potclip' + (++potSeq);
  return `<svg class="${cls || 'pot'}" viewBox="112 76 78 130" aria-hidden="true">
    <defs><clipPath id="${id}"><path d="${DROP}"/></clipPath></defs>
    <g clip-path="url(#${id})">
      <rect class="potfill" x="112" y="80" width="78" height="122" fill="var(--success)"
        style="transform:translateY(${y}px)"/>
    </g>
    <path d="${DROP}" fill="none" stroke="var(--gold)" stroke-width="7" stroke-linejoin="round"/>
  </svg>`;
}
function potWord(p){
  if (p <= 0)  return 'not started';
  if (p < .3)  return 'just begun';
  if (p < .45) return 'getting there';
  if (p < .6)  return 'half way';
  return 'nearly there';
}
const backBtn = (to,label) => `<button class="btn ghost sm" data-back="${to}" style="margin:.875rem 0">&larr; ${esc(label)}</button>`;

function photoImg(id, cls){
  return `<img class="${cls||''}" data-photo="${esc(id)}" alt="">`;
}

function hydratePhotos(){
  $$('[data-photo]').forEach(img => {
    const id = img.dataset.photo;
    if (urlCache.has(id)){ img.src = urlCache.get(id); img.classList.add('in'); return; }
    getPhoto(id).then(rec => {
      if (rec && rec.blob) return rec.blob;
      /* Not on this device. If it was taken on another one, fetch it now.
         Photos are pulled when they are wanted on screen rather than all
         at once, because a full collection could be hundreds of megabytes
         over somebody's mobile data. */
      if (typeof pullPhoto === 'function') return pullPhoto(id);
      return null;
    }).then(blob => {
      if (!blob){ img.alt = 'Photo missing'; img.classList.add('in'); return; }
      const u = URL.createObjectURL(blob);
      urlCache.set(id, u); img.src = u;
      img.addEventListener('load', () => img.classList.add('in'), { once:true });
    }).catch(err => { img.alt = 'Photo could not be loaded'; img.classList.add('in');
                      console.warn('photo', id, err.message); });
  });
}
const urlCache = new Map();

/* ===========================================================================
   Home
   =========================================================================== */
function screenHome(){
  const c = counts();
  /* What is on the bench, by army. Started and not finished, most recently
     touched first; each army gets its own heading so Death Guard never
     shares a row with Tyranids. Three armies, four models each, at most. */
  const started = data.minis.filter(m => stageIx(m) > 0 && !isDone(m))
    .sort((a,b) => (b.updated||0)-(a.updated||0));
  const benchGroups = new Map();
  started.forEach(m => { const k = armyKey(m); if (!benchGroups.has(k)) benchGroups.set(k, []); benchGroups.get(k).push(m); });
  let h = `<p class="muted small" style="margin:.875rem 0 .375rem">${greeting()}</p>`;
  if (c.entries === 0){
    return h + `<h2 class="display" style="font-size:1.625rem;margin-bottom:.875rem">Your collection</h2>
      <div class="empty"><p>Nothing in here yet. Add your first miniature and the numbers start filling in.</p>
      <div class="row wrapm" style="justify-content:center">
        <button class="btn" data-act="addMini">Add a miniature</button>
        <button class="btn ghost" data-act="addSys">Add a game system</button></div></div>`;
  }
  /* What you were painting comes first: that is why the app gets opened.
     The totals follow it, so they read as progress rather than a scoreboard. */
  if (benchGroups.size){
    h += `<div class="ehead" style="margin-top:0"><h2>Continue painting</h2></div>`;
    [...benchGroups.entries()].slice(0,3).forEach(([k, ms]) => {
      const g = { sys:ms[0].sys||'', fac:ms[0].fac||'' };
      h += `<button class="crumb" data-openarmy="${esc(k)}">${esc(armyLabel(g))} <span>&middot; ${esc(gameLabel(g.sys))}</span> <span aria-hidden="true">&rsaquo;</span></button>
        <div class="grid">`;
      ms.slice(0,4).forEach(m => { h += tile(m); });
      h += `</div>`;
    });
    if (benchGroups.size > 3)
      h += `<p class="small muted">And ${benchGroups.size - 3} more ${benchGroups.size - 3 === 1 ? 'army' : 'armies'} with something on the bench, in Collection.</p>`;
  }

  /* One hero number, then a ruled line. What matters on opening this app is
     how much you have actually finished — not four equally-weighted totals in
     four identical boxes, which gives the eye nowhere to land. */
  h += `<div class="ehead"${benchGroups.size ? '' : ' style="margin-top:0"'}><div class="eb">Your collection</div></div>
    <div class="hero"><b>${c.done}</b><span>finished<br>of ${c.total}</span></div>
    <hr class="keyline">
    <div class="ledger">
      <div class="lcell"><b>${c.started}</b><span>On the bench</span></div>
      <div class="lcell"><b>${c.backlog}</b><span>Still waiting</span></div>
      <div class="lcell"><b>${c.paints}</b><span>Paints owned</span></div>
    </div>`;
  h += valuePanel();

  h += `<div class="ehead"><h2>Quick actions</h2></div><div class="row wrapm">
    <button class="btn" data-act="addMini">Add a miniature</button>
    <button class="btn ghost" data-act="pick">Pick something for me</button></div>`;
  return h;
}

/* What the collection is worth.

   Hidden until asked for, every time. Nobody should open this app and be met
   with a number about their own money. It is shown beside what has been
   FINISHED so it reads as progress rather than debt, and it does not count up
   or animate — a figure like this arriving with a flourish is a fruit machine. */
function valuePanel(){
  const v = collectionValue();
  if (!v.priced) return '';
  if (!state.showValue){
    return `<div class="valueline">
      <span class="small muted">Collection value</span>
      <button class="linkbtn" data-act="showValue">Show</button></div>`;
  }
  return `<div class="valueline">
      <span class="small muted">Collection value</span>
      <button class="linkbtn" data-act="hideValue">Hide</button></div>
    <div class="vgrid">
      <div class="vcell"><b class="num">${esc(money(v.unpainted))}</b><span>waiting to be painted</span></div>
      <div class="vcell done"><b class="num">${esc(money(v.finished))}</b><span>painted and finished</span></div>
    </div>
    <div class="valbar"><i style="width:${v.pct}%"></i></div>
    <p class="barlab">${v.pct}% of what you&rsquo;ve spent is finished and on the shelf.</p>
    ${v.missing ? `<p class="small muted" style="margin:.5rem 0 0">Based on the
      <span class="num">${v.priced}</span> of your <span class="num">${v.priced + v.missing}</span>
      entries that have a price. The rest aren&rsquo;t counted.</p>` : ''}`;
}
function greeting(){
  const hr = new Date().getHours();
  return hr < 12 ? 'Good morning.' : hr < 18 ? 'Good afternoon.' : 'Good evening.';
}
/* When a sort is active, show the thing being sorted on. Sorting a list by
   something invisible leaves people unable to tell whether it worked. */
function sortNote(m){
  if (state.sort === 'waiting'){
    if (!m.acquired) return `<span class="small muted">no date recorded</span>`;
    return `<span class="small muted">${isFinished(m) ? 'owned' : 'waiting'}
      <span class="num">${esc(waitedFor(m.acquired))}</span></span>`;
  }
  if (state.sort === 'value' && m.price != null && m.price !== '')
    return `<span class="small muted num">${esc(money(m.price))}</span>`;
  return '';
}

function tile(m){
  const pid = arr(m.photos)[0];
  const img = pid ? photoImg(pid,'ph')
    : `<div class="ph empty" aria-hidden="true">${dropSvg('phdrop','')}<span>no photo yet</span></div>`;
  const n = Number(m.total)||1, d = Number(m.done)||0;
  /* The system and faction used to be a third line here. Over a photograph
     that is too many words, and both are on the entry's own screen anyway. */
  const mark = isFinished(m)
    ? `<svg class="mk" width="19" height="19" viewBox="120 12 60 62" aria-hidden="true"><path d="${SPARKLE}" fill="var(--gold)"/></svg>`
    : stageIx(m) > 0
    ? `<svg class="mk" width="15" height="27" viewBox="112 76 78 130" aria-hidden="true"><path d="${DROP}" fill="var(--gold)"/></svg>`
    : '';
  return `<button class="tile${pid?'':' nophoto'}" data-open="${esc(m.id)}">${img}${mark}
    <span class="meta"><b class="user-text">${esc(m.name)}</b>
    <span class="small muted">${esc(m.stage)}${n>1?` &middot; <span class="num">${d} of ${n}</span>`:''}</span>
    ${sortNote(m)}
    </span></button>`;
}

/* ===========================================================================
   Getting started

   Three steps, every one skippable in a single tap, and skipping leaves
   nothing half-finished behind. It appears by itself the first time you open
   a genuinely empty collection and never asks again; after that it lives in
   the ... menu.

   The third step is the reason this exists. A paint is otherwise added one
   at a time, from a dialog, out of a catalogue of 9,693 — so recording the
   forty pots on a desk means opening that dialog forty times. Step three
   adds a whole rack at once, and the same picker is offered on the Paints
   screen as "Add several", because that is the part worth having again.
   =========================================================================== */
function startSetup(only){
  state.setup = { step: only === 'paints' ? 3 : 1, only: only || '',
                  sysPick: arr(data.systems).map(s => s.name),
                  sysName:'', facName:'', units:[],
                  brand:'', range:'', pq:'', picked:{}, added:null };
  state.openMini = null; state.openArmy = null;
  render(); window.scrollTo(0,0);
}

/* Offered once, and only when there is genuinely nothing here.

   It waits for firstPullDone, not for status 'ok'. 'ok' is set by whichever
   collection answers first, so on a second phone this would otherwise fire
   while the real collection was still arriving — and offer to set up a
   collection that already has three hundred models in it. */
let setupChecked = false;
function maybeStartSetup(){
  if (setupChecked || state.setup.step) return;
  if (!syncState.firstPullDone) return;
  setupChecked = true;
  if (data.settings.setupDone) return;
  if (data.minis.length || data.paints.length){
    data.settings.setupDone = true; save(); return;
  }
  startSetup();
}

function endSetup(go){
  /* Using the paint picker on its own is not "I have done the setup", so it
     must not quietly suppress the first-run offer. */
  const paintsOnly = state.setup.only === 'paints';
  state.setup = { step:0, only:'', sysPick:[], sysName:'', facName:'', units:[],
                  brand:'', range:'', pq:'', picked:{}, added:null };
  if (!paintsOnly) data.settings.setupDone = true;
  save();
  if (go) state.tab = go;
  render(); window.scrollTo(0,0);
}

/* Step 1 creates any system that was ticked and does not exist yet. Nothing
   is ever removed: unticking a system you already had would be a destructive
   act buried inside a setup flow, and the models filed under it would be
   orphaned. Untick here only means "don't add it". */
function commitSystems(){
  const have = arr(data.systems).map(s => s.name);
  state.setup.sysPick.forEach(n => { if (have.indexOf(n) === -1) systemIdByName(n); });
  save();
}

/* The two selects are rebuilt on every render, so whatever is showing has to
   be read back into state before anything re-renders. */
function captureArmyFields(){
  const s = state.setup;
  const sy = $('#suSys'); if (sy) s.sysName = sy.value;
  const fa = $('#suFac');
  if (fa) s.facName = fa.value === '__own'
    ? (($('#suFacOwn') && $('#suFacOwn').value.trim()) || '')
    : fa.value;
}

function setupAddUnit(quiet){
  const s = state.setup;
  captureArmyFields();
  const el = $('#suUnit'); if (!el) return;
  const name = el.value.trim();
  if (!name){ if (!quiet) toast('Type a name first.'); return; }
  const cEl = $('#suCount');
  s.units.push({ name, total: Math.max(1, Number(cEl ? cEl.value : 1) || 1) });
  el.value = ''; if (cEl) cEl.value = '1';
  if (quiet) return;
  render();
  const f = $('#suUnit'); if (f) f.focus();
}

/* Everything the flow collected, written at once. Running setup a second
   time must not duplicate a pot you already have, so paints are matched on
   name, brand and range before being added. */
function commitSetup(){
  const s = state.setup;
  const cat = catalogue();
  let paints = 0, minis = 0, models = 0;

  Object.keys(s.picked).forEach(k => {
    if (!s.picked[k]) return;
    const r = cat.rows[+k]; if (!r) return;
    if (arr(data.paints).some(p => p.name === r.n && p.brand === r.b && p.range === r.rg)) return;
    data.paints.push({ id:uid(), name:r.n, brand:r.b, range:r.rg, code:r.c, hex:r.hex,
      type:'', stock:'Have it', notes:'', created:Date.now(), updated:Date.now() });
    paints++;
  });

  if (s.units.length){
    const sysId = s.sysName ? systemIdByName(s.sysName) : '';
    const facId = s.facName ? factionIdByName(s.facName, sysId) : '';
    s.units.forEach(u => {
      data.minis.push({ id:uid(), name:u.name, sys:sysId, fac:facId,
        base:'', unit:'', total:u.total, price:null, acquired:'',
        done:0, stage:data.stages[0], tags:'', notes:'', photos:[],
        created:Date.now(), updated:Date.now() });
      minis++; models += u.total;
    });
    if (s.sysName || s.facName) setLastUsed({ sys:s.sysName, fac:s.facName });
  }

  s.added = { minis, models, paints, army:s.facName,
    key: s.units.length && s.sysName ? systemIdByName(s.sysName) + '|' + (s.facName ? factionIdByName(s.facName, systemIdByName(s.sysName)) : '') : '' };
  if (s.only !== 'paints') data.settings.setupDone = true;
  save();
}

/* The step marker, with the way out on the same row. The exit has to be at
   the top: step three is a list of sixty paints, and an exit below it is an
   exit you cannot see. */
function setupBar(n){
  let h = `<div class="setupbar">`;
  for (let i = 1; i <= 3; i++)
    h += potSvg(i <= n ? 1 : 0, 'sdrop' + (i === n ? ' now' : ''));
  h += `<span class="stepcap">${n} of 3</span>
    <button class="btn ghost sm" data-act="setupSkip"
      style="margin-left:auto">Skip setup</button></div>`;
  return h;
}
/* Paints-only has no steps to show, but still needs the same way out. */
function setupCloseBar(){
  return `<div class="setupbar"><button class="btn ghost sm" data-act="setupSkip">&larr; Paints</button></div>`;
}

function screenSetup(){
  const s = state.setup;
  if (s.step === 1) return setupSystems();
  if (s.step === 2) return setupArmy();
  if (s.step === 3) return setupPaints();
  return setupDone();
}

/* --- step 1: what do you play ------------------------------------------- */
function setupSystems(){
  const s = state.setup;
  let h = setupBar(1) +
    `<div class="ehead" style="margin-top:0"><div class="eb">Getting started</div>
      <h3>What do you play?</h3></div>
     <p class="small muted" style="margin:0">Tick as many as you like. This only decides
       which army lists you get offered &mdash; you can always type your own.</p>
     <div class="chips" role="group" aria-label="Game systems">`;
  /* Not the shared chips helper: it joins values with commas, and
     "Warhammer 40,000" has a comma in it. */
  SYSTEMS.forEach(sys => {
    const on = s.sysPick.indexOf(sys.name) !== -1;
    h += `<button class="chip" data-setupsys="${esc(sys.name)}" aria-pressed="${on}">${esc(sys.name)}</button>`;
  });
  h += `</div>
    <button class="btn advance" data-act="setupNext">Next</button>
    <button class="skip" data-act="setupSkip">Skip setup</button>`;
  return h;
}

/* --- step 2: your first army -------------------------------------------- */
function setupArmy(){
  const s = state.setup;
  const mine = arr(data.systems).map(x => x.name);
  const sysName = s.sysName || mine[0] || '';
  let h = setupBar(2) +
    `<div class="ehead" style="margin-top:0"><div class="eb">Getting started</div>
      <h3>Your first army</h3></div>`;
  if (!mine.length){
    h += `<p class="small muted">No game systems yet, so there are no army lists to offer.
      You can still name an army yourself.</p>`;
  }
  h += `<label for="suSys">Game system</label>
    <select id="suSys">${mine.map(n =>
      `<option value="${esc(n)}"${n === sysName ? ' selected' : ''}>${esc(n)}</option>`).join('')}
      <option value="">Not set</option></select>
    <label for="suFac">Army</label>
    <select id="suFac">${armyOptions(sysName, s.facName)}</select>
    <input id="suFacOwn" type="text" placeholder="Your own army" style="margin-top:.5rem" hidden>
    <label for="suUnit">Add a unit &mdash; type and press return</label>
    <div class="row" style="gap:.5rem">
      <input id="suUnit" class="grow" placeholder="Plague Marines" autocomplete="off">
      <input id="suCount" class="num" inputmode="numeric" value="1" aria-label="How many models"
        style="width:4.5rem;flex:0 0 auto;text-align:center">
    </div>
    <p class="small muted" style="margin:.375rem 0 0">The number is how many models are in
      that box. A box of ten counts as one entry with a count of ten.</p>
    <button class="btn ghost sm" data-act="setupAddUnit" style="margin-top:.625rem">Add it</button>`;

  if (s.units.length){
    h += `<div class="ulist">`;
    s.units.forEach((u, i) => {
      h += `<div class="uli">${dropSvg('udrop','')}
        <span class="unm user-text">${esc(u.name)}</span>
        <span class="uct num">&times;${u.total}</span>
        <button class="iconbtn" data-setupdelunit="${i}" aria-label="Remove ${esc(u.name)}">&times;</button></div>`;
    });
    h += `</div>`;
  }
  h += `<button class="btn advance" data-act="setupNext">${
      s.units.length ? `Next &mdash; add ${s.units.length === 1 ? 'this one' : `these ${s.units.length}`}` : 'Next'}</button>
    <button class="skip" data-act="setupSkipStep">I&rsquo;ll add models later</button>`;
  return h;
}

/* --- step 3: paints you own --------------------------------------------- */
function setupPaints(){
  const s = state.setup;
  const cat = catalogue();
  const brands = cat.brands.slice().sort((a,b) => a.localeCompare(b));
  /* Alphabetical for finding one, but the default is a guess at what you
     own rather than whichever brand starts with an A: the brand most of
     your existing paints come from, then Citadel, then the largest range. */
  const mineBy = {};
  arr(data.paints).forEach(p => { if (p.brand) mineBy[p.brand] = (mineBy[p.brand]||0) + 1; });
  const mineTop = Object.keys(mineBy).sort((a,b) => mineBy[b] - mineBy[a])[0];
  const biggest = () => {
    const n = {};
    cat.rows.forEach(r => { n[r.b] = (n[r.b]||0) + 1; });
    return brands.slice().sort((a,b) => (n[b]||0) - (n[a]||0))[0] || brands[0] || '';
  };
  const brand = s.brand || mineTop
    || (brands.indexOf('Citadel') !== -1 ? 'Citadel' : biggest());

  /* Ranges that actually exist for the chosen brand, in catalogue order. */
  const ranges = [], rangeN = {};
  cat.rows.forEach(r => { if (r.b !== brand) return;
    if (ranges.indexOf(r.rg) === -1) ranges.push(r.rg);
    rangeN[r.rg] = (rangeN[r.rg] || 0) + 1; });
  /* Biggest range first as the default, for the same reason as the brand:
     catalogue order would land you on Citadel Technical, which is nobody's
     starting point. The list itself stays in the publisher's own order. */
  const range = s.range && ranges.indexOf(s.range) !== -1 ? s.range
    : (ranges.slice().sort((a,b) => rangeN[b] - rangeN[a])[0] || '');

  const q = (s.pq || '').trim().toLowerCase();
  const hits = [];
  for (let i = 0; i < cat.rows.length && hits.length < 300; i++){
    const r = cat.rows[i];
    if (q.length >= 2){
      if ((r.n + ' ' + r.b + ' ' + r.rg + ' ' + r.c).toLowerCase().indexOf(q) !== -1) hits.push([i, r]);
    } else if (r.b === brand && r.rg === range) hits.push([i, r]);
  }
  const n = Object.keys(s.picked).filter(k => s.picked[k]).length;

  let h = (s.only === 'paints' ? setupCloseBar() : setupBar(3)) +
    `<div class="ehead" style="margin-top:0">
      <div class="eb">${s.only === 'paints' ? 'Paints' : 'Getting started'}</div>
      <h3>${s.only === 'paints' ? 'Add several at once' : 'Paints you own'}</h3></div>
     <p class="small muted" style="margin:0">Pick a brand and a range and tick what&rsquo;s on
       your shelf. They all go in together.</p>
     <label for="suBrand">Brand</label>
     <select id="suBrand">${brands.map(b =>
       `<option value="${esc(b)}"${b === brand ? ' selected' : ''}>${esc(b)}</option>`).join('')}</select>
     <label for="suRange">Range</label>
     <select id="suRange">${ranges.map(r =>
       `<option value="${esc(r)}"${r === range ? ' selected' : ''}>${esc(r)}</option>`).join('')}</select>
     <label for="suPq">Or search all <span class="num">${cat.rows.length}</span></label>
     <div class="field"><input id="suPq" type="search" value="${esc(s.pq || '')}"
       placeholder="Mephiston, Vallejo, 72.001" autocomplete="off">
       ${s.pq ? `<button class="clearq" data-act="setupClearQ" aria-label="Clear search">&times;</button>` : ''}</div>`;

  if (!hits.length){
    h += `<p class="small muted" style="margin-top:.75rem">${q.length >= 2
      ? 'Nothing matches that.' : 'No paints in that range.'}</p>`;
  } else {
    h += `<div style="margin-top:.625rem">`;
    hits.forEach(([i, r]) => {
      const on = !!s.picked[i];
      h += `<button class="prow" data-setuppaint="${i}" aria-pressed="${on}">
        <span class="ptick"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13 L10 18 L19 6"
          fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        ${dropSvg('pdrop', r.hex)}
        <span class="pnm user-text">${esc(r.n)}<em>${esc([r.b, r.rg, r.c].filter(Boolean).join(' · '))}</em></span>
      </button>`;
    });
    h += `</div>`;
    if (hits.length === 300) h += `<p class="small muted" style="margin-top:.5rem">Showing the
      first <span class="num">300</span>. Narrow the search to see the rest.</p>`;
  }

  h += `<p class="pcount"><b class="num">${n}</b> ticked so far${
    n ? '' : ' &mdash; tick anything you own'}</p>
    <button class="btn advance" data-act="setupFinish"${n ? '' : ' disabled'}>${
      n ? `Add ${n === 1 ? 'it' : `all ${n}`} and finish` : 'Add them and finish'}</button>
    <button class="skip" data-act="${s.only === 'paints' ? 'setupSkip' : 'setupSkipStep'}">${
      s.only === 'paints' ? 'Cancel' : 'I’ll add paints later'}</button>`;
  return h;
}

/* --- done ---------------------------------------------------------------- */
function setupDone(){
  const c = counts();
  const a = state.setup.added || { minis:0, models:0, paints:0, army:'' };
  /* The finish screen is not a trap, but the rule is the rule: a way out at
     the top of every screen, not only the big button under the summary. */
  return `<div class="setupbar"><span class="stepcap">All done</span>
      <button class="btn ghost sm" data-act="setupGo" style="margin-left:auto">Close</button></div>
    <div class="ehead" style="margin-top:0"><div class="eb">Your collection</div></div>
    <div class="hero"><b>${c.done}</b><span>finished<br>of ${c.total}</span></div>
    <hr class="keyline">
    <div class="ledger">
      <div class="lcell"><b>${c.started}</b><span>On the bench</span></div>
      <div class="lcell"><b>${c.backlog}</b><span>Still waiting</span></div>
      <div class="lcell"><b>${c.paints}</b><span>Paints owned</span></div>
    </div>
    <div class="help" style="margin-top:1.25rem">
      <span class="helph">You&rsquo;re set.</span>
      <p>${a.minis ? `<span class="num">${a.minis}</span> ${a.minis === 1 ? 'entry' : 'entries'}${
        a.army ? ` in <b class="user-text">${esc(a.army)}</b>` : ''}` : 'Nothing added yet'}${
        a.paints ? ` and <span class="num">${a.paints}</span> paint${a.paints === 1 ? '' : 's'} on the shelf` : ''}.</p>
      <p>Mark a paint <b>running low</b> while you&rsquo;re painting and it turns up on your
         shopping list by itself. You can run this again any time from the <b>&hellip;</b> menu.</p>
    </div>
    <button class="btn advance" data-act="setupGo">Take me to my collection</button>`;
}

/* ===========================================================================
   Armies

   An army is a game system and a faction together. Both have been on every
   model since v002, so none of this stores anything new — it is a view of
   what is already there.

   The groups are built from the models rather than from the list of factions,
   which guarantees every model appears in exactly one group. Building them
   from the faction list instead would silently hide anything with no army
   set, and "my models vanished" is a worse bug than an untidy heading.
   =========================================================================== */
const NO_SYS_ID = '_none';
const armyKey = m => (m.sys || '') + '|' + (m.fac || '');

/* What a game calls one of your forces. These are the plain words players
   use, not anything taken from a rulebook. Joe's own call: Necromunda is
   gangs and Kill Team is squads, and both can have several. */
const GROUP_WORDS = {
  'Necromunda':'gang', 'Kill Team':'squad', 'Warcry':'warband', 'Frostgrave':'warband',
  'Blood Bowl':'team', 'Dungeons & Dragons':'party', 'Pathfinder':'party',
  'Turnip28':'regiment', 'Mordheim':'warband', 'Gaslands':'team'
};
function groupWord(sysId, plural){
  const w = GROUP_WORDS[sysName(sysId)] || 'army';
  if (!plural) return w;
  return w === 'army' ? 'armies' : w === 'party' ? 'parties' : w + 's';
}
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const noArmyLabel = sysId => 'No ' + groupWord(sysId) + ' set';
const NO_SYS = 'No game set';
const gameLabel = id => id && id !== NO_SYS_ID ? (sysName(id) || NO_SYS) : NO_SYS;
const armyLabel = g => g.fac ? (facName(g.fac) || noArmyLabel(g.sys)) : noArmyLabel(g.sys);

function armyGroups(){
  const g = new Map();
  data.minis.forEach(m => {
    const k = armyKey(m);
    if (!g.has(k)) g.set(k, { key:k, sys:m.sys || '', fac:m.fac || '', minis:[] });
    g.get(k).minis.push(m);
  });
  return [...g.values()];
}
/* Games, biggest first, each holding its armies, biggest first. Anything
   with no game or no army set still appears, at the end, so nothing you own
   can drop out of sight. */
function gameGroups(){
  const by = new Map();
  armyGroups().forEach(g => {
    const id = g.sys || NO_SYS_ID;
    if (!by.has(id)) by.set(id, { id, armies:[], minis:[] });
    const x = by.get(id); x.armies.push(g); x.minis.push(...g.minis);
  });
  const models = ms => ms.reduce((n,m) => n + (Number(m.total)||1), 0);
  const out = [...by.values()];
  out.forEach(x => x.armies.sort((p,q) =>
    (!p.fac) - (!q.fac) || models(q.minis) - models(p.minis) || armyLabel(p).localeCompare(armyLabel(q))));
  return out.sort((p,q) => (p.id === NO_SYS_ID) - (q.id === NO_SYS_ID) ||
    models(q.minis) - models(p.minis) || gameLabel(p.id).localeCompare(gameLabel(q.id)));
}

function armyStats(minis){
  const models   = minis.reduce((n,m) => n + (Number(m.total)||1), 0);
  const done     = minis.reduce((n,m) => n + (Number(m.done)||0), 0);
  const started  = minis.filter(m => stageIx(m) > 0 && !isDone(m)).length;
  const backlog  = minis.filter(m => stageIx(m) === 0).length;
  const priced   = minis.filter(m => m.price != null && m.price !== '');
  const spent    = priced.reduce((n,m) => n + (Number(m.price)||0), 0);
  return { entries:minis.length, models, done, started, backlog,
           spent, priced:priced.length, missing:minis.length - priced.length,
           pct: models ? Math.round((done / models) * 100) : 0 };
}

/* The way back, at the top of every step: Collection, then the game. */
const backLink = (act, label) =>
  `<button class="backlink" data-act="${act}"><span aria-hidden="true">&lsaquo;</span> ${esc(label)}</button>`;

/* ===========================================================================
   Collection: game, then army, then models.

   Armies are never mixed. Death Guard and Tyranids are different things on
   different shelves, so every list of models in this app sits under its
   game and army. Search and filters look across everything, but their
   results are grouped the same way.
   =========================================================================== */
function screenCollection(){
  if (state.openArmy) return screenArmy();
  if (state.openGame) return screenGame();
  let h = '';
  if (!data.minis.length)
    return h + `<div class="empty" style="margin-top:.875rem"><p>No miniatures yet. A box of ten counts as one entry with a count of ten &mdash; you do not need a record per model.</p>
      <button class="btn" data-act="addMini">Add your first</button></div>`;

  const nOn = (state.fStage?1:0) + (state.sort?1:0);
  h += `<div class="findrow" style="margin-top:.875rem"><div class="field">
      <label for="q" class="sr-only">Search every model</label>
      <input id="q" type="search" placeholder="Search every model" value="${esc(state.q)}">
      ${state.q?`<button class="clearq" data-act="clearq" aria-label="Clear search">&times;</button>`:''}</div>
    <button class="fopen" data-act="openFilter" aria-haspopup="dialog">Filter${nOn?` <span class="fc">${nOn}</span>`:''}</button></div>`;
  if (nOn){
    h += `<div class="chips">`;
    if (state.fStage) h += `<button class="chip on-x" data-act="unfilter" data-k="stage" aria-label="Remove filter ${esc(state.fStage)}">${esc(state.fStage)} &times;</button>`;
    if (state.sort) h += `<button class="chip on-x" data-act="unfilter" data-k="sort" aria-label="Stop sorting">${state.sort==='waiting'?'Longest waiting':'Most expensive'} &times;</button>`;
    h += `</div>`;
  }

  /* Searching or filtering: matching models, under game and army headings. */
  if (state.q.trim() || nOn) return h + groupedResults(filtered());

  gameGroups().forEach(x => {
    const s = armyStats(x.minis);
    const nA = x.armies.length;
    const word = groupWord(x.id === NO_SYS_ID ? '' : x.id, nA !== 1);
    h += `<button class="gamecard" data-opengame="${esc(x.id)}">
      ${potSvg(s.models ? s.done / s.models : 0, 'apot')}
      <span class="aname"><b class="user-text">${esc(gameLabel(x.id))}</b>
        <span><span class="num">${nA}</span> ${word} &middot; <span class="num">${s.models}</span> model${s.models===1?'':'s'}</span></span>
      <span class="apct">${s.pct}%</span><span class="chev" aria-hidden="true">&rsaquo;</span></button>`;
  });
  return h;
}

/* Search and filter results. The list is already in the order asked for;
   grouping keeps that order inside each army and puts the armies in the
   order their first match appears. */
function groupedResults(list){
  if (!list.length)
    return `<div class="empty"><p>No models match${state.q?` &ldquo;${esc(state.q)}&rdquo;`:' those filters'}.</p>
      <button class="btn ghost" data-act="clearFilters">Clear search and filters</button></div>`;
  const groups = new Map();
  list.forEach(m => { const k = armyKey(m); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(m); });
  /* Unsorted, the armies come in the same order as the Collection itself:
     biggest game first, biggest army first. Sorted, the army holding the
     first result leads, so "longest waiting" still reads top to bottom. */
  let keys = [...groups.keys()];
  if (!state.sort){
    const order = [];
    gameGroups().forEach(x => x.armies.forEach(g => order.push(g.key)));
    keys.sort((p,q) => order.indexOf(p) - order.indexOf(q));
  }
  let h = `<p class="small muted"><span class="num">${list.length}</span> of <span class="num">${data.minis.length}</span></p>`;
  keys.forEach(k => { const ms = groups.get(k);
    const g = { sys:ms[0].sys||'', fac:ms[0].fac||'' };
    h += `<button class="crumb" data-openarmy="${esc(k)}">${esc(gameLabel(g.sys))} &rsaquo; ${esc(armyLabel(g))}</button>`;
    ms.forEach(m => { h += modelRow(m); });
  });
  return h;
}
function modelRow(m){
  const n = Number(m.total)||1, d = Number(m.done)||0;
  const note = sortNote(m) || (stageIx(m) === 0 && m.acquired
    ? `<span class="small muted">${esc(waitedFor(m.acquired))}</span>` : '');
  return `<button class="mrow" data-open="${esc(m.id)}">
    <span class="grow user-text">${esc(m.name)}</span>
    <span class="small muted mst">${esc(m.stage)}${n>1&&!isDone(m)&&d?` &middot; <span class="num">${d} of ${n}</span>`:''}${note?'<br>'+note:''}</span></button>`;
}

function screenGame(){
  const x = gameGroups().find(g => g.id === state.openGame);
  let h = backLink('backGames', 'Collection');
  if (!x) return h + `<div class="empty"><p>Nothing is filed under that game any more.</p></div>`;
  const sysId = x.id === NO_SYS_ID ? '' : x.id;
  x.armies.forEach(g => {
    const s = armyStats(g.minis);
    h += `<button class="arow" data-openarmy="${esc(g.key)}">
      ${potSvg(s.models ? s.done / s.models : 0, 'apot')}
      <span class="aname"><b class="user-text">${esc(armyLabel(g))}</b>
        <span><span class="num">${s.done} of ${s.models}</span> finished${s.started?` &middot; <span class="num">${s.started}</span> on the bench`:''}</span></span>
      <span class="apct">${s.pct}%</span><span class="chev" aria-hidden="true">&rsaquo;</span></button>`;
  });
  return h;
}

function screenArmy(){
  const g = armyGroups().find(x => x.key === state.openArmy);
  const sysId = (state.openArmy || '').split('|')[0];
  let h = backLink('backGame', gameLabel(sysId || NO_SYS_ID));
  if (!g) return h + `<div class="empty"><p>That ${groupWord(sysId)} no longer has anything in it.</p></div>`;

  const s = armyStats(g.minis);
  h += `<div class="armyhead">
      ${potSvg(s.models ? s.done / s.models : 0, 'bigpot')}
      <div><div class="hero" style="margin:0"><b>${s.pct}%</b></div>
        <div class="small muted"><span class="num">${s.done} of ${s.models}</span> models finished${
          s.priced ? ` &middot; ${esc(money(s.spent))} spent` : ''}</div></div>
    </div>
    <hr class="keyline">`;

  /* Three shelves, in the order you would want them: what you are working on,
     what is still in the box, and what is done. */
  const bench = g.minis.filter(m => stageIx(m) > 0 && !isDone(m))
    .sort((p,q) => stageIx(q) - stageIx(p) || (q.updated||0) - (p.updated||0));
  const waiting = g.minis.filter(m => stageIx(m) === 0 && !isDone(m))
    .sort((p,q) => (p.acquired||'9999').localeCompare(q.acquired||'9999'));
  const done = g.minis.filter(isDone).sort((p,q) => (q.updated||0) - (p.updated||0));
  const shelf = (title, ms, asTiles) => {
    if (!ms.length) return '';
    let o = `<div class="ehead shelf"><h2>${title}</h2><span class="small muted num">${ms.length}</span></div>`;
    if (asTiles){ o += `<div class="grid">`; ms.forEach(m => { o += tile(m); }); o += `</div>`; }
    else ms.forEach(m => { o += modelRow(m); });
    return o;
  };
  h += shelf('On the bench', bench, true);
  h += shelf(`Still to build`, waiting, false);
  h += shelf('Finished', done, true);
  return h;
}

/* Moving between Collection's steps. Deeper slides in from the right, back
   slides out to the right, so the way out mirrors the way in. Browsers
   without view transitions just change screen, as before. */
function navGo(dir, change){
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!document.startViewTransition){ change(); return; }
  document.documentElement.dataset.nav = reduce ? 'fade' : dir;
  const vt = document.startViewTransition(change);
  vt.finished.finally(() => { delete document.documentElement.dataset.nav; });
}

/* A one-line title for the top bar while inside a game or an army. */
function collTitle(){
  if (state.openMini) return 'Collection';
  if (state.openArmy){
    const [sys, fac] = state.openArmy.split('|');
    return armyLabel({ sys, fac });
  }
  if (state.openGame) return gameLabel(state.openGame);
  return 'Collection';
}

/* --- the filter panel ----------------------------------------------------
   Each chip applies at once, so the list behind updates as you tap and the
   button at the foot says how many will show. Nothing here is new: these are
   the same filters that used to sit on the screen, moved one tap away. */
function filterSheetBody(){
  if (state.sheet === 'paints'){
    const stockCount = {};
    data.paints.forEach(p => { stockCount[p.stock] = (stockCount[p.stock]||0)+1; });
    let h = `<p class="fsec">How you are for it</p><div class="chips">`;
    STOCK.filter(s => stockCount[s]).forEach(s => {
      h += `<button class="chip" data-fstock="${esc(s)}" aria-pressed="${state.pStock===s}">
        ${esc(s)} <span class="n">${stockCount[s]}</span></button>`;
    });
    h += `</div>`;
    if (state.pStock) h += `<button class="fclear" data-act="unfilterAll">Clear filter</button>`;
    return h;
  }
  /* Game and army are not in here: those are the Collection's own steps.
     This is for looking across everything, and the results come back
     grouped by game and army. */
  const stageCount = {};
  data.minis.forEach(m => { stageCount[m.stage] = (stageCount[m.stage]||0)+1; });
  let h = '';
  h += `<p class="fsec">Stage</p><div class="chips">`;
  data.stages.filter(s => stageCount[s]).forEach(s => {
    h += `<button class="chip" data-fstage="${esc(s)}" aria-pressed="${state.fStage===s}">
      ${esc(s)} <span class="n">${stageCount[s]}</span></button>`;
  });
  h += `</div>`;
  /* Only offer the sorts that have data behind them. */
  const anyDate = data.minis.some(m => m.acquired);
  const anyPrice = data.minis.some(m => m.price != null && m.price !== '');
  if (anyDate || anyPrice){
    h += `<p class="fsec">Sort</p><div class="chips">`;
    if (anyDate) h += `<button class="chip" data-sort="waiting" aria-pressed="${state.sort==='waiting'}">Longest waiting</button>`;
    if (anyPrice) h += `<button class="chip" data-sort="value" aria-pressed="${state.sort==='value'}">Most expensive</button>`;
    h += `</div>`;
  }
  if (state.fStage || state.sort)
    h += `<button class="fclear" data-act="unfilterAll">Clear all filters</button>`;
  return h;
}
function sheetCountLabel(){
  if (state.sheet === 'paints'){
    const n = paintList().length;
    return `Show ${n} paint${n===1?'':'s'}`;
  }
  const n = filtered().length;
  return `Show ${n} model entr${n===1?'y':'ies'}`;
}
function openFilterSheet(kind){
  state.sheet = kind;
  openDialog('Filter', `<div id="fsheet">${filterSheetBody()}</div>`, () => true, sheetCountLabel());
  const dlg = $('#dlg');
  dlg.classList.add('sheet');
  /* The foot already has the one button that matters; the x in the header
     is the way out, so the footer's Cancel would just be a second one. */
  const foot = dlg.querySelector('.dlgbody > .row:last-child [data-dlg="cancel"]');
  if (foot) foot.remove();
  dlg.addEventListener('close', () => { state.sheet = ''; dlg.classList.remove('sheet','leaving','dragging'); dlg.style.transform = ''; }, { once:true });
  $('#dlgBody').insertAdjacentHTML('afterbegin', '<div class="grab" aria-hidden="true"></div>');
  sheetDrag(dlg);
}

/* Drag the panel down by its handle or header to close it. It follows the
   finger 1:1, resists being pulled upward, and a quick flick closes it even
   if it has not travelled far. Letting go short springs it back. */
function sheetDrag(dlg){
  if (!(window.matchMedia && matchMedia('(max-width:40rem)').matches)) return;
  let y0 = null, last = [], id = null;
  const down = e => {
    if (!e.target.closest('.grab, .dlghead') || e.target.closest('button')) return;
    y0 = e.clientY; last = [[e.clientY, e.timeStamp]]; id = e.pointerId;
    dlg.setPointerCapture(id); dlg.classList.add('dragging');
  };
  const move = e => {
    if (y0 === null || e.pointerId !== id) return;
    let dy = e.clientY - y0;
    if (dy < 0) dy = -Math.sqrt(-dy) * 2;          /* resist upward */
    dlg.style.transform = `translateY(${dy}px)`;
    last.push([e.clientY, e.timeStamp]); if (last.length > 5) last.shift();
  };
  const up = e => {
    if (y0 === null || e.pointerId !== id) return;
    const dy = e.clientY - y0;
    const [a, b] = [last[0], last[last.length-1]];
    const v = b[1] > a[1] ? (b[0] - a[0]) / (b[1] - a[1]) : 0;   /* px per ms */
    y0 = null; dlg.classList.remove('dragging');
    if (dy > 90 || v > 0.6){ closeSheet(dlg); }
    else { dlg.style.transform = ''; }
  };
  dlg.addEventListener('pointerdown', down);
  dlg.addEventListener('pointermove', move);
  dlg.addEventListener('pointerup', up);
  dlg.addEventListener('pointercancel', up);
  dlg.addEventListener('close', () => {
    dlg.removeEventListener('pointerdown', down); dlg.removeEventListener('pointermove', move);
    dlg.removeEventListener('pointerup', up); dlg.removeEventListener('pointercancel', up);
  }, { once:true });
}
/* Leave downward, the way it arrived, then close. */
function closeSheet(dlg){
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !dlg.classList.contains('sheet')){ dlg.close(); return; }
  dlg.style.transform = '';
  dlg.classList.add('leaving');
  setTimeout(() => dlg.close(), 220);
}
function refreshFilterSheet(){
  const dlg = $('#dlg'), box = document.getElementById('fsheet');
  if (!state.sheet || !dlg.open || !box) return;
  box.innerHTML = filterSheetBody();
  const ok = dlg.querySelector('[data-dlg="ok"]');
  if (ok) ok.textContent = sheetCountLabel();
}

/* Search reads the game system and army names too. An earlier version matched
   only name, tags and notes, so typing a system returned nothing at all. */
function filtered(){
  const q = state.q.trim().toLowerCase();
  return data.minis.filter(m => {
    if (state.fSys && m.sys !== state.fSys) return false;
    if (state.fFac && m.fac !== state.fFac) return false;
    if (state.fStage && m.stage !== state.fStage) return false;
    if (!q) return true;
    const hay = [m.name, m.tags, m.notes, sysName(m.sys), facName(m.fac), m.stage, m.unit]
      .filter(Boolean).join(' ').toLowerCase();
    return hay.includes(q);
  }).sort(sorter());
}

/* Most recently touched by default. "Longest waiting" uses the date you got
   it, which is a different fact from when you added the record — you might
   log a box today that has sat in a cupboard for three years. Anything with
   no date goes last rather than pretending to be new. */
function sorter(){
  if (state.sort === 'waiting'){
    return (a,b) => {
      const am = monthsSince(a.acquired), bm = monthsSince(b.acquired);
      if (am === null && bm === null) return (b.updated||0)-(a.updated||0);
      if (am === null) return 1;
      if (bm === null) return -1;
      return bm - am;
    };
  }
  if (state.sort === 'value'){
    return (a,b) => (Number(b.price)||0) - (Number(a.price)||0);
  }
  return (a,b) => (b.updated||0)-(a.updated||0);
}

/* ===========================================================================
   Model detail
   =========================================================================== */
function screenMini(){
  const m = data.minis.find(x => x.id === state.openMini);
  if (!m) return `<div class="empty"><p>That miniature no longer exists.</p>
    <button class="btn" data-back="coll">Back to collection</button></div>`;
  const n = Number(m.total)||1, d = Number(m.done)||0, cur = stageIx(m), last = data.stages.length-1;
  const fin = cur === last;

  let h = backLink('backMini', armyLabel({ sys:m.sys||'', fac:m.fac||'' }));
  h += `<h2 class="display user-text" style="font-size:1.625rem">${esc(m.name)}</h2>`;
  const sub = [sysName(m.sys), facName(m.fac)].filter(Boolean).join(' · ');
  if (sub) h += `<p class="muted user-text" style="margin-top:-.25rem">${esc(sub)}</p>`;

  /* "Waiting since", not "neglected for". The hobby makes its own jokes about
     the pile of shame; the app only has to tell the truth. */
  const facts = [];
  if (m.acquired) facts.push((isFinished(m) ? 'Bought ' : 'Waiting since ') + esc(waitingSince(m.acquired)));
  if (m.price != null && m.price !== '') facts.push(esc(money(m.price)));
  if (m.unit) facts.push(esc(m.unit));
  if (m.base) facts.push(esc(m.base));
  if (facts.length) h += `<p class="small muted" style="margin-top:.25rem">${facts.join(' &middot; ')}</p>`;

  const stageHelp = helpBlock('stages');
  const prog = last ? cur / last : 1;
  h += `<div class="card${fin?' finished':''}">
    <div class="flab" style="margin-top:0"><h3 style="margin:0">Progress</h3>${stageHelp.btn}</div>
    ${stageHelp.panel}
    <div class="vessel${fin?' full':''}">${potSvg(prog)}
      <div class="vtext">
        <div class="stagename user-text">${esc(m.stage)}</div>
        <div class="vsub">Stage <span class="num">${cur+1}</span> of <span class="num">${last+1}</span>${fin?'':' &middot; ' + potWord(prog)}</div>
      </div>
    </div>`;
  if (!fin) h += `<button class="btn advance" data-adv>Move to ${esc(data.stages[cur+1])} &rarr;</button>`;
  h += `<button class="btn ghost jumpbtn" data-jump aria-expanded="false" aria-controls="ladder">Jump to another stage</button>
    <div class="ladder" id="ladder"><div>`;
  data.stages.forEach((s,i) => {
    const st = i < cur ? 'done' : i === cur ? 'now' : 'todo';
    h += `<button class="lrow" data-stage="${esc(s)}" data-s="${st}">
      ${dropSvg('ldrop', i < cur ? 'var(--success)' : i === cur ? 'var(--gold)' : '')}
      <span class="lname user-text">${esc(s)}</span>
      ${st==='done'?'<span class="ltag">Done</span>':st==='now'?'<span class="ltag">You are here</span>':''}
    </button>`;
  });
  h += `</div></div>`;
  h += `<div class="finmark${fin?' on':''}"><i>&#10003;</i> Finished${n>1?` &mdash; all ${n} of them`:''}</div>`;
  if (n > 1){
    h += `<label for="doneN">How many of the ${n} are finished?</label>
      <div class="row"><input id="doneN" type="number" min="0" max="${n}" value="${d}" style="max-width:7.5rem">
      <span class="muted small"><span class="num">${d} of ${n}</span> finished</span></div>`;
  }
  h += `</div>`;

  h += `<div class="card"><div class="row spread"><h3 style="margin:0">Photos</h3>
    <button class="btn sm ghost" data-act="addPhotos">Add photo</button></div><div class="photos">`;
  arr(m.photos).forEach(pid => {
    h += `<span class="photowrap">${photoImg(pid)}<button data-delphoto="${esc(pid)}" aria-label="Remove photo">&times;</button></span>`;
  });
  h += `</div>${arr(m.photos).length?'':'<p class="small muted">No photos yet. Anything you add stays on this phone.</p>'}</div>`;

  const linked = data.links.filter(l => l.miniId === m.id);
  h += `<div class="card"><div class="row spread"><h3 style="margin:0">Recipes</h3>
    <button class="btn sm ghost" data-act="linkRecipe">Attach</button></div>`;
  if (!linked.length) h += `<p class="small muted">No recipes attached yet.</p>`;
  linked.forEach(l => {
    const r = data.recipes.find(x => x.id === l.recipeId);
    if (!r) return;
    h += `<div class="row spread" style="padding:.5rem 0;border-top:1px solid var(--border)">
      <button class="grow" data-openrecipe="${esc(r.id)}" style="background:none;border:0;text-align:left;font:inherit;color:var(--text);cursor:pointer;min-height:var(--tap)">
        <b class="user-text">${esc(r.title)}</b>${l.area?`<span class="small muted"> &mdash; ${esc(l.area)}</span>`:''}</button>
      <button class="iconbtn" data-unlink="${esc(l.recipeId)}" aria-label="Remove recipe link">&times;</button></div>`;
  });
  h += `</div>`;

  h += `<div class="card"><h3>Details</h3>
    <label for="eName">Name</label><input id="eName" value="${esc(m.name)}">
    <label for="eTotal">How many models in this entry</label><input id="eTotal" type="number" min="1" value="${n}">
    ${chips('eUnit', UNIT_TYPES, { label:'Unit type', value:m.unit || '',
      help:'unitType', ownPlaceholder:'Whatever your game calls it' })}
    ${field('eBase','Base size',
      `<select id="eBase"><option value="">Not set</option>
         ${BASE_SIZES.map(b => `<option value="${esc(b[0])}"${m.base === b[0] ? ' selected' : ''}>${esc(b[0])} &mdash; ${esc(b[1])}</option>`).join('')}
       </select>`, 'baseSize')}
    <label for="ePrice">What it cost <span class="opt">optional</span></label>
    <input id="ePrice" type="number" min="0" step="0.01" inputmode="decimal"
      value="${m.price == null ? '' : esc(String(m.price))}">
    <label for="eAcq">When you got it <span class="opt">optional</span></label>
    <input id="eAcq" type="date" value="${esc(m.acquired || '')}">
    ${chips('eTags', CHIPS.tag, { label:'Tags', value:m.tags || '', multi:true,
      ownPlaceholder:'Your own tags, separated by commas' })}
    <label for="eNotes">Notes</label><textarea id="eNotes" class="user-text">${esc(m.notes||'')}</textarea>
    <div class="row" style="margin-top:.875rem"><button class="btn" data-act="saveMini">Save changes</button>
    <button class="btn danger" data-act="delMini">Delete</button></div></div>`;
  return h;
}

/* ===========================================================================
   Paints
   =========================================================================== */
function paintList(){
  const q = state.pq.trim().toLowerCase();
  return data.paints.filter(p => {
    if (state.pStock && p.stock !== state.pStock) return false;
    if (!q) return true;
    return [p.name,p.brand,p.range,p.code,p.type].filter(Boolean).join(' ').toLowerCase().includes(q);
  });
}

function screenPaints(){
  if (state.sub === 'swatchCompare') return screenCompare();
  if (state.sub === 'planner') return screenPlanner();
  if (state.openPaint) return screenPaintDetail();

  /* Add is in the top bar. The planner, the swatch comparison and adding
     several at once are in the ... menu; the stock filter is behind Filter. */
  const nd = needList();
  let h = '';

  if (!data.paints.length){
    return h + `<div class="empty" style="margin-top:.875rem"><p>No paints yet. Add one from the catalogue of
      <span class="num">${catalogue().rows.length.toLocaleString()}</span> paints, or enter your own.</p>
      <div class="row wrapm" style="justify-content:center">
      <button class="btn" data-act="addPaint">Add a paint</button>
      <button class="btn ghost" data-act="setupPaintsOnly">Add several at once</button></div></div>`;
  }

  h += `<div class="findrow" style="margin-top:.875rem"><div class="field">
      <label for="pq" class="sr-only">Search your paints</label>
      <input id="pq" type="search" placeholder="Search ${data.paints.length} paints" value="${esc(state.pq)}">
      ${state.pq?`<button class="clearq" data-act="clearpq" aria-label="Clear search">&times;</button>`:''}</div>
    <button class="fopen" data-act="openPaintFilter" aria-haspopup="dialog">Filter${state.pStock?` <span class="fc">1</span>`:''}</button></div>`;
  if (state.pStock)
    h += `<div class="chips"><button class="chip on-x" data-act="unfilter" data-k="stock" aria-label="Remove filter ${esc(state.pStock)}">${esc(state.pStock)} &times;</button></div>`;
  /* Always here: it is also the way to the wishlist and supplies, which
     vanished whenever nothing happened to be running low (v011 to v014). */
  const wn = arr(data.wishlist).length;
  h += `<button class="shopline" data-act="shop"><span class="sl">Shopping list${nd.total ? ` &middot; <span class="num">${nd.total}</span> to buy` : ''}${wn ? ` &middot; wishlist <span class="num">${wn}</span>` : ' &amp; wishlist'}</span><span class="sr" aria-hidden="true">&rsaquo;</span></button>`;

  const q = state.pq.trim().toLowerCase();
  const list = paintList();
  if (!list.length) return h + `<div class="empty"><p>No paints match${q?` &ldquo;${esc(state.pq)}&rdquo;`:''}.</p>
    <button class="btn ghost" data-act="clearPaintFilters">Clear search and filters</button></div>`;

  /* Your rule: an estimated colour is never presented as how a paint looks.
     One line says so for the whole list; a photographed swatch is the
     exception, and only those rows carry a mark. */
  h += `<p class="estline">Colours are the maker&rsquo;s estimates until you photograph a swatch.</p>`;
  h += `<p class="small muted"><span class="num">${list.length}</span> of <span class="num">${data.paints.length}</span> shown</p>`;
  list.forEach(p => {
    const sw = data.swatches.filter(s => s.paintId === p.id).length;
    h += `<button class="paintrow" data-openpaint="${esc(p.id)}" style="margin-bottom:.5rem">
      <span class="sw" style="background:${esc(p.hex||'#CFC7BA')}"></span>
      <span class="grow"><span class="nm user-text">${esc(p.name)}</span><br>
        <span class="br">${esc([p.brand,p.range].filter(Boolean).join(' · '))}${p.code?' · '+esc(p.code):''}</span></span>
      ${sw?`<span class="tagmini">${sw} swatch${sw>1?'es':''}</span>`:''}</button>`;
  });
  return h;
}

function screenPaintDetail(){
  const p = paintOf(state.openPaint);
  if (!p) return `<div class="empty"><p>That paint no longer exists.</p>
    <button class="btn" data-back="paints">Back to paints</button></div>`;
  const sws = data.swatches.filter(s => s.paintId === p.id);

  let h = backBtn('paints','Paints');
  h += `<h2 class="display user-text" style="font-size:1.625rem">${esc(p.name)}</h2>
    <p class="muted user-text" style="margin-top:-.25rem">${esc([p.brand,p.range,p.code].filter(Boolean).join(' · '))}</p>`;

  h += `<div class="card"><h3>Colour</h3>
    <p class="small muted">The chip is the maker&rsquo;s estimate. Your swatches are photographs of the paint
      as it actually went on, over a named undercoat.</p>
    <div class="swatchpair">
      <figure><div class="estchip" style="background:${esc(p.hex||'#CFC7BA')}"></div>
        <figcaption>Maker&rsquo;s estimate</figcaption></figure>
      ${sws.length
        ? `<figure>${photoImg(sws[0].photoId,'realswatch')}<figcaption>Your swatch &mdash; over ${esc(ucName(sws[0].undercoatId).toLowerCase())}</figcaption></figure>`
        : `<figure><div class="estchip" style="background:var(--warm-grey)"></div>
             <figcaption>No swatch photographed yet</figcaption></figure>`}
    </div>
    <button class="btn" data-act="newSwatch" style="width:100%">Photograph a swatch</button></div>`;

  if (sws.length){
    h += `<div class="card"><h3>Your swatches</h3>`;
    sws.forEach(s => {
      h += `<div class="row" style="padding:.625rem 0;border-top:1px solid var(--border)">
        ${photoImg(s.photoId,'realswatch')}
        <span class="grow"><b>Over ${esc(ucName(s.undercoatId).toLowerCase())}</b>
          <span class="small muted" style="display:block">${s.coats?esc(s.coats)+' coat'+(s.coats>1?'s':''):'Coats not noted'}${s.lighting?' · '+esc(s.lighting):''}</span>
          ${s.notes?`<span class="small muted user-text" style="display:block">${esc(s.notes)}</span>`:''}</span>
        <button class="iconbtn" data-delswatch="${esc(s.id)}" aria-label="Delete swatch">&times;</button></div>`;
    });
    h += `<p class="small muted" style="margin-top:.75rem">Photographs vary with lighting, camera and screen.
      They show how the paint behaved for you, not a calibrated colour.</p></div>`;
  }

  h += `<div class="card"><h3>Details</h3>
    ${field('pStock','Stock', `<select id="pStock">${STOCK.map(s =>
      `<option${p.stock===s?' selected':''}>${esc(s)}</option>`).join('')}</select>`, 'stock')}
    ${field('pType','Type', `<select id="pType"><option value="">Not set</option>${PAINT_TYPES.map(t =>
      `<option${p.type===t?' selected':''}>${esc(t)}</option>`).join('')}</select>`, 'paintType')}
    <label for="pNotes">Notes</label><textarea id="pNotes" class="user-text">${esc(p.notes||'')}</textarea>
    <div class="row" style="margin-top:.875rem"><button class="btn" data-act="savePaint">Save changes</button>
    <button class="btn danger" data-act="delPaint">Delete</button></div></div>`;
  return h;
}

/* ===========================================================================
   Swatch comparison
   =========================================================================== */
function screenCompare(){
  let h = backBtn('paints','Paints');
  h += `<h2 class="display" style="font-size:1.5rem">Compare swatches</h2>`;
  if (!data.swatches.length)
    return h + `<div class="empty"><p>No swatches yet. Photograph one from any paint and it shows up here.</p></div>`;

  h += `<div class="chips">
    <button class="chip" data-cmpmode="paint" aria-pressed="${state.cmp.mode==='paint'}">One paint, every undercoat</button>
    <button class="chip" data-cmpmode="under" aria-pressed="${state.cmp.mode==='under'}">One undercoat, every paint</button></div>`;

  if (state.cmp.mode === 'paint'){
    const withSw = data.paints.filter(p => data.swatches.some(s => s.paintId === p.id));
    const sel = state.cmp.paintId || (withSw[0] && withSw[0].id);
    h += `<label for="cmpPaint">Paint</label><select id="cmpPaint">${withSw.map(p =>
      `<option value="${esc(p.id)}"${sel===p.id?' selected':''}>${esc(p.name)} &mdash; ${esc(p.brand||'')}</option>`).join('')}</select>`;
    const list = data.swatches.filter(s => s.paintId === sel);
    h += `<div class="grid" style="margin-top:.875rem">`;
    list.forEach(s => {
      h += `<figure style="margin:0">${photoImg(s.photoId,'realswatch')}
        <figcaption class="small muted" style="text-align:center;margin-top:.375rem">Over ${esc(ucName(s.undercoatId).toLowerCase())}</figcaption></figure>`;
    });
    h += `</div>`;
    if (list.length < 2) h += `<p class="small muted">Photograph this paint over another undercoat to compare them side by side.</p>`;
  } else {
    const used = data.undercoats.filter(u => data.swatches.some(s => s.undercoatId === u.id));
    const sel = state.cmp.ucId || (used[0] && used[0].id);
    h += `<label for="cmpUc">Undercoat</label><select id="cmpUc">${used.map(u =>
      `<option value="${esc(u.id)}"${sel===u.id?' selected':''}>${esc(u.name)}</option>`).join('')}</select>`;
    const list = data.swatches.filter(s => s.undercoatId === sel);
    h += `<div class="grid" style="margin-top:.875rem">`;
    list.forEach(s => {
      const p = paintOf(s.paintId);
      h += `<figure style="margin:0">${photoImg(s.photoId,'realswatch')}
        <figcaption class="small muted" style="text-align:center;margin-top:.375rem">${esc(p?p.name:'Unknown paint')}</figcaption></figure>`;
    });
    h += `</div>`;
  }
  h += `<p class="small muted" style="margin-top:1rem">These are your photographs. Lighting, camera and screen
    all change what you see, so compare them against each other rather than treating any one as the true colour.</p>`;
  return h;
}

/* ===========================================================================
   Colour scheme planner
   =========================================================================== */
function screenPlanner(){
  let h = backBtn('paints','Paints');
  const planHelp = helpBlock('colourPlan');
  h += `<div class="flab"><h2 class="display" style="font-size:1.5rem;margin:0">Plan a colour scheme</h2>${planHelp.btn}</div>${planHelp.panel}`;
  if (!data.paints.length)
    return h + `<div class="empty"><p>Add a paint first &mdash; the scheme is built around one you own.</p></div>`;

  const sel = state.planner.paintId || data.paints[0].id;
  const base = paintOf(sel) || data.paints[0];
  h += `<label for="plPaint">Base paint</label><select id="plPaint">${data.paints.map(p =>
    `<option value="${esc(p.id)}"${sel===p.id?' selected':''}>${esc(p.name)} &mdash; ${esc(p.brand||'')}</option>`).join('')}</select>`;

  h += `<div class="chips" style="margin-top:.75rem">`;
  Object.keys(HARMONIES).forEach(k => {
    h += `<button class="chip" data-harm="${k}" aria-pressed="${state.planner.kind===k}">${esc(HARMONIES[k].label)}</button>`;
  });
  h += `</div>`;

  const kind = state.planner.kind, sch = scheme(kind, base.hex || '#CFC7BA');
  h += `<div class="card"><p class="small" style="margin:0 0 .75rem">${esc(HARMONIES[kind].note)}</p>`;
  h += wheelSvg(sch, base.hex || '#CFC7BA');
  sch.forEach(c => {
    const m = nearestPaint(c.hex);
    h += `<div class="srow"><span class="sw" style="background:${esc(c.hex)}"></span>
      <span class="grow"><span class="role">${esc(c.role)}</span><br>
        <b class="user-text">${m && m.paint ? esc(m.paint.n) : 'No match found'}</b>
        <span class="small muted">${m && m.paint ? esc(m.paint.b) : ''}</span></span>
      ${m ? `<span class="de">&Delta;E ${m.de.toFixed(1)}</span>` : ''}</div>`;
  });
  h += `<p class="small muted" style="margin-top:.875rem"><b>These matches are estimates.</b> They are calculated
    from a colour value someone typed into a catalogue, not from how the paint behaves over your undercoat.
    &Delta;E is how far the nearest paint sits from the ideal colour &mdash; under 2 is close, over 10 is a different colour.
    Photograph a swatch before trusting any of it.</p></div>`;
  return h;
}

function wheelSvg(sch, baseHex){
  const cx = 110, cy = 110, r = 86;
  let ring = '';
  for (let a = 0; a < 360; a += 3){
    const [r1,g1,b1] = hslRgb(a, .62, .52);
    const x1 = cx + Math.cos((a-90)*Math.PI/180)*r, y1 = cy + Math.sin((a-90)*Math.PI/180)*r;
    const x2 = cx + Math.cos((a+3-90)*Math.PI/180)*r, y2 = cy + Math.sin((a+3-90)*Math.PI/180)*r;
    ring += `<path d="M${x1.toFixed(1)} ${y1.toFixed(1)}A${r} ${r} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}"
      stroke="${rgbHex(r1,g1,b1)}" stroke-width="15" fill="none"/>`;
  }
  let dots = '';
  sch.forEach((c,i) => {
    const [rr,gg,bb] = hexRgb(c.hex); const [hh] = rgbHsl(rr,gg,bb);
    const rad = r - 26;
    const x = cx + Math.cos((hh-90)*Math.PI/180)*rad, y = cy + Math.sin((hh-90)*Math.PI/180)*rad;
    dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="11" fill="${esc(c.hex)}"
      stroke="var(--text)" stroke-width="1.5"/>
      <text x="${x.toFixed(1)}" y="${(y+3.5).toFixed(1)}" text-anchor="middle" font-size="9"
        fill="var(--bg)" font-weight="700">${i+1}</text>`;
  });
  return `<svg class="wheel" viewBox="0 0 220 220" width="220" height="220" role="img"
    aria-label="Colour wheel showing where each colour in the scheme sits">${ring}${dots}</svg>`;
}

/* ===========================================================================
   Recipes
   =========================================================================== */
function screenRecipes(){
  if (state.openRecipe) return screenRecipeDetail();
  /* New is in the top bar, like Add on Collection and Paints. */
  let h = `<div style="height:.875rem"></div>`;
  if (!data.recipes.length)
    return h + `<div class="empty"><p>No recipes yet. A recipe is an ordered set of steps &mdash; Aged Bone,
      Oxidised Copper &mdash; that you can attach to as many models as you like.</p>
      <button class="btn" data-act="newRecipe">Create one</button></div>`;
  data.recipes.forEach(r => {
    const used = data.links.filter(l => l.recipeId === r.id).length;
    h += `<button class="card" data-openrecipe="${esc(r.id)}" style="width:100%;text-align:left;cursor:pointer;display:block">
      <b class="user-text">${esc(r.title)}</b>
      <span class="small muted" style="display:block">${arr(r.steps).length} step${arr(r.steps).length===1?'':'s'}${r.category?' · '+esc(r.category):''}${used?` · on ${used} model${used>1?'s':''}`:''}</span></button>`;
  });
  return h;
}

function screenRecipeDetail(){
  const r = data.recipes.find(x => x.id === state.openRecipe);
  if (!r) return `<div class="empty"><p>That recipe no longer exists.</p>
    <button class="btn" data-back="recipes">Back to recipes</button></div>`;
  const used = data.links.filter(l => l.recipeId === r.id);
  let h = backBtn('recipes','Recipes');
  h += `<h2 class="display user-text" style="font-size:1.625rem">${esc(r.title)}</h2>`;
  if (r.category) h += `<p class="muted" style="margin-top:-.25rem">${esc(r.category)}</p>`;
  if (used.length) h += `<p class="small muted">Used on <b>${used.length}</b> model${used.length>1?'s':''}.
    Editing it changes all of them.</p>`;

  h += `<div class="card"><div class="row spread"><h3 style="margin:0">Steps</h3>
    <button class="btn sm ghost" data-act="addStep">Add step</button></div>`;
  if (!arr(r.steps).length) h += `<p class="small muted">No steps yet.</p>`;
  arr(r.steps).forEach((s,i) => {
    const names = arr(s.paintIds).map(id => { const p = paintOf(id); return p ? p.name : null; }).filter(Boolean);
    h += `<div class="row" style="padding:.625rem 0;border-top:1px solid var(--border);align-items:flex-start">
      <span class="num" style="min-width:1.5rem;color:var(--text-2)">${i+1}</span>
      <span class="grow"><b class="user-text">${esc(s.technique||'Step')}</b>
        ${names.length?`<span class="small" style="display:block">${esc(names.join(' + '))}${s.mix?' · '+esc(s.mix):''}</span>`:''}
        ${s.notes?`<span class="small muted user-text" style="display:block">${esc(s.notes)}</span>`:''}
        ${s.dry?`<span class="small muted" style="display:block">Leave ${esc(s.dry)}</span>`:''}</span>
      <button class="iconbtn" data-delstep="${esc(s.id)}" aria-label="Delete step">&times;</button></div>`;
  });
  h += `</div>`;

  h += `<div class="card"><h3>Details</h3>
    <label for="rTitle">Name</label><input id="rTitle" value="${esc(r.title)}">
    <label for="rCat">Category</label><input id="rCat" value="${esc(r.category||'')}" placeholder="bone, flesh, metal, cloth">
    <label for="rDesc">Notes</label><textarea id="rDesc" class="user-text">${esc(r.desc||'')}</textarea>
    <div class="row" style="margin-top:.875rem"><button class="btn" data-act="saveRecipe">Save changes</button>
    <button class="btn danger" data-act="delRecipe">Delete</button></div></div>`;
  return h;
}

/* ===========================================================================
   Render
   =========================================================================== */
const TITLES = { home:'MiniManager', coll:'Collection', paints:'Paints', recipes:'Recipes' };

/* The one thing you most often do on each list screen, in the top bar beside
   its title. Detail screens and the setup flow have their own buttons. */
function headerAction(){
  if (state.setup.step) return '';
  if (state.tab === 'coll' && !state.openMini && data.minis.length)
    return `<button class="btn sm" data-act="addHere">Add</button>`;
  if (state.tab === 'paints' && !state.sub && !state.openPaint && data.paints.length)
    return `<button class="btn sm" data-act="addPaint">Add</button>`;
  if (state.tab === 'recipes' && !state.openRecipe && data.recipes.length)
    return `<button class="btn sm" data-act="newRecipe">New</button>`;
  return '';
}

function render(){
  const app = $('#app');
  const nav = document.querySelector('nav.tabs');
  const bar = document.querySelector('header.bar');

  /* Before sign-in there is nothing to navigate, so the tabs and the header
     buttons go away rather than sitting there doing nothing. */
  if (authGate !== 'in'){
    app.innerHTML = authGate === 'loading' ? screenLoading()
                  : (state.tab === 'privacy' ? screenPrivacy('home', 'Sign in') : screenSignIn());
    if (nav) nav.hidden = true;
    if (bar) bar.classList.add('gated');
    $('#screenTitle').textContent = 'MiniManager';
    return;
  }
  if (nav) nav.hidden = false;
  if (bar) bar.classList.remove('gated');

  let html;
  if (state.setup.step)              html = screenSetup();
  else if (state.tab === 'account')  html = screenAccount();
  else if (state.tab === 'privacy')  html = screenPrivacy('home');
  else if (state.tab === 'pick')     html = screenPick();
  else if (state.tab === 'shop')     html = screenShop();
  else if (state.tab === 'home')     html = screenHome();
  else if (state.tab === 'coll')     html = state.openMini ? screenMini() : screenCollection();
  else if (state.tab === 'paints')   html = screenPaints();
  else                               html = screenRecipes();
  app.innerHTML = html;
  $('#screenTitle').textContent = state.tab === 'coll' ? collTitle() : (TITLES[state.tab] || 'MiniManager');
  $$('#tabs button').forEach(b => {
    if (b.dataset.tab === state.tab) b.setAttribute('aria-current','page');
    else b.removeAttribute('aria-current');
  });
  const slot = document.getElementById('syncslot');
  if (slot){ slot.innerHTML = ''; slot.appendChild(syncPill()); }
  const actslot = document.getElementById('actslot');
  if (actslot) actslot.innerHTML = headerAction();
  refreshFilterSheet();
  hydratePhotos();
  /* Last, and guarded so it can only ever fire once: it renders again. */
  maybeStartSetup();
}

/* ===========================================================================
   The shop

   Need and Want are the same moment — you are standing in a shop with one
   phone — so they are one screen with two sides. Need writes itself from the
   stock states you already set while painting; you never maintain it.
   =========================================================================== */
const SHOP_LOW = ['Running low','Out'];

function needList(){
  const paints = arr(data.paints).filter(p => SHOP_LOW.indexOf(p.stock) !== -1);
  const supplies = arr(data.supplies).filter(s => SHOP_LOW.indexOf(s.stock) !== -1);
  return { paints, supplies, total: paints.length + supplies.length };
}

function screenShop(){
  const need = needList();
  const want = arr(data.wishlist);
  const tab = state.shopTab;

  let h = `${backBtn('home','Home')}
    <h2 class="display" style="font-size:1.5rem;margin:0 0 .5rem">Shopping</h2>
    <div class="tabs2" role="tablist">
      <button role="tab" data-shop="need" aria-selected="${tab==='need'}">Need
        ${need.total?`<span class="n">${need.total}</span>`:''}</button>
      <button role="tab" data-shop="want" aria-selected="${tab==='want'}">Want
        ${want.length?`<span class="n">${want.length}</span>`:''}</button>
    </div>`;

  if (tab === 'need'){
    if (!need.total){
      h += `<div class="empty"><p>Nothing to buy. Mark a paint <b>Running low</b> or
        <b>Out</b> while you&rsquo;re painting and it turns up here by itself.</p>
        <button class="btn ghost" data-act="addSupply">Add a supply</button></div>`;
      return h;
    }
    if (need.paints.length){
      h += `<p class="grouphead">Paints</p>`;
      need.paints.forEach(p => { h += shopRow(p, 'paint'); });
    }
    if (need.supplies.length){
      h += `<p class="grouphead">Supplies</p>`;
      need.supplies.forEach(s => { h += shopRow(s, 'supply'); });
    }
    const n = Object.keys(state.ticked || {}).filter(k => state.ticked[k]).length;
    h += `<div class="row"><button class="btn ghost" data-act="addSupply">Add a supply</button></div>`;
    if (n) h += `<div class="row"><button class="btn" data-act="restock">
      I bought these &mdash; mark <span class="num">${n}</span> back in stock</button></div>`;
    h += `<p class="small muted" style="margin-top:.75rem">Ticking crosses something off for
      this trip. Nothing changes in your paints until you press the button above &mdash;
      standing in a shop and what&rsquo;s actually in your cupboard are different things.</p>`;
    return h;
  }

  if (!want.length){
    h += `<div class="empty"><p>Nothing on the wishlist. Add the things you fancy next
      &mdash; models, paints, anything.</p>
      <button class="btn" data-act="addWish">Add something</button></div>`;
    return h;
  }
  const groups = [['model','Models'],['paint','Paints'],['supply','Supplies'],['other','Anything else']];
  groups.forEach(g => {
    const items = want.filter(w => (w.kind || 'other') === g[0]);
    if (!items.length) return;
    h += `<p class="grouphead">${esc(g[1])}</p>`;
    items.forEach(w => { h += wishRow(w); });
  });
  h += `<div class="row"><button class="btn ghost" data-act="addWish">Add something</button></div>`;
  return h;
}

function shopRow(item, kind){
  const got = !!(state.ticked && state.ticked[item.id]);
  /* Paints get their real colour as a drop; supplies and any paint without a
     photographed colour get a hollow one. An invented colour is never shown. */
  const sw = dropSvg('shopdrop', kind === 'paint' && item.hex ? esc(item.hex) : '');
  const sub = kind === 'paint'
    ? [item.brand, item.range].filter(Boolean).join(' · ')
    : (item.note || '');
  return `<div class="shoprow${got?' got':''}">
    <button class="tick" data-tick="${esc(item.id)}" aria-pressed="${got}"
      aria-label="${got?'Put back on the list':'Got it'}: ${esc(item.name)}">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13 L10 18 L19 6" fill="none"
        stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>${sw}
    <span class="nm"><b class="user-text">${esc(item.name)}</b>
      ${sub?`<span class="user-text">${esc(sub)}</span>`:''}</span>
    <span class="pill${item.stock==='Out'?' out':''}">${item.stock==='Out'?'Out':'Low'}</span>
  </div>`;
}

function wishRow(w){
  const got = !!(state.ticked && state.ticked[w.id]);
  const bits = [];
  if (w.note) bits.push(w.note);
  if (w.price != null && w.price !== '') bits.push('around ' + money(w.price));
  return `<div class="shoprow${got?' got':''}">
    <button class="tick" data-tick="${esc(w.id)}" aria-pressed="${got}"
      aria-label="${got?'Untick':'Got it'}: ${esc(w.name)}">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13 L10 18 L19 6" fill="none"
        stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
    <span class="nm"><b class="user-text">${esc(w.name)}</b>
      ${bits.length?`<span class="user-text">${esc(bits.join(' · '))}</span>`:''}</span>
    <button class="iconbtn" data-delwish="${esc(w.id)}" aria-label="Remove ${esc(w.name)} from the wishlist">&times;</button>
  </div>`;
}

function dlgAddSupply(){
  openDialog('Add a supply',
    `<p class="small muted" style="margin:0 0 .5rem">Glue, brushes, files, basing grit &mdash;
      anything that isn&rsquo;t a paint but still runs out.</p>
     <label for="suName">What is it?</label>
     <input id="suName" placeholder="Plastic glue" autocomplete="off">
     <label for="suNote">Note <span class="opt">optional</span></label>
     <input id="suNote" placeholder="Thin, the one with the needle">
     ${chips('suStock', ['Have it','Running low','Out'], { label:'How are you for it?',
        value:'Running low', noOwn:true })}`,
    () => {
      const n = $('#suName').value.trim();
      if (!n){ toast(NAME_REQUIRED); return false; }
      data.supplies.push({ id:uid(), name:n, note:$('#suNote').value.trim(),
        stock:$('#suStock').value || 'Have it', created:Date.now(), updated:Date.now() });
      save(); render(); toast('Supply added.');
    }, 'Add');
}

function dlgAddWish(){
  openDialog('Add to the wishlist',
    `<label for="wName">What do you want?</label>
     <input id="wName" placeholder="Sons of Behemat — Mega-Gargant" autocomplete="off">
     ${chips('wKind', ['Model','Paint','Supply','Anything else'],
        { label:'What sort of thing?', value:'Model', noOwn:true })}
     <label for="wNote">Note <span class="opt">optional</span></label>
     <input id="wNote" placeholder="Age of Sigmar">
     <label for="wPrice">Roughly what it costs <span class="opt">optional</span></label>
     <input id="wPrice" type="number" min="0" step="0.01" inputmode="decimal">`,
    () => {
      const n = $('#wName').value.trim();
      if (!n){ toast(NAME_REQUIRED); return false; }
      const k = ($('#wKind').value || 'Model').toLowerCase();
      data.wishlist.push({ id:uid(), name:n,
        kind: k.indexOf('model') === 0 ? 'model' : k.indexOf('paint') === 0 ? 'paint'
            : k.indexOf('supply') === 0 ? 'supply' : 'other',
        note:$('#wNote').value.trim(),
        price: $('#wPrice').value === '' ? null : Math.max(0, Number($('#wPrice').value) || 0),
        created:Date.now(), updated:Date.now() });
      save(); render(); toast('Added to the wishlist.');
    }, 'Add');
}

/* Only now does anything actually change. Ticking in a shop and what is in
   your cupboard are different facts, and guessing would corrupt the list you
   rely on next trip. */
function restock(){
  const ids = Object.keys(state.ticked || {}).filter(k => state.ticked[k]);
  if (!ids.length) return;
  let n = 0;
  ids.forEach(id => {
    const p = arr(data.paints).find(x => x.id === id);
    if (p){ p.stock = 'Have it'; p.updated = Date.now(); n++; return; }
    const s = arr(data.supplies).find(x => x.id === id);
    if (s){ s.stock = 'Have it'; s.updated = Date.now(); n++; }
  });
  state.ticked = {};
  save(); render();
  toast(n + (n === 1 ? ' item' : ' items') + ' marked back in stock.');
}

/* ===========================================================================
   Pick something for me

   The real problem is not randomness, it is standing in front of a shelf
   unable to choose. So the important button is "Not that one", and the whole
   thing is built to be pressed repeatedly: under 700ms a go, and it never
   offers the same entry twice running.
   =========================================================================== */
function pickPool(){
  const p = state.pick, lastStage = data.stages[data.stages.length - 1];
  return arr(data.minis).filter(m => {
    if (m.stage === lastStage) return false;            /* already done */
    if (p.kind === 'build' && m.stage !== data.stages[0]) return false;
    if (p.kind === 'paint' && m.stage === data.stages[0]) return false;
    if (p.opts.quick && (Number(m.total) || 1) > 5) return false;
    if (p.opts.sys && m.sys !== p.opts.sys) return false;
    return true;
  });
}

function screenPick(){
  const p = state.pick;
  const withMinis = {};
  arr(data.minis).forEach(m => { if (m.sys) withMinis[m.sys] = true; });
  const systems = arr(data.systems).filter(s => withMinis[s.id]);

  let h = `${backBtn('home','Home')}
    <h2 class="display" style="font-size:1.5rem">What should I do next?</h2>
    <div class="chips">
      <button class="chip" data-pk="build" aria-pressed="${p.kind==='build'}">To build</button>
      <button class="chip" data-pk="paint" aria-pressed="${p.kind==='paint'}">To paint</button>
      <button class="chip" data-pk="either" aria-pressed="${p.kind==='either'}">Either</button>
    </div>
    <div class="chips" style="margin-top:.5rem">
      <button class="chip" data-po="old" aria-pressed="${!!p.opts.old}">Favour the oldest</button>
      <button class="chip" data-po="quick" aria-pressed="${!!p.opts.quick}">Something quick</button>
    </div>`;

  if (systems.length > 1){
    h += `<label for="pkSys" style="margin-top:.875rem">Only from</label>
      <select id="pkSys"><option value="">Any game system</option>
        ${systems.map(s => `<option value="${esc(s.id)}"${p.opts.sys===s.id?' selected':''}>${esc(s.name)}</option>`).join('')}
      </select>`;
  }

  const pool = pickPool();
  h += `<div class="picker" id="picker">
    <div class="pickface" id="pickface">`;
  if (p.result){
    h += pickFaceHtml(p.result);
  } else if (!pool.length){
    h += `<p class="pickidle">Nothing matches that. Loosen one of the choices above.</p>`;
  } else {
    h += `<p class="pickidle">Press the button and I&rsquo;ll choose from your
      <span class="num">${pool.length}</span>.</p>`;
  }
  h += `</div></div>
    <div class="row"><button class="btn wide" data-act="doPick"${pool.length?'':' disabled'}>
      ${p.result ? 'Pick again' : 'Pick one for me'}</button></div>`;
  if (p.result){
    h += `<div class="row">
      <button class="btn ghost" data-act="doPick">Not that one</button>
      <button class="btn ghost" data-act="openPicked">Open this</button></div>`;
  }
  return h;
}

function pickFaceHtml(m){
  const sub = [sysName(m.sys), facName(m.fac)].filter(Boolean).join(' · ');
  const n = Number(m.total) || 1;
  const bits = [n + (n === 1 ? ' model' : ' models')];
  if (m.acquired) bits.push('waiting ' + waitedFor(m.acquired));
  bits.push(m.stage);
  return `<div><p class="pickname user-text">${esc(m.name)}</p>
    ${sub ? `<p class="picksub user-text">${esc(sub)}</p>` : ''}
    <p class="pickmeta">${esc(bits.join(' · '))}</p></div>`;
}

/* The flick. Three names go past, decelerating, then the chosen one settles.
   Deliberately not a spinning reel: a reel is slow, and it implies the app is
   doing something cleverer than picking at random. */
function runPick(){
  const p = state.pick;
  const pool = pickPool();
  const face = $('#pickface');
  if (!pool.length || !face) return;

  const choices = pool.length > 1 ? pool.filter(m => m.id !== p.last) : pool;
  let winner;
  if (p.opts.old){
    const dated = choices.filter(m => m.acquired);
    winner = dated.length
      ? dated.sort((a,b) => monthsSince(b.acquired) - monthsSince(a.acquired))[0]
      : choices[Math.floor(Math.random() * choices.length)];
  } else {
    winner = choices[Math.floor(Math.random() * choices.length)];
  }

  const settle = () => {
    p.result = winner; p.last = winner.id;
    render();
    const f = $('#pickface');
    if (f && !reducedMotion()){ f.classList.remove('land'); void f.offsetWidth; f.classList.add('land'); }
  };

  if (reducedMotion() || pool.length < 2){ settle(); return; }

  face.classList.add('flick');
  [0, 110, 210].forEach(d => setTimeout(() => {
    const f = $('#pickface');
    if (f) f.innerHTML = pickFaceHtml(pool[Math.floor(Math.random() * pool.length)]);
  }, d));
  setTimeout(() => {
    const f = $('#pickface');
    if (f) f.classList.remove('flick');
    settle();
  }, 330);
}
function reducedMotion(){
  try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
  catch (e) { return false; }
}

/* ---------------------------------------------------------------------------
   Moving a model along its stages.

   This is the most-used action in the app and, until now, the flattest: the
   screen was rebuilt from scratch on every tap, so the bar jumped to its new
   width and the tick simply existed. Updating in place gives the transitions
   something to travel from.
--------------------------------------------------------------------------- */

/* The single place a stage changes, reached from both the big button and the
   ladder. Having two copies of this was how the "finished" flag and the
   celebration could drift apart. */
function setStage(m, stage){
  const wasFinished = isFinished(m);
  m.stage = stage;
  /* Finished means every model in the entry is finished, so the count says
     so too. Before v015 a ten-model unit could sit at Finished with 0 of 10
     counted, and every total under-reported. Leaving Finished again after
     everything was counted done resets the count, since they are not. */
  const n = Number(m.total) || 1;
  if (isDone(m)) m.done = n;
  else if (wasFinished && (Number(m.done)||0) >= n) m.done = 0;
  m.updated = Date.now(); save();
  advanceStrip(m, !wasFinished && isFinished(m));
}

function advanceStrip(m, justFinished){
  const vessel = document.querySelector('.vessel');
  if (!vessel){ render(); return; }

  const idx = data.stages.indexOf(m.stage);
  const last = data.stages.length - 1;
  const p = last ? idx / last : 1;
  const done = isFinished(m);

  /* The paint level. This is the one thing on screen that must travel, because
     the height of the paint IS the information. */
  const lvl = vessel.querySelector('.potfill');
  if (lvl) lvl.style.transform = `translateY(${(DROP_BOT - 80 - DROP_H * p).toFixed(1)}px)`;
  vessel.classList.toggle('full', done);

  const nameEl = vessel.querySelector('.stagename');
  if (nameEl) nameEl.textContent = m.stage;
  const subEl = vessel.querySelector('.vsub');
  if (subEl) subEl.innerHTML =
    `Stage <span class="num">${idx+1}</span> of <span class="num">${last+1}</span>` +
    (done ? '' : ' &middot; ' + potWord(p));

  /* The big button names the next stage, so it has to be relabelled — and at
     the end there is no next stage, so it goes away entirely. */
  const adv = document.querySelector('.advance');
  if (adv){
    if (idx >= last) adv.remove();
    else adv.innerHTML = `Move to ${esc(data.stages[idx+1])} &rarr;`;
  }

  /* The ladder is usually shut, but if it is open you are looking straight at
     it, so it cannot sit stale for half a second. */
  document.querySelectorAll('.lrow').forEach((el, i) => {
    const st = i < idx ? 'done' : (i === idx ? 'now' : 'todo');
    el.dataset.s = st;
    const path = el.querySelector('.ldrop path');
    if (path){
      if (st === 'todo'){
        path.setAttribute('fill','none');
        path.setAttribute('stroke','var(--warm-grey)');
        path.setAttribute('stroke-width','9');
      } else {
        path.setAttribute('fill', st === 'done' ? 'var(--success)' : 'var(--gold)');
        path.removeAttribute('stroke'); path.removeAttribute('stroke-width');
      }
    }
    const want = st === 'done' ? 'Done' : st === 'now' ? 'You are here' : '';
    let tag = el.querySelector('.ltag');
    if (want && !tag){ tag = document.createElement('span'); tag.className = 'ltag'; el.appendChild(tag); }
    if (tag){ if (!want) tag.remove(); else tag.textContent = want; }
  });

  const card = vessel.closest('.card');
  if (card) card.classList.toggle('finished', done);
  const fin = document.querySelector('.finmark');
  if (fin) fin.classList.toggle('on', done);

  if (justFinished) celebrate(card);

  /* Everything else on the screen still needs the new numbers, but only
     after the motion has had its moment. */
  clearTimeout(advanceStrip._t);
  advanceStrip._t = setTimeout(() => {
    if (state.tab === 'coll' && state.openMini === m.id) render();
  }, justFinished ? 1700 : 420);
}

/* Option B: a large tick draws itself across the card, then clears.
   Pointer-events are off throughout so it can never swallow a tap. */
function celebrate(card){
  if (!card || card.querySelector('.celebrate')) return;
  const el = document.createElement('div');
  el.className = 'celebrate';
  el.setAttribute('aria-hidden', 'true');
  el.innerHTML = `<svg viewBox="0 0 48 48"><path d="M10 25 L20 35 L38 14"/></svg>`;
  card.appendChild(el);
  if (reducedMotion()){
    el.classList.add('still');
    setTimeout(() => el.remove(), 1200);
  } else {
    el.classList.add('go');
    setTimeout(() => el.remove(), 1600);
  }
}

/* ===========================================================================
   The sign-in gate

   Signing in is required in this app, which means the gate is the first
   thing a new person meets. Two things it must do: say what it is going to
   do with their data BEFORE they hand any over, and never trap somebody who
   is offline but has signed in before.
   =========================================================================== */
let authGate = 'loading';   /* loading | out | in */
let authBusy = false;

function screenSignIn(){
  const err = syncState.error;
  return `<div class="gate">
    <div class="gatecard">
      <h2 class="display">Your collection. Your colours. Your progress.</h2>
      <p>MiniManager keeps your miniatures, your paints and your swatch
         photographs in step across your phone and your computer.</p>
      <p class="small muted">You need a Google account because everything you
         add is stored against it. Nothing is shared with anyone, and nobody
         else can see it &mdash; not even me.</p>
      ${err ? `<p class="gateerr" role="alert">${esc(err)}</p>` : ''}
      <button class="btn big" data-act="signin"${authBusy ? ' disabled' : ''}>
        ${authBusy ? 'Opening Google…' : 'Continue with Google'}</button>
      <p class="small muted" style="margin-top:1rem">
        Before you do, here is exactly what gets stored and where:
        <button class="linkbtn" data-act="privacy">what MiniManager keeps</button>.
      </p>
    </div>
  </div>`;
}

function screenLoading(){
  return `<div class="gate"><div class="gatecard">
    <p class="muted" role="status">Checking whether you are signed in…</p>
  </div></div>`;
}

/* The privacy notice. This is not boilerplate: sign-in is required, so Joe
   is holding other people's data, and they are owed a plain account of it
   before they hand it over rather than afterwards. */
function screenPrivacy(back, label){
  /* Always a way out. Reached from the sign-in screen this used to render
     with no back button AND no tab bar, because the tab bar is hidden until
     you are signed in — so reading the privacy notice before handing over
     your data left you with nothing but a page reload. Asking someone to
     read this and then trapping them in it is the worst possible place for
     a dead end. */
  return `${backBtn(back || 'home', label || 'Back')}
  <h2 class="display" style="font-size:1.5rem">What MiniManager keeps</h2>
  <div class="card">
    <h3>What is stored</h3>
    <p>The things you put in: your miniatures and their progress, the paints
       you own, your recipes, and the photographs you take of swatches and
       models. Your name and email address come from your Google account so
       the app knows which collection is yours.</p>
    <h3>Where it is stored</h3>
    <p>Your collection is held in Google Firebase. The text &mdash; miniatures,
       paints, recipes &mdash; is stored in <b>London</b>. Your
       <b>photographs are stored in the United States</b>, because that is
       where the free storage allowance sits.</p>
    <h3>Who can see it</h3>
    <p>Only you. The rules that enforce this run on Google's servers, not in
       this app, so they cannot be worked around from a browser. Nobody else
       signing in can reach your data, and neither can the person who built
       this.</p>
    <h3>What is never collected</h3>
    <p>There is no analytics, no tracking, no advertising and no third party
       watching what you do here. The app does not know how often you open it.</p>
    <h3>Getting it back, or getting rid of it</h3>
    <p>Export everything to a file at any time from the <b>&hellip;</b> menu.
       Delete your account from the same place and it goes properly: your
       collection, every photograph, the copy on this device, and the account
       itself. That cannot be undone and there is no backup to restore from.</p>
    <h3>Who is responsible</h3>
    <p>MiniManager is run by one person as a hobby project. Questions, or a
       request to see or delete your data, go to the email address shown on
       the Google sign-in screen.</p>
    <p class="small muted">Last updated 12 October 2026.</p>
  </div>`;
}

/* --- the account screen ---------------------------------------------------- */
function screenAccount(){
  const u = syncState.user;
  return `${backBtn('home','Home')}
  <h2 class="display" style="font-size:1.5rem">Your account</h2>
  <div class="card">
    <p style="margin:0"><b>${esc((u && (u.displayName || u.email)) || 'Signed in')}</b></p>
    ${u && u.email ? `<p class="small muted user-text" style="margin:.25rem 0 0">${esc(u.email)}</p>` : ''}
    <p class="small muted" style="margin:.75rem 0 0">
      ${syncState.status === 'ok' ? 'Everything is saved to your account.'
      : syncState.status === 'syncing' ? 'Saving to your account…'
      : syncState.status === 'offline' ? 'No connection. Changes are saved on this device and will go up when you are back online.'
      : syncState.error ? esc(syncState.error) : ''}</p>
    <div class="row" style="margin-top:1rem">
      <button class="btn ghost" data-act="signout">Sign out</button>
    </div>
    <p class="small muted" style="margin:.5rem 0 0">Signing out leaves your
      collection in your account. It does not delete anything.</p>
  </div>
  <div class="card">
    <h3>Currency</h3>
    <p class="small muted" style="margin:0 0 .25rem">Used wherever the app shows a price:
      what a model cost, your collection value, wishlist estimates.</p>
    <label for="setCurrency">Show prices in</label>
    <select id="setCurrency">
      ${CURRENCIES.map(c => `<option value="${esc(c[0])}"${
        (data.settings.currency||'GBP') === c[0] ? ' selected' : ''
      }>${esc(c[1])} &mdash; ${esc(c[0])}</option>`).join('')}
    </select>
    <p class="small muted" style="margin:.5rem 0 0">Changing this does not convert anything.
      The numbers you typed stay exactly as they are &mdash; only the symbol in front of
      them changes. Example: <b class="num">${esc(money(32.5))}</b></p>
  </div>
  <div class="card danger">
    <h3>Delete your account</h3>
    <p class="small">This removes your collection, every photograph you have
      taken, the copy stored on this device, and the account itself.
      <b>It cannot be undone</b>, and there is no backup to restore from.</p>
    <p class="small muted">Export your collection first if there is any chance
      you will want it.</p>
    <div class="row">
      <button class="btn ghost" data-act="exportFirst">Export everything first</button>
      <button class="btn danger" data-act="deleteAccount">Delete my account</button>
    </div>
  </div>`;
}

/* Deliberately awkward. A destructive, unrecoverable action should take more
   than one tap, and the person should have to demonstrate they read it. */
function dlgDeleteAccount(){
  openDialog('Delete your account',
    `<p>This will permanently delete:</p>
     <ul class="tight">
       <li>every miniature, paint and recipe in your collection</li>
       <li>every photograph you have taken, including your swatches</li>
       <li>the copy stored on this device</li>
       <li>your MiniManager account itself</li>
     </ul>
     <p><b>There is no backup and this cannot be undone.</b></p>
     <label for="delConfirm">Type <b>DELETE</b> to confirm</label>
     <input id="delConfirm" autocomplete="off" autocapitalize="characters">
     <p id="delProgress" class="small muted" role="status" style="margin-top:.75rem"></p>`,
    () => {
      if ($('#delConfirm').value.trim().toUpperCase() !== 'DELETE'){
        toast('Type DELETE to confirm.'); return false;
      }
      const p = $('#delProgress');
      const say = m => { if (p) p.textContent = m; };
      $$('[data-dlg]').forEach(b => b.disabled = true);
      deleteEverything(say).then(() => {
        location.reload();
      }).catch(err => {
        $$('[data-dlg]').forEach(b => b.disabled = false);
        say('');
        toast('Could not finish deleting: ' + (err.message || 'unknown problem'));
      });
      return false;   /* stay open and show progress */
    }, 'Delete everything');
}

/* ===========================================================================
   Dialogs
   =========================================================================== */
function openDialog(title, body, onOk, okLabel, cancelLabel){
  /* The close lives in a pinned header, not only at the foot. A long dialog
     — the "More" menu runs to the full MIT licence — otherwise hides its
     only way out below everything else. */
  $('#dlgBody').innerHTML = `
    <div class="dlghead"><h2>${esc(title)}</h2>
      <button class="iconbtn" data-dlg="cancel" aria-label="Close">&times;</button></div>
    ${body}
    <div class="row" style="margin-top:1rem;justify-content:flex-end">
      <button class="btn ghost" data-dlg="cancel">${esc(cancelLabel||'Cancel')}</button>
      ${onOk ? `<button class="btn" data-dlg="ok">${esc(okLabel||'Save')}</button>` : ''}</div>`;
  const dlg = $('#dlg');
  /* One dialog follows another (Restore asks from inside the menu), and
     opening an already-open dialog throws. */
  if (!dlg.open) dlg.showModal();
  dlg.onclick = e => {
    const b = e.target.closest('[data-dlg]');
    if (!b) return;
    if (b.dataset.dlg === 'cancel'){ closeSheet(dlg); return; }
    /* A dialog with nothing to confirm — the menu — has no onOk at all. */
    if (!onOk || onOk() !== false) closeSheet(dlg);
  };
}
const NAME_REQUIRED = 'Give it a name first.';

/* ---------------------------------------------------------------------------
   Small reusable form pieces.

   Two ideas do most of the work here. A "?" opens its answer in the flow of
   the form rather than as a tooltip, because a tooltip on a phone is a thing
   you cannot read. And a row of chips writes into a hidden input, so every
   save path below still reads one value by id exactly as it always did.
--------------------------------------------------------------------------- */
let helpSeq = 0;

function helpBlock(key){
  const h = key && HELP[key];
  if (!h) return { btn:'', panel:'' };
  const id = 'hlp' + (++helpSeq);
  let inner = '';
  if (h.p) inner += h.p.map(x => `<p>${esc(x)}</p>`).join('');
  if (h.dl) inner += '<dl>' + h.dl.map(r => `<dt>${esc(r[0])}</dt><dd>${esc(r[1])}</dd>`).join('') + '</dl>';
  if (h.table) inner += '<table class="helptbl"><tbody>' +
    h.table.map(r => `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td></tr>`).join('') + '</tbody></table>';
  return {
    btn: `<button class="q" type="button" data-help="${id}" aria-expanded="false"
            aria-controls="${id}" aria-label="${esc(h.title)}">?</button>`,
    /* Three nested elements so the answer can grow into place: the outer one
       animates grid-template-rows 0fr -> 1fr, which is how you transition to
       an unknown height, and the middle one clips while it does. */
    panel: `<div class="helpwrap" id="${id}"><div><div class="help">
              <b class="helph">${esc(h.title)}</b>${inner}</div></div></div>`
  };
}

/* A labelled control, with the explanation appearing under the control. */
function field(id, labelText, control, helpKey){
  const h = helpBlock(helpKey);
  if (!h.btn) return `<label for="${esc(id)}">${esc(labelText)}</label>${control}`;
  return `<div class="flab"><label for="${esc(id)}">${esc(labelText)}</label>${h.btn}</div>
          ${control}${h.panel}`;
}

/* Tap instead of type. Always ends with "Type my own" so nobody is locked out
   by a list I happened not to think of. */
function chips(id, items, opts){
  const o = opts || {};
  const cur = o.value || '';
  const h = helpBlock(o.help);

  /* Multi-select keeps a comma-joined string, which is what tags already are,
     so nothing downstream has to change. */
  const picked = o.multi ? cur.split(',').map(s => s.trim()).filter(Boolean) : (cur ? [cur] : []);
  const extra = picked.filter(p => items.indexOf(p) === -1);
  const own = extra.length > 0;
  const on = v => picked.indexOf(v) !== -1;

  return `<div class="flab"><span class="clab" id="${esc(id)}lab">${esc(o.label || '')}</span>${h.btn}</div>
    <div class="chipwrap" data-chipwrap${o.multi ? ' data-multi' : ''}>
      <input type="hidden" id="${esc(id)}" value="${esc(cur)}">
      <div class="chips" role="group" aria-labelledby="${esc(id)}lab">
        ${items.map(i => `<button class="chip" type="button" data-val="${esc(i)}"
            aria-pressed="${on(i) ? 'true' : 'false'}">${esc(i)}</button>`).join('')}
        ${o.noOwn ? '' : `<button class="chip" type="button" data-own="1"
            aria-pressed="${own ? 'true' : 'false'}">Type my own</button>`}
      </div>
      <div class="ownwrap${own ? ' open' : ''}"><div>
        <input class="chipown" type="text" placeholder="${esc(o.ownPlaceholder || 'Type it here')}"
          value="${esc(extra.join(', '))}">
      </div></div>
    </div>${h.panel}`;
}

/* Rebuild the stored value from whatever is currently pressed. */
function syncChips(wrap){
  const hidden = wrap.querySelector('input[type="hidden"]');
  const own = wrap.querySelector('.chipown');
  const vals = [];
  wrap.querySelectorAll('.chip[data-val][aria-pressed="true"]')
      .forEach(c => vals.push(c.dataset.val));
  const ownBox = own.closest('.ownwrap');
  if (ownBox && ownBox.classList.contains('open'))
    own.value.split(',').map(s => s.trim()).filter(Boolean)
      .forEach(v => { if (vals.indexOf(v) === -1) vals.push(v); });
  hidden.value = vals.join(wrap.hasAttribute('data-multi') ? ', ' : '');
}

/* --- system and army pickers ----------------------------------------------
   Lists are built from the presets merged with whatever the person has
   already created, so a custom system behaves exactly like a built-in one. */
function systemNames(){
  const out = SYSTEMS.map(s => s.name);
  arr(data.systems).forEach(s => { if (s.name && out.indexOf(s.name) === -1) out.push(s.name); });
  return out;
}
function presetArmies(sysName){
  const s = SYSTEMS.find(x => x.name === sysName);
  return s ? s.groups : [];
}
function armyOptions(sysName, current){
  const groups = presetArmies(sysName).slice();
  /* Armies this person already made for this system, that no preset covers. */
  const sys = arr(data.systems).find(s => s.name === sysName);
  const flat = [];
  groups.forEach(g => g.items.forEach(i => flat.push(i)));
  const mine = arr(data.factions)
    .filter(f => (!sys || f.sys === sys.id) && f.name && flat.indexOf(f.name) === -1)
    .map(f => f.name);
  if (mine.length) groups.push({ label:'Yours', items:mine });

  let h = `<option value="">Not set</option>`;
  groups.forEach(g => {
    const opts = g.items.map(i =>
      `<option value="${esc(i)}"${i === current ? ' selected' : ''}>${esc(i)}</option>`).join('');
    h += g.label ? `<optgroup label="${esc(g.label)}">${opts}</optgroup>` : opts;
  });
  h += `<option value="__own">Type my own&hellip;</option>`;
  return h;
}

/* Sixty-odd undercoats is too many for a flat list, so they group by brand. */
function undercoatOptions(sel){
  const by = {};
  arr(data.undercoats).forEach(u => { (by[u.brand || 'Yours'] = by[u.brand || 'Yours'] || []).push(u); });
  const order = ['Any','Citadel','The Army Painter','The Colour Forge','Vallejo','Scale75'];
  const names = Object.keys(by).sort((a, b) => {
    const ia = order.indexOf(a), ib = order.indexOf(b);
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib) || a.localeCompare(b);
  });
  return names.map(n => `<optgroup label="${esc(n)}">` + by[n].map(u =>
    `<option value="${esc(u.id)}"${u.id === sel ? ' selected' : ''}>${esc(u.name)}</option>`
  ).join('') + '</optgroup>').join('');
}

/* Look the record up by name, or make it. Keeps the forms free of ids. */
function systemIdByName(name){
  if (!name) return '';
  const hit = arr(data.systems).find(s => s.name === name);
  if (hit) return hit.id;
  const rec = { id:uid(), name };
  data.systems.push(rec);
  return rec.id;
}
function factionIdByName(name, sysId){
  if (!name) return '';
  const hit = arr(data.factions).find(f => f.name === name && f.sys === sysId);
  if (hit) return hit.id;
  const rec = { id:uid(), sys:sysId, name };
  data.factions.push(rec);
  return rec.id;
}

/* The last thing added, so the next twenty of the same army need the name only. */
function lastUsed(){
  try { return JSON.parse(localStorage.getItem('mm.last') || '{}') || {}; }
  catch (e) { return {}; }
}
function setLastUsed(o){
  try { localStorage.setItem('mm.last', JSON.stringify(o)); } catch (e) {}
}

function dlgAddSystem(){
  const have = arr(data.systems).map(s => s.name);
  /* Every system is listed, including the ones already on your list, marked
     and unselectable.

     This used to filter them out, which meant Warhammer 40,000 simply was not
     there once you had added it — and a game you cannot find reads as a game
     the app does not support, not as one you already have. A system is also
     created automatically the first time you add a model to it, so this could
     happen without you ever having opened this dialog. */
  const left = SYSTEMS.filter(s => have.indexOf(s.name) === -1).length;
  openDialog('Add a game system',
    `<label for="sName">Which one?</label>
     <select id="sName">
       <option value="">Pick one&hellip;</option>
       ${SYSTEMS.map(s => {
         const got = have.indexOf(s.name) !== -1;
         return `<option value="${esc(s.name)}"${got ? ' disabled' : ''}>${esc(s.name)}${
           got ? ' — already on your list' : ''}</option>`;
       }).join('')}
       <option value="__own">Type my own&hellip;</option>
     </select>
     <input id="sOwn" type="text" placeholder="Your own game" style="margin-top:.5rem" hidden>
     <p class="small muted" style="margin:.625rem 0 0">${left
       ? 'Picking one of these brings its army list with it. You can still type your own army whatever you choose.'
       : 'You already have every game system on the built-in list. Choose <b>Type my own</b> for anything else &mdash; the app has never cared which game it is.'}</p>`,
    () => {
      const sel = $('#sName').value;
      const v = sel === '__own' ? $('#sOwn').value.trim() : sel;
      if (!v){ toast('Pick a game system, or type your own.'); return false; }
      if (have.indexOf(v) !== -1){ toast('You already have that one.'); return false; }
      data.systems.push({ id:uid(), name:v }); save(); render(); toast('System added.');
    }, 'Add');
  const sel = $('#sName'), own = $('#sOwn');
  sel.addEventListener('change', () => {
    const custom = sel.value === '__own';
    own.hidden = !custom;
    if (custom) own.focus();
  });
}

/* One question. Everything else is behind "More details" and remembers what
   you picked last time, because the twentieth unit of the same army should
   not cost five answers. */
function dlgAddMini(){
  const last = lastUsed();
  const sysList = systemNames();
  const lastSys = sysList.indexOf(last.sys) !== -1 ? last.sys : '';
  const hint = lastSys
    ? `<p class="small muted" style="margin:.5rem 0 0">Will be filed under
       <b>${esc(last.fac || lastSys)}</b>. Open More details to change it.</p>`
    : '';

  openDialog('Add a miniature',
    `<label for="mName">What is it?</label>
     <input id="mName" placeholder="Skaven Clanrats" autocomplete="off">
     ${hint}
     <details class="more"><summary>More details</summary>
       <label for="mSys">Game system</label>
       <select id="mSys">
         <option value="">Not set</option>
         ${sysList.map(n => `<option value="${esc(n)}"${n === lastSys ? ' selected' : ''}>${esc(n)}</option>`).join('')}
         <option value="__own">Type my own&hellip;</option>
       </select>
       <input id="mSysOwn" type="text" placeholder="Your own game" style="margin-top:.5rem" hidden>

       <label for="mFac">Army or faction</label>
       <select id="mFac">${armyOptions(lastSys, last.fac || '')}</select>
       <input id="mFacOwn" type="text" placeholder="Your own army" style="margin-top:.5rem" hidden>

       ${chips('mUnit', UNIT_TYPES, { label:'Unit type',
         help:'unitType', ownPlaceholder:'Whatever your game calls it' })}

       ${field('mBase','Base size',
         `<select id="mBase"><option value="">Not set</option>
            ${BASE_SIZES.map(b => `<option value="${esc(b[0])}">${esc(b[0])} &mdash; ${esc(b[1])}</option>`).join('')}
          </select>`, 'baseSize')}

       <label for="mTotal">How many models</label>
       <input id="mTotal" type="number" min="1" value="1" inputmode="numeric">

       <label for="mPrice">What it cost <span class="opt">optional</span></label>
       <input id="mPrice" type="number" min="0" step="0.01" inputmode="decimal"
         placeholder="${esc(money(0).replace(/[\d.,\s]/g,''))}">
       <label for="mAcq">When you got it <span class="opt">optional</span></label>
       <input id="mAcq" type="date">
     </details>`,
    () => {
      const name = $('#mName').value.trim();
      if (!name){ toast(NAME_REQUIRED); return false; }

      const sysSel = $('#mSys').value;
      const sysName = sysSel === '__own' ? $('#mSysOwn').value.trim() : sysSel;
      const facSel = $('#mFac').value;
      const facName = facSel === '__own' ? $('#mFacOwn').value.trim() : facSel;

      const sys = systemIdByName(sysName);
      const fac = factionIdByName(facName, sys);

      data.minis.push({ id:uid(), name, sys, fac,
        base:$('#mBase').value || '',
        unit:$('#mUnit') ? $('#mUnit').value.trim() : '',
        total:Math.max(1, Number($('#mTotal').value) || 1),
        /* Both optional and both stay empty rather than zero: a price of 0
           and no price recorded are different facts, and the collection
           total must not count a guess as a real figure. */
        price: $('#mPrice').value === '' ? null : Math.max(0, Number($('#mPrice').value) || 0),
        acquired: $('#mAcq').value || '',
        done:0, stage:data.stages[0], tags:'', notes:'', photos:[],
        created:Date.now(), updated:Date.now() });
      setLastUsed({ sys:sysName, fac:facName });
      save(); state.tab='coll'; state.openMini=null; render(); toast('Added.');
    }, 'Add');

  /* Changing the system swaps the army list. A stale army from the previous
     system would quietly file the model in the wrong place, so it is cleared. */
  const sys = $('#mSys'), sysOwn = $('#mSysOwn'), fac = $('#mFac'), facOwn = $('#mFacOwn');
  const syncFacOwn = () => {
    const custom = fac.value === '__own';
    facOwn.hidden = !custom;
    if (custom) facOwn.focus();
  };
  sys.addEventListener('change', () => {
    const custom = sys.value === '__own';
    sysOwn.hidden = !custom;
    if (custom) sysOwn.focus();
    fac.innerHTML = armyOptions(custom ? '' : sys.value, '');
    facOwn.value = '';
    syncFacOwn();
  });
  fac.addEventListener('change', syncFacOwn);
  syncFacOwn();
}

/* Paint picker: searches the catalogue, falls back to a hand-typed paint. */
function dlgAddPaint(){
  openDialog('Add a paint',
    `<label for="catq">Search the catalogue</label>
     <input id="catq" type="search" placeholder="Kislev Flesh, Vallejo, 72.001" autocomplete="off">
     <div id="catres" style="margin-top:.625rem;max-height:17rem;overflow-y:auto"></div>
     <hr><p class="small muted" style="margin:0 0 .5rem">Not in there? Add your own.</p>
     <label for="ownName">Paint name</label><input id="ownName" placeholder="My mix">
     <label for="ownHex">Colour</label><input id="ownHex" type="color" value="#C6A962" style="height:3rem">`,
    () => {
      const sel = $('#catres [aria-pressed="true"]');
      if (sel){
        const row = catalogue().rows[+sel.dataset.ci];
        data.paints.push({ id:uid(), name:row.n, brand:row.b, range:row.rg, code:row.c,
          hex:row.hex, type:'', stock:'Have it', notes:'', created:Date.now() });
        save(); render(); toast('Paint added.'); return;
      }
      const n = $('#ownName').value.trim();
      if (!n){ toast('Pick one from the catalogue, or give your own a name.'); return false; }
      data.paints.push({ id:uid(), name:n, brand:'Your own', range:'', code:'',
        hex:$('#ownHex').value.toUpperCase(), type:'', stock:'Have it', notes:'', created:Date.now() });
      save(); render(); toast('Paint added.');
    }, 'Add');
  const q = $('#catq'), res = $('#catres');
  const run = () => {
    const v = q.value.trim().toLowerCase();
    if (v.length < 2){ res.innerHTML = `<p class="small muted">Type at least two letters.</p>`; return; }
    const rows = catalogue().rows;
    const hits = [];
    for (let i = 0; i < rows.length && hits.length < 40; i++){
      const r = rows[i];
      if ((r.n+' '+r.b+' '+r.rg+' '+r.c).toLowerCase().includes(v)) hits.push([i,r]);
    }
    res.innerHTML = hits.length ? hits.map(([i,r]) =>
      `<button class="paintrow" data-ci="${i}" aria-pressed="false" style="margin-bottom:.375rem">
        <span class="sw" style="background:${esc(r.hex)}"></span>
        <span class="grow"><span class="nm">${esc(r.n)}</span><br>
          <span class="br">${esc(r.b)}${r.rg?' · '+esc(r.rg):''}${r.c?' · '+esc(r.c):''}</span></span>
        <span class="tagmini">Estimated</span></button>`).join('')
      : `<p class="small muted">Nothing in the catalogue matches that.</p>`;
  };
  q.addEventListener('input', run);
  res.addEventListener('click', e => {
    const b = e.target.closest('[data-ci]'); if (!b) return;
    $$('#catres [data-ci]').forEach(x => x.setAttribute('aria-pressed','false'));
    b.setAttribute('aria-pressed','true');
  });
  run();
}

/* Camera first: the photograph happens before anything else, because it is the
   perishable half. Labelling can wait; wet paint cannot. */
function startSwatch(paintId){
  state.pending = { paintId: paintId || null };
  $('#camIn').click();
}
function dlgLabelSwatch(photoId){
  const pid = state.pending && state.pending.paintId;
  openDialog('What is this a swatch of?',
    `<div class="swatchpair"><figure style="flex:0 0 9rem">
       <img class="realswatch" data-photo="${esc(photoId)}" alt="The swatch you just photographed">
       <figcaption>Just photographed</figcaption></figure></div>
     <label for="swPaint">Paint</label><select id="swPaint">
       ${data.paints.map(p => `<option value="${esc(p.id)}"${pid===p.id?' selected':''}>${esc(p.name)} &mdash; ${esc(p.brand||'')}</option>`).join('')}</select>
     ${field('swUc','Undercoat', `<select id="swUc">${undercoatOptions()}</select>`, 'undercoat')}
     <label for="swCoats">Coats</label><input id="swCoats" type="number" min="1" value="2" inputmode="numeric">
     ${chips('swLight', CHIPS.light, { label:'Lighting', help:'swatch',
        ownPlaceholder:'Describe the light' })}
     <label for="swNotes">Notes</label><textarea id="swNotes" class="user-text"></textarea>`,
    () => {
      const paintId = $('#swPaint').value;
      if (!paintId){ toast('Add a paint first, then photograph a swatch of it.'); return false; }
      data.swatches.push({ id:uid(), paintId, undercoatId:$('#swUc').value, photoId,
        coats:Number($('#swCoats').value)||null, lighting:$('#swLight').value.trim(),
        notes:$('#swNotes').value.trim(), created:Date.now() });
      save(); render(); toast('Swatch saved.');
    }, 'Save swatch');
  hydratePhotos();
}

function dlgNewRecipe(){
  openDialog('New recipe',
    `<label for="rnTitle">Name</label><input id="rnTitle" placeholder="Aged Bone" autocomplete="off">
     ${chips('rnCat', CHIPS.category, { label:'What is it for?', ownPlaceholder:'Your own category' })}`,
    () => {
      const t = $('#rnTitle').value.trim();
      if (!t){ toast(NAME_REQUIRED); return false; }
      const r = { id:uid(), title:t, category:$('#rnCat').value.trim(), tags:'', desc:'',
                  steps:[], visibility:'private', created:Date.now() };
      data.recipes.push(r); save(); state.tab='recipes'; state.openRecipe=r.id; render(); toast('Recipe created.');
    }, 'Create');
}

function dlgAddStep(){
  const r = data.recipes.find(x => x.id === state.openRecipe); if (!r) return;
  openDialog('Add a step',
    `${chips('stTech', TECHNIQUES.map(t => t[0]), { label:'Technique', help:'technique',
        ownPlaceholder:'Your own technique' })}
     <label for="stPaint">Paint</label><select id="stPaint"><option value="">None</option>
       ${data.paints.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select>
     ${chips('stMix', CHIPS.mix, { label:'Thinned how much?', help:'thinning',
        ownPlaceholder:'e.g. 2:1 with Lahmian Medium' })}
     ${chips('stDry', CHIPS.dry, { label:'Drying time', ownPlaceholder:'How long?' })}
     <label for="stNotes">Notes</label><textarea id="stNotes" class="user-text"></textarea>`,
    () => {
      const tech = $('#stTech').value.trim();
      if (!tech){ toast('Give the step a technique.'); return false; }
      arr(r.steps); if (!Array.isArray(r.steps)) r.steps = [];
      r.steps.push({ id:uid(), technique:tech, paintIds:$('#stPaint').value?[$('#stPaint').value]:[],
        mix:$('#stMix').value.trim(), dry:$('#stDry').value.trim(), notes:$('#stNotes').value.trim() });
      save(); render(); toast('Step added.');
    }, 'Add step');
}

function dlgLinkRecipe(){
  if (!data.recipes.length){ toast('Create a recipe first.'); return; }
  openDialog('Attach a recipe',
    `<label for="lkRec">Recipe</label><select id="lkRec">
       ${data.recipes.map(r => `<option value="${esc(r.id)}">${esc(r.title)}</option>`).join('')}</select>
     ${chips('lkArea', CHIPS.area, { label:'Which part of the model?',
        ownPlaceholder:'Which part?' })}`,
    () => {
      data.links.push({ id:uid(), miniId:state.openMini, recipeId:$('#lkRec').value, area:$('#lkArea').value.trim(), notes:'' });
      save(); render(); toast('Recipe attached.');
    }, 'Attach');
}

/* ===========================================================================
   Events
   =========================================================================== */
let busy = false;

/* The "?" panels and the chip rows. Handled before anything else so a tap on
   a chip inside a dialog never reaches the dialog's own click handler. */
document.addEventListener('click', e => {
  const q = e.target.closest('.q');
  if (q){
    const panel = document.getElementById(q.dataset.help);
    if (panel){
      const opening = !panel.classList.contains('open');
      panel.classList.toggle('open', opening);
      q.setAttribute('aria-expanded', opening ? 'true' : 'false');
    }
    e.stopPropagation(); e.preventDefault(); return;
  }
  /* Only chips inside a chipwrap belong to this handler. The paint-stock
     filter and the comparison toggles are also .chip and must keep working,
     so anything outside a wrap falls straight through to the main handler. */
  const chip = e.target.closest('.chip');
  if (chip){
    const wrap = chip.closest('[data-chipwrap]');
    if (wrap){
      const own = wrap.querySelector('.chipown');
      const multi = wrap.hasAttribute('data-multi');
      const wasOn = chip.getAttribute('aria-pressed') === 'true';

      if (!multi) wrap.querySelectorAll('.chip').forEach(c => c.setAttribute('aria-pressed','false'));
      chip.setAttribute('aria-pressed', wasOn ? 'false' : 'true');

      const ownBox = own.closest('.ownwrap');
      if (chip.dataset.own){
        if (ownBox) ownBox.classList.toggle('open', !wasOn);
        if (wasOn) own.value = ''; else own.focus();
      } else if (!multi){
        if (ownBox) ownBox.classList.remove('open');
        own.value = '';
        const ownChip = wrap.querySelector('.chip[data-own]');
        if (ownChip) ownChip.setAttribute('aria-pressed','false');
      }
      syncChips(wrap);
      e.stopPropagation(); e.preventDefault();
    }
    return;
  }
}, true);

document.addEventListener('input', e => {
  if (!e.target.classList || !e.target.classList.contains('chipown')) return;
  const wrap = e.target.closest('[data-chipwrap]');
  if (wrap) syncChips(wrap);
});

document.addEventListener('click', e => {
  const t = e.target;
  const tab = t.closest('#tabs button');
  if (tab && !tab.disabled){
    state.tab = tab.dataset.tab; state.openMini = state.openPaint = state.openRecipe = null;
    state.sub = null; render(); window.scrollTo(0,0); return;
  }
  const back = t.closest('[data-back]');
  if (back){ state.openMini = state.openPaint = state.openRecipe = null; state.sub = null;
    state.tab = back.dataset.back; render(); window.scrollTo(0,0); return; }

  const open = t.closest('[data-open]');
  if (open){ const m = data.minis.find(x => x.id === open.dataset.open);
    navGo('fwd', () => { state.openMini = open.dataset.open; state.tab='coll';
      if (m){ state.openGame = m.sys || NO_SYS_ID; state.openArmy = armyKey(m); }
      render(); window.scrollTo(0,0); }); return; }
  const op = t.closest('[data-openpaint]');
  if (op){ state.openPaint = op.dataset.openpaint; state.tab='paints'; state.sub=null; render(); window.scrollTo(0,0); return; }
  const orr = t.closest('[data-openrecipe]');
  if (orr){ state.openRecipe = orr.dataset.openrecipe; state.tab='recipes'; render(); window.scrollTo(0,0); return; }

  const act = t.closest('[data-act]');
  if (act){
    const a = act.dataset.act;
    /* --- account and sign-in --- */
    if (a === 'signin'){
      if (authBusy) return;
      authBusy = true; syncState.error = null; render();
      doSignIn().catch(err => { syncState.error = friendlyAuthError(err); })
                .finally(() => { authBusy = false; render(); });
      return;
    }
    if (a === 'signout'){
      doSignOut().catch(() => {}).finally(() => { state.tab = 'home'; render(); });
      return;
    }
    /* --- getting started --- */
    if (a === 'setupStart'){ $('#dlg').close(); startSetup(); return; }
    if (a === 'setupPaintsOnly'){ $('#dlg').close(); startSetup('paints'); return; }
    if (a === 'setupSkip')  return endSetup();
    /* Finishing setup opens the army you just made, not the top of Collection. */
    if (a === 'setupGo'){ const k = state.setup.added && state.setup.added.key; endSetup('coll');
      if (k){ state.openGame = k.split('|')[0] || NO_SYS_ID; state.openArmy = k; render(); } return; }
    if (a === 'setupClearQ'){ state.setup.pq = ''; render(); return; }
    if (a === 'setupAddUnit') return setupAddUnit();
    if (a === 'setupSkipStep'){
      const s = state.setup;
      if (s.step === 2){ s.units = []; s.step = 3; }
      else { commitSetup(); s.step = 4; }
      render(); window.scrollTo(0,0); return;
    }
    if (a === 'setupNext'){
      const s = state.setup;
      if (s.step === 1){ commitSystems(); s.step = 2; }
      else if (s.step === 2){ setupAddUnit(true); s.step = 3; }
      render(); window.scrollTo(0,0); return;
    }
    if (a === 'setupFinish'){
      commitSetup();
      if (state.setup.only === 'paints'){
        const n = state.setup.added ? state.setup.added.paints : 0;
        endSetup('paints'); toast(n === 1 ? 'Paint added.' : n + ' paints added.');
      } else { state.setup.step = 4; render(); window.scrollTo(0,0); }
      return;
    }

    /* --- the new screens --- */
    if (a === 'backGames'){ navGo('back', () => { state.openGame = null; state.openArmy = null; render(); window.scrollTo(0,0); }); return; }
    if (a === 'backMini'){ navGo('back', () => { state.openMini = null; render(); window.scrollTo(0,0); }); return; }
    if (a === 'backGame'){ navGo('back', () => { state.openArmy = null; render(); window.scrollTo(0,0); }); return; }
    if (a === 'pick'){ $('#dlg').close(); state.tab = 'pick'; state.openMini = null;
      state.pick.result = null; render(); window.scrollTo(0,0); return; }
    if (a === 'shop'){ $('#dlg').close(); state.tab = 'shop'; state.openMini = null;
      render(); window.scrollTo(0,0); return; }
    if (a === 'doPick')     return runPick();
    if (a === 'openPicked'){
      if (!state.pick.result) return;
      state.openMini = state.pick.result.id; state.tab = 'coll'; render(); window.scrollTo(0,0); return;
    }
    if (a === 'addSupply')  return dlgAddSupply();
    if (a === 'addWish')    return dlgAddWish();
    if (a === 'restock')    return restock();
    if (a === 'showValue'){ state.showValue = true; render(); return; }
    if (a === 'hideValue'){ state.showValue = false; render(); return; }

    if (a === 'account'){ $('#dlg').close(); state.tab = 'account'; state.openMini = null; render(); return; }
    if (a === 'privacy'){ $('#dlg').close(); state.tab = 'privacy'; render(); return; }
    if (a === 'exportFirst') return exportData();
    if (a === 'deleteAccount') return dlgDeleteAccount();

    if (a === 'addMini')    return dlgAddMini();
    /* Add from inside a game or an army files the new model there. */
    if (a === 'addHere'){
      const sys = state.openArmy ? state.openArmy.split('|')[0] : (state.openGame && state.openGame !== NO_SYS_ID ? state.openGame : '');
      const fac = state.openArmy ? state.openArmy.split('|')[1] : '';
      if (sys) setLastUsed({ sys: sysName(sys), fac: fac ? facName(fac) : '' });
      return dlgAddMini();
    }
    if (a === 'addSys')     return dlgAddSystem();
    if (a === 'addPaint')   return dlgAddPaint();
    if (a === 'newRecipe')  return dlgNewRecipe();
    if (a === 'addStep')    return dlgAddStep();
    if (a === 'linkRecipe') return dlgLinkRecipe();
    if (a === 'saveMini')   return saveMiniEdits();
    if (a === 'delMini')    return deleteMini();
    if (a === 'savePaint')  return savePaintEdits();
    if (a === 'delPaint')   return deletePaint();
    if (a === 'saveRecipe') return saveRecipeEdits();
    if (a === 'delRecipe')  return deleteRecipe();
    if (a === 'addPhotos')  { $('#photoIn').click(); return; }
    if (a === 'newSwatch')  return startSwatch(state.openPaint);
    if (a === 'quickSwatch'){ if (!data.paints.length){ toast('Add a paint first.'); return; } return startSwatch(null); }
    if (a === 'openPlanner'){ if ($('#dlg').open) $('#dlg').close(); state.tab='paints'; state.sub='planner'; state.openPaint=null; render(); window.scrollTo(0,0); return; }
    if (a === 'openCompare'){ if ($('#dlg').open) $('#dlg').close(); state.tab='paints'; state.sub='swatchCompare'; state.openPaint=null; render(); window.scrollTo(0,0); return; }
    if (a === 'clearq')     { state.q=''; render(); return; }
    if (a === 'clearpq')    { state.pq=''; render(); return; }
    if (a === 'clearFilters'){ state.q=''; state.fSys=''; state.fFac=''; state.fStage=''; state.sort=''; render(); return; }
    if (a === 'openFilter'){ openFilterSheet('coll'); return; }
    if (a === 'openPaintFilter'){ openFilterSheet('paints'); return; }
    if (a === 'unfilter'){ const k = act.dataset.k;
      if (k==='sys'){ state.fSys=''; state.fFac=''; } else if (k==='fac') state.fFac=''; else if (k==='stage') state.fStage='';
      else if (k==='sort') state.sort=''; else if (k==='stock') state.pStock='';
      render(); return; }
    if (a === 'unfilterAll'){
      if (state.sheet === 'paints') state.pStock=''; else { state.fSys=''; state.fFac=''; state.fStage=''; state.sort=''; }
      render(); return; }
    if (a === 'themeSet'){ data.settings.theme = act.dataset.v || ''; save(); applyTheme(); refreshThemeChips(); return; }
    if (a === 'clearPaintFilters'){ state.pq=''; state.pStock=''; render(); return; }
  }

  const og = t.closest('[data-opengame]');
  if (og){ navGo('fwd', () => { state.openGame = og.dataset.opengame; state.openArmy = null; render(); window.scrollTo(0,0); }); return; }
  /* From anywhere — Home, search results — opening an army lands inside the
     Collection with its game behind it, so the way back makes sense. */
  const oa = t.closest('[data-openarmy]');
  if (oa){ const k = oa.dataset.openarmy; navGo('fwd', () => { state.tab = 'coll'; state.openMini = null;
    state.openGame = k.split('|')[0] || NO_SYS_ID; state.openArmy = k; state.q = '';
    state.fStage = ''; state.sort = ''; render(); window.scrollTo(0,0); }); return; }
  /* An empty data-astage is the "All" chip, so test for the attribute rather
     than for a truthy value — otherwise "All" would never clear the filter. */
  const as = t.closest('[data-astage]');
  if (as){ state.aStage = as.dataset.astage; render(); return; }
  /* Changing or clearing the game system drops the army, which belongs to it. */
  const fs = t.closest('[data-fsys]'); if (fs){ state.fSys = state.fSys===fs.dataset.fsys?'':fs.dataset.fsys; state.fFac=''; render(); return; }
  const ff = t.closest('[data-ffac]'); if (ff){ state.fFac = state.fFac===ff.dataset.ffac?'':ff.dataset.ffac; render(); return; }
  const ft = t.closest('[data-fstage]'); if (ft){ state.fStage = state.fStage===ft.dataset.fstage?'':ft.dataset.fstage; render(); return; }
  const fk = t.closest('[data-fstock]'); if (fk){ state.pStock = state.pStock===fk.dataset.fstock?'':fk.dataset.fstock; render(); return; }
  const hm = t.closest('[data-harm]');  if (hm){ state.planner.kind = hm.dataset.harm; render(); return; }

  /* --- sorting, the picker and the shop --- */
  const so = t.closest('[data-sort]');
  if (so){ state.sort = state.sort === so.dataset.sort ? '' : so.dataset.sort; render(); return; }
  const pk = t.closest('[data-pk]');
  if (pk){ state.pick.kind = pk.dataset.pk; state.pick.result = null; render(); return; }
  const po = t.closest('[data-po]');
  if (po){ const k = po.dataset.po; state.pick.opts[k] = !state.pick.opts[k];
    state.pick.result = null; render(); return; }
  const sh = t.closest('[data-shop]');
  if (sh){ state.shopTab = sh.dataset.shop; render(); return; }
  const tk = t.closest('[data-tick]');
  if (tk){
    const id = tk.dataset.tick;
    state.ticked[id] = !state.ticked[id];
    render(); return;
  }
  const dw = t.closest('[data-delwish]');
  if (dw){
    const w = arr(data.wishlist).find(x => x.id === dw.dataset.delwish);
    data.wishlist = arr(data.wishlist).filter(x => x.id !== dw.dataset.delwish);
    save(); render(); toast(w ? w.name + ' removed.' : 'Removed.');
    return;
  }
  const cm = t.closest('[data-cmpmode]'); if (cm){ state.cmp.mode = cm.dataset.cmpmode; render(); return; }

  /* --- getting started --- */
  const ss = t.closest('[data-setupsys]');
  if (ss){
    const n = ss.dataset.setupsys, i = state.setup.sysPick.indexOf(n);
    if (i === -1) state.setup.sysPick.push(n); else state.setup.sysPick.splice(i, 1);
    render(); return;
  }
  const sp = t.closest('[data-setuppaint]');
  if (sp){
    const k = sp.dataset.setuppaint;
    if (state.setup.picked[k]) delete state.setup.picked[k];
    else state.setup.picked[k] = true;
    /* Update in place: a full render would rebuild the list and throw away
       your scroll position halfway down a rack of sixty pots. */
    sp.setAttribute('aria-pressed', state.setup.picked[k] ? 'true' : 'false');
    const n = Object.keys(state.setup.picked).filter(x => state.setup.picked[x]).length;
    const cEl = document.querySelector('.pcount');
    if (cEl) cEl.innerHTML = `<b class="num">${n}</b> ticked so far${
      n ? '' : ' &mdash; tick anything you own'}`;
    const btn = document.querySelector('[data-act="setupFinish"]');
    if (btn){ btn.disabled = !n;
      btn.innerHTML = n ? `Add ${n === 1 ? 'it' : `all ${n}`} and finish` : 'Add them and finish'; }
    return;
  }
  const du = t.closest('[data-setupdelunit]');
  if (du){ captureArmyFields();
    state.setup.units.splice(+du.dataset.setupdelunit, 1); render(); return; }

  /* "Jump to another stage" opens the full ladder in place. */
  const jmp = t.closest('[data-jump]');
  if (jmp){
    const lad = document.getElementById('ladder');
    if (lad){
      const open = lad.classList.toggle('open');
      jmp.setAttribute('aria-expanded', open ? 'true' : 'false');
      jmp.textContent = open ? 'Hide the stage list' : 'Jump to another stage';
    }
    return;
  }

  /* The common action: forward one. */
  const adv = t.closest('[data-adv]');
  if (adv){
    const m = data.minis.find(x => x.id === state.openMini); if (!m) return;
    const i = stageIx(m);
    if (i >= data.stages.length - 1) return;
    setStage(m, data.stages[i + 1]);
    return;
  }

  const stg = t.closest('[data-stage]');
  if (stg){
    const m = data.minis.find(x => x.id === state.openMini); if (!m) return;
    setStage(m, stg.dataset.stage);
    /* You picked from the list, so the list has done its job. */
    const lad = document.getElementById('ladder');
    const jb = document.querySelector('[data-jump]');
    if (lad && lad.classList.contains('open')){
      lad.classList.remove('open');
      if (jb){ jb.setAttribute('aria-expanded','false'); jb.textContent = 'Jump to another stage'; }
    }
    return;
  }
  const dp = t.closest('[data-delphoto]'); if (dp) return removePhoto(dp.dataset.delphoto);
  const ds = t.closest('[data-delswatch]'); if (ds) return deleteSwatch(ds.dataset.delswatch);
  const dst = t.closest('[data-delstep]'); if (dst) return deleteStep(dst.dataset.delstep);
  const ul = t.closest('[data-unlink]');
  if (ul){ data.links = data.links.filter(l => !(l.miniId===state.openMini && l.recipeId===ul.dataset.unlink));
    save(); render(); toast('Recipe detached.'); return; }
});

document.addEventListener('input', e => {
  const id = e.target.id;
  if (id === 'q' || id === 'pq'){
    const pos = e.target.selectionStart;
    if (id === 'q') state.q = e.target.value; else state.pq = e.target.value;
    render();
    const f = $('#'+id); if (f){ f.focus(); try { f.setSelectionRange(pos,pos); } catch(err){} }
  }
  if (id === 'doneN'){
    const m = data.minis.find(x => x.id === state.openMini); if (!m) return;
    m.done = Math.max(0, Math.min(Number(m.total)||1, Number(e.target.value)||0));
    m.updated = Date.now(); save();
  }
  if (id === 'suPq'){
    const pos = e.target.selectionStart;
    state.setup.pq = e.target.value;
    render();
    const f = $('#suPq'); if (f){ f.focus(); try { f.setSelectionRange(pos,pos); } catch(err){} }
  }
});

/* Return adds the unit and leaves the cursor where it was, so a box list can
   be typed straight through without reaching for a button. */
document.addEventListener('keydown', e => {
  if (e.key !== 'Enter') return;
  if (e.target.id === 'suUnit' || e.target.id === 'suCount'){
    e.preventDefault(); setupAddUnit();
  }
});

document.addEventListener('change', e => {
  const id = e.target.id;
  if (id === 'photoIn') return addPhotos(e.target.files);
  if (id === 'camIn')   return captureSwatch(e.target.files);
  if (id === 'impIn')   return importData(e.target.files[0]);
  if (id === 'plPaint'){ state.planner.paintId = e.target.value; render(); }
  if (id === 'pkSys'){ state.pick.opts.sys = e.target.value || null;
                       state.pick.result = null; render(); }
  if (id === 'setCurrency'){
    data.settings.currency = e.target.value;
    moneyFmtFor = null;                    /* force the formatter to rebuild */
    save(); render(); toast('Currency set to ' + currencyName(e.target.value) + '.');
  }
  if (id === 'cmpPaint'){ state.cmp.paintId = e.target.value; render(); }
  if (id === 'cmpUc'){ state.cmp.ucId = e.target.value; render(); }
  /* --- getting started --- */
  if (id === 'suSys'){
    /* Changing the system swaps the army list, so a stale army is cleared
       rather than quietly filing the models under the wrong one. */
    state.setup.sysName = e.target.value; state.setup.facName = '';
    render(); return;
  }
  if (id === 'suFac'){
    const own = e.target.value === '__own';
    const box = $('#suFacOwn');
    if (box){ box.hidden = !own; if (own) box.focus(); }
    if (!own) state.setup.facName = e.target.value;
    return;
  }
  if (id === 'suBrand'){ state.setup.brand = e.target.value; state.setup.range = '';
                         state.setup.pq = ''; render(); return; }
  if (id === 'suRange'){ state.setup.range = e.target.value; render(); return; }
});

function saveMiniEdits(){
  const m = data.minis.find(x => x.id === state.openMini); if (!m) return;
  const name = $('#eName').value.trim();
  if (!name){ toast(NAME_REQUIRED); return; }
  m.name = name; m.total = Math.max(1, Number($('#eTotal').value)||1);
  if (m.done > m.total) m.done = m.total;
  m.tags = $('#eTags').value.trim(); m.notes = $('#eNotes').value;
  m.base = $('#eBase') ? $('#eBase').value : (m.base || '');
  if ($('#eUnit')) m.unit = $('#eUnit').value.trim();
  if ($('#ePrice')) m.price = $('#ePrice').value === '' ? null
                            : Math.max(0, Number($('#ePrice').value) || 0);
  if ($('#eAcq')) m.acquired = $('#eAcq').value || '';
  m.updated = Date.now(); save(); render(); toast('Saved.');
}
function deleteMini(){
  const m = data.minis.find(x => x.id === state.openMini); if (!m) return;
  openDialog('Delete this entry?',
    `<p class="user-text">${esc(m.name)} and its photos will be deleted from this phone and from your account. This cannot be undone.</p>`,
    () => {
      arr(m.photos).forEach(pid => { forgetPhoto(pid).catch(() => {}); });
      data.minis = data.minis.filter(x => x.id !== m.id);
      data.links = data.links.filter(l => l.miniId !== m.id);
      save(); state.openMini = null; render(); toast('Deleted.');
    }, 'Delete entry', 'Keep it');
}
function savePaintEdits(){
  const p = paintOf(state.openPaint); if (!p) return;
  p.stock = $('#pStock').value; p.type = $('#pType').value; p.notes = $('#pNotes').value;
  save(); render(); toast('Saved.');
}
function deletePaint(){
  const p = paintOf(state.openPaint); if (!p) return;
  const sws = data.swatches.filter(s => s.paintId === p.id);
  openDialog('Delete this paint?',
    `<p class="user-text">${esc(p.name)}${sws.length?` and its ${sws.length} swatch photo${sws.length>1?'s':''}`:''} will be removed. This cannot be undone.</p>`,
    () => {
      sws.forEach(s => { forgetPhoto(s.photoId).catch(() => {}); });
      data.swatches = data.swatches.filter(s => s.paintId !== p.id);
      data.paints = data.paints.filter(x => x.id !== p.id);
      save(); state.openPaint = null; render(); toast('Deleted.');
    }, 'Delete paint', 'Keep it');
}
function saveRecipeEdits(){
  const r = data.recipes.find(x => x.id === state.openRecipe); if (!r) return;
  const t = $('#rTitle').value.trim();
  if (!t){ toast(NAME_REQUIRED); return; }
  const used = data.links.filter(l => l.recipeId === r.id).length;
  const apply = () => { r.title = t; r.category = $('#rCat').value.trim(); r.desc = $('#rDesc').value;
    save(); render(); toast('Saved.'); };
  if (used > 2){
    openDialog('This recipe is on ' + used + ' models',
      `<p>Saving changes it everywhere it is used. If you want to keep the old version, duplicate it first.</p>`,
      () => { apply(); }, 'Change all ' + used, 'Cancel');
  } else apply();
}
function deleteRecipe(){
  const r = data.recipes.find(x => x.id === state.openRecipe); if (!r) return;
  const used = data.links.filter(l => l.recipeId === r.id).length;
  openDialog('Delete this recipe?',
    `<p class="user-text">${esc(r.title)} will be removed${used?` and detached from ${used} model${used>1?'s':''}`:''}. This cannot be undone.</p>`,
    () => {
      data.recipes = data.recipes.filter(x => x.id !== r.id);
      data.links = data.links.filter(l => l.recipeId !== r.id);
      save(); state.openRecipe = null; render(); toast('Deleted.');
    }, 'Delete recipe', 'Keep it');
}
function deleteStep(id){
  const r = data.recipes.find(x => x.id === state.openRecipe); if (!r) return;
  r.steps = arr(r.steps).filter(s => s.id !== id); save(); render();
}
function deleteSwatch(id){
  const s = data.swatches.find(x => x.id === id); if (!s) return;
  forgetPhoto(s.photoId).catch(() => {});
  data.swatches = data.swatches.filter(x => x.id !== id);
  if (urlCache.has(s.photoId)){ URL.revokeObjectURL(urlCache.get(s.photoId)); urlCache.delete(s.photoId); }
  save(); render(); toast('Swatch deleted.');
}

async function addPhotos(fileList){
  const files = Array.from(fileList || []); if (!files.length) return;
  if (busy){ toast('Still working on the last one.'); return; }
  busy = true;
  const m = data.minis.find(x => x.id === state.openMini);
  if (!m){ busy = false; return; }
  let added = 0, failed = 0;
  for (const f of files){
    try {
      const blob = await deadline(Promise.resolve(f.slice()), 45000, 'Reading ' + f.name);
      const id = uid(); await putPhoto(id, blob);
      if (!Array.isArray(m.photos)) m.photos = [];
      m.photos.push(id); added++;
    } catch (err){ failed++; console.warn('photo failed', f && f.name, err.message); }
  }
  m.updated = Date.now(); save(); busy = false; render();
  $('#photoIn').value = '';
  if (added && !failed)     toast(added === 1 ? 'Photo added.' : added + ' photos added.');
  else if (added && failed) toast(added + ' added, ' + failed + ' could not be read.');
  else toast('That photo could not be read. If it is in iCloud, open it in Photos first so it downloads.');
}

async function captureSwatch(fileList){
  const f = (fileList || [])[0];
  $('#camIn').value = '';
  if (!f) return;
  if (busy){ toast('Still working on the last one.'); return; }
  busy = true;
  try {
    const blob = await deadline(Promise.resolve(f.slice()), 45000, 'Reading the photo');
    const id = uid(); await putPhoto(id, blob);
    busy = false; dlgLabelSwatch(id);
  } catch (err){
    busy = false;
    toast('That photo could not be read. If it is in iCloud, open it in Photos first so it downloads.');
    console.warn('swatch failed', err.message);
  }
}

function removePhoto(pid){
  const m = data.minis.find(x => x.id === state.openMini); if (!m) return;
  m.photos = arr(m.photos).filter(x => x !== pid);
  m.updated = Date.now(); save();
  forgetPhoto(pid).catch(err => toast('Removed from the entry, but the file could not be deleted: ' + err.message));
  if (urlCache.has(pid)){ URL.revokeObjectURL(urlCache.get(pid)); urlCache.delete(pid); }
  render();
}

/* --- header buttons -------------------------------------------------------- */
/* Light and dark used to be a button in the top bar. It is set once and left,
   so it lives in the menu now, as three plain choices instead of a cycle. */
function themeChips(){
  const cur = data.settings.theme || '';
  return [['','Match my device'],['light','Light'],['dark','Dark']].map(([v,l]) =>
    `<button class="chip" data-act="themeSet" data-v="${v}" aria-pressed="${cur===v}">${l}</button>`).join('');
}
function refreshThemeChips(){
  const box = document.getElementById('themechips');
  if (box) box.innerHTML = themeChips();
}

$('#moreBtn').addEventListener('click', () => {
  const c = counts();
  openDialog('More',
    `<p class="small muted">MiniManager <span class="num">${APP_VERSION}</span> &middot;
       <span class="num">${c.entries}</span> entries, <span class="num">${c.done} of ${c.total}</span> models finished,
       <span class="num">${c.paints}</span> paints, <span class="num">${c.swatches}</span> swatches,
       <span class="num">${c.recipes}</span> recipes</p>
     <hr><h3 style="font-size:.9375rem">Your account</h3>
     <p class="small muted">Signed in as
       <b class="user-text">${esc((syncState.user && (syncState.user.displayName || syncState.user.email)) || 'you')}</b>.
       Your collection is saved to your Google account and kept in step across
       your devices. Only you can see it.</p>
     <div class="row wrapm" style="margin-top:.625rem">
       <button class="btn ghost sm" data-act="account">Account and sign out</button>
       <button class="btn ghost sm" data-act="privacy">What MiniManager keeps</button></div>
     <hr><h3 style="font-size:.9375rem">Appearance</h3>
     <div class="chips" id="themechips" role="group" aria-label="Light or dark">${themeChips()}</div>
     <hr><h3 style="font-size:.9375rem">Paints and shopping</h3>
     <div class="row wrapm" style="margin-top:.625rem">
       <button class="btn ghost sm" data-act="shop">Shopping list and wishlist</button>
       <button class="btn ghost sm" data-act="openPlanner">Plan a colour scheme</button>
       <button class="btn ghost sm" data-act="openCompare">Compare swatches</button>
       <button class="btn ghost sm" data-act="setupPaintsOnly">Add several paints</button></div>
     <hr><h3 style="font-size:.9375rem">Getting started</h3>
     <p class="small muted">Fill an empty collection quickly, a game system and an army at a time.</p>
     <div class="row wrapm" style="margin-top:.625rem">
       <button class="btn ghost sm" data-act="setupStart">Set up my collection</button></div>
     <hr><h3 style="font-size:.9375rem">Your data</h3>
     <p class="small muted">Take a copy whenever you like. The backup file is
       yours and works with no account at all.</p>
     <div class="row wrapm" style="margin-top:.625rem">
       <button class="btn ghost sm" id="expBtn">Export a backup</button>
       <button class="btn ghost sm" id="csvBtn">Export as a spreadsheet</button>
       <button class="btn ghost sm" id="impBtn">Restore a backup</button></div>
     <hr><h3 style="font-size:.9375rem">Acknowledgements</h3>
     <p class="small muted">Paint catalogue data from
       <a href="https://github.com/PauloSalum/paint-equivalents">paint-equivalents</a>, derived from
       <a href="https://github.com/Arcturus5404/miniature-paints">miniature-paints</a>,
       MIT licence, Copyright &copy; 2022 Rick Fleuren.</p>
     <p class="small muted">Permission is hereby granted, free of charge, to any person obtaining a copy of this
       software and associated documentation files (the &ldquo;Software&rdquo;), to deal in the Software without
       restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute,
       sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to
       do so, subject to the following conditions: The above copyright notice and this permission notice shall be
       included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED &ldquo;AS IS&rdquo;,
       WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
       MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
       COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
       TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
       THE SOFTWARE.</p>
     <p class="small muted">Paint names, brand names, game system names, army and faction names are
       trademarks of their respective owners. They appear here only so you can label and find your
       own models. MiniManager is not affiliated with, endorsed by or sponsored by any paint
       manufacturer or games publisher.</p>
     <p class="small muted">Army lists were checked against the publishers&rsquo; own material where it
       could be reached. They are a convenience, not an authority: every list in this app ends with
       &ldquo;Type my own&rdquo;, and your own spelling always wins.</p>`,
    /* Nothing to confirm here, so no Save button and no "Cancel": one
       honest Close at the foot, and the × pinned at the top. */
    null, null, 'Close');
  $('#expBtn').addEventListener('click', exportData);
  $('#csvBtn').addEventListener('click', exportCsv);
  $('#impBtn').addEventListener('click', () => $('#impIn').click());
});

function download(name, text, type){
  const blob = new Blob([text], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
function exportData(){
  /* Photos are not in the export. They would make a file of hundreds of
     megabytes that most phones cannot assemble in memory. */
  download('minimanager-backup-' + new Date().toISOString().slice(0,10) + '.json',
    JSON.stringify(data, null, 2), 'application/json');
  toast('Backup saved &mdash; records only, not photos.'.replace('&mdash;','—'));
}
function exportCsv(){
  const q = s => '"' + String(s==null?'':s).replace(/"/g,'""') + '"';
  const rows = [['Name','Game system','Army','Stage','Total','Finished','Tags','Notes'].map(q).join(',')];
  data.minis.forEach(m => rows.push([m.name, sysName(m.sys), facName(m.fac), m.stage,
    m.total, m.done, m.tags, m.notes].map(q).join(',')));
  download('minimanager-collection-' + new Date().toISOString().slice(0,10) + '.csv',
    rows.join('\n'), 'text/csv');
  toast('Spreadsheet saved.');
}
function importData(file){
  if (!file) return;
  file.text().then(txt => {
    let p = null;
    try { p = JSON.parse(txt); } catch (e) { p = null; }
    if (!p || !Array.isArray(p.minis)){ toast('That file is not a MiniManager backup.'); return; }
    /* Restoring replaces everything, here and in the account, so it says
       exactly what will change and waits for a yes. */
    const n = (x, one, many) => `<b>${arr(x).length}</b> ${arr(x).length === 1 ? one : many}`;
    openDialog('Replace everything with this backup?',
      `<p>Your collection now: ${n(data.minis,'entry','entries')}, ${n(data.paints,'paint','paints')}, ${n(data.recipes,'recipe','recipes')}.</p>
       <p>The backup: ${n(p.minis,'entry','entries')}, ${n(p.paints,'paint','paints')}, ${n(p.recipes,'recipe','recipes')}.</p>
       <p>Everything here and in your account is replaced by the backup. Anything added since the backup was made is deleted. Photos are not in backups; ones still in your account stay.</p>`,
      () => {
        localStorage.setItem('mm.data', txt);
        if (typeof syncState !== 'undefined') syncState.allowMassDelete = true;
        load(); applyTheme(); save(); render();
        toast('Restored ' + p.minis.length + ' entries.');
      }, 'Replace everything', 'Keep what I have');
  }).catch(err => toast('That file could not be read: ' + err.message));
  $('#impIn').value = '';
}

/* ===========================================================================
   Start
   =========================================================================== */
load(); applyTheme(); render();

/* Sign-in is required, so the gate decides what gets drawn. The one thing
   it must never do is lock somebody out because they happen to be offline:
   Firebase keeps the session locally, so a person who signed in once opens
   straight into their collection on a train with no signal. */
(async () => {
  try {
    await authStart(user => {
      if (user){
        authGate = 'in';
        if (state.tab === 'privacy' || state.tab === 'account') state.tab = 'home';
        render();
        startSync(user);
      } else {
        authGate = 'out';
        stopSync();
        render();
      }
    });
  } catch (err) {
    /* If Firebase itself cannot start there is no way in, and pretending
       otherwise would show an empty collection as though it were real. */
    authGate = 'out';
    syncState.error = 'MiniManager could not reach the sign-in service. ' +
      (navigator.onLine ? (err.message || '') : 'You appear to be offline.');
    render();
  }
})();

window.addEventListener('online',  () => { if (syncState.on){ syncStatus('syncing'); pushUp().catch(() => {}); } });
window.addEventListener('offline', () => { if (syncState.on) syncStatus('offline'); });

if ('serviceWorker' in navigator){
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(err => console.warn('sw', err.message));
  });
}
