/* v015: the audit's urgent fixes. Sync is tested against a recorder in place
   of Firebase: what a device sends, and when. */
const { chromium } = require('playwright'); const fs = require('fs');
const DIR = __dirname + '/';
const SEED = fs.readFileSync(DIR+'test_v7.js','utf8').match(/const SEED = `([\s\S]*?)`;/)[1];
let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); } else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };
const FAKE = `
window.__w = []; window.__cb = {}; window.__deleted = [];
const F = {
  collection:(db,p)=>({p}), doc:(db,...parts)=>({p:parts.join('/')}),
  onSnapshot:(q,cb)=>{ window.__cb[q.p] = cb; return ()=>{}; },
  writeBatch:()=>({ set:(ref,val)=>window.__w.push([ref.p,val]), commit:async()=>{} }),
  storageRef:(s,p)=>({p}), uploadBytes:async()=>{}, deleteObject:async(r)=>{ window.__deleted.push(r.p); }
};
fb = { F, db:{}, storage:{} };
window.__snap = (coll, recs) => window.__cb['users/u1/'+coll]({ docChanges:()=>recs.map(r=>({doc:{data:()=>r}})) });
window.__all = (by) => SYNC_COLLECTIONS.forEach(c => window.__snap(c, (by && by[c]) || []));
`;
const wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const b = await chromium.launch();
  const page = async () => { const p = await b.newPage({ viewport:{width:390,height:844} }); const e=[]; p.on('pageerror',x=>e.push(x.message)); p.errs=e;
    await p.goto('file://' + require('path').join(__dirname, '..', 'build', 'index.html')); await p.waitForTimeout(1800); await p.evaluate(SEED); await p.evaluate(FAKE); return p; };

  /* ---------- 1. first sync on a device holding an old copy ---------- */
  let p = await page();
  let r = await p.evaluate(async () => {
    localStorage.removeItem('mm.synced.u1');
    data.minis.forEach(m => m.updated = 1000);
    data.minis.push({ id:'onlyHere', name:'Made offline', sys:'', fac:'', stage:'Unbuilt', total:1, done:0, photos:[], updated:2000 });
    startSync({ uid:'u1' });
    await new Promise(r => setTimeout(r, 200));
    const before = window.__w.length;
    /* The account has every seeded model, one of them edited elsewhere since. */
    const remote = data.minis.filter(m => m.id !== 'onlyHere').map(m => Object.assign({}, m, { updated: 5000 }));
    remote[0] = Object.assign({}, remote[0], { name:'Renamed on the other phone', updated: 9000 });
    const undercoats = data.undercoats.map(u => Object.assign({}, u));
    window.__all({ minis: remote, undercoats, systems: data.systems.map(x=>Object.assign({},x)), factions: data.factions.map(x=>Object.assign({},x)) });
    await new Promise(r => setTimeout(r, 300));
    const minis = window.__w.filter(w => w[0].includes('/minis/'));
    return { sentBeforeDownload: before, miniWrites: minis.map(w => w[0].split('/').pop()), total: window.__w.length,
             otherPhoneEditKept: data.minis[0].name, baselineSaved: !!localStorage.getItem('mm.synced.u1') };
  });
  ok('first sync: nothing is sent before the account has downloaded', r.sentBeforeDownload === 0, String(r.sentBeforeDownload));
  ok('first sync: only the record made on this device alone is sent', r.miniWrites.join(',') === 'onlyHere', JSON.stringify(r));
  ok('first sync: the other phone\'s newer edit survives', r.otherPhoneEditKept === 'Renamed on the other phone', r.otherPhoneEditKept);
  ok('first sync: undercoat presets are not re-sent', r.total === 1, String(r.total));
  ok('what the account holds is remembered on the device', r.baselineSaved);
  r = await p.evaluate(async () => {
    stopSync(); localStorage.removeItem('mm.synced.u1'); window.__w = [];
    startSync({ uid:'u1' });
    const m5 = data.minis.find(m => m.id === 'm5'); const remote5 = Object.assign({}, m5);
    m5.name = 'Edited in the first seconds'; m5.updated = Date.now() + 60000; saveLocalOnly(); schedulePush();
    const by = {}; SYNC_COLLECTIONS.forEach(c => { by[c] = arr(data[c]).filter(x => x && x.id).map(x => Object.assign({}, x)); });
    by.minis = by.minis.map(m => m.id === 'm5' ? remote5 : m);
    window.__all(by);
    await new Promise(r => setTimeout(r, 400));
    return window.__w.map(w => w[0].split('/').pop());
  });
  ok('first sync: an edit made before the download finished still goes out', r.includes('m5') && r.length === 1, r.join(','));

  /* ---------- 2. the next launch ---------- */
  r = await p.evaluate(async () => {
    stopSync(); fb.F.onSnapshot = (q,cb)=>{ window.__cb[q.p] = cb; return ()=>{}; };
    window.__w = [];
    data.minis.find(m => m.id === 'm2').name = 'Edited offline';
    saveLocalOnly();
    startSync({ uid:'u1' });
    await new Promise(r => setTimeout(r, 300));
    return window.__w.map(w => w[0].split('/').slice(-2).join('/'));
  });
  ok('next launch: only the record edited since is sent, straight away', r.join(',') === 'minis/m2', r.join(','));

  /* ---------- 3. something arrives while an edit is waiting to send ---------- */
  r = await p.evaluate(async () => {
    window.__w = [];
    const m3 = data.minis.find(m => m.id === 'm3'); m3.name = 'Local, not sent yet';
    window.__snap('minis', [Object.assign({}, data.minis.find(m => m.id === 'm4'), { name:'From elsewhere', updated: Date.now() + 5000 })]);
    await pushUp();
    return { sent: window.__w.map(w => w[0].split('/').pop()), m4: data.minis.find(m => m.id === 'm4').name };
  });
  ok('an edit waiting to send is not swallowed when something else arrives', r.sent.includes('m3') && !r.sent.includes('m4'), JSON.stringify(r));
  ok('...and the arrival is applied', r.m4 === 'From elsewhere');

  /* ---------- 4. a damaged local copy does not wipe the account ---------- */
  r = await p.evaluate(async () => {
    window.__w = [];
    const keep = data.minis.slice();
    data.minis = []; await pushUp();
    const accidental = window.__w.filter(w => w[1] && w[1].deleted).length;
    data.minis = keep;
    return accidental;
  });
  ok('more than 25 deletes at once, not via Restore, are held back', r === 0, String(r));
  r = await p.evaluate(async () => {
    window.__w = []; for (let i = 0; i < 30; i++) data.minis.push({ id:'x'+i, name:'x', stage:'Unbuilt', total:1, done:0, photos:[] });
    await pushUp(); window.__w = [];
    data.minis = data.minis.filter(m => !m.id.startsWith('x')); syncState.allowMassDelete = true; await pushUp();
    return window.__w.filter(w => w[1] && w[1].deleted).length;
  });
  ok('...but go through when Restore says so', r === 30, String(r));

  /* ---------- 5. photo deletes reach the account ---------- */
  r = await p.evaluate(async () => {
    window.__deleted = [];
    const m = data.minis.find(m => m.id === 'm1'); m.photos = ['phA']; await putPhoto('phA', new Blob(['x'],{type:'image/jpeg'}));
    state.tab='coll'; state.openMini='m1'; render();
    removePhoto('phA');
    await new Promise(r => setTimeout(r, 300));
    data.swatches = [{ id:'s1', paintId:'', photoId:'phB', undercoatId:'' }];
    deleteSwatch('s1');
    await new Promise(r => setTimeout(r, 300));
    return window.__deleted;
  });
  ok('removing a photo deletes it from the account', r.some(x => x.endsWith('/phA')), JSON.stringify(r));
  ok('deleting a swatch deletes its photo from the account', r.some(x => x.endsWith('/phB')), JSON.stringify(r));
  r = await p.evaluate(async () => {
    window.__deleted = [];
    Object.defineProperty(navigator, 'onLine', { configurable:true, get:()=>false });
    queueCloudDelete('phC'); await new Promise(r => setTimeout(r, 100));
    const queued = JSON.parse(localStorage.getItem('mm.photoDeletes')||'[]');
    Object.defineProperty(navigator, 'onLine', { configurable:true, get:()=>true });
    await flushCloudDeletes();
    return { queued, sent: window.__deleted, left: JSON.parse(localStorage.getItem('mm.photoDeletes')||'[]') };
  });
  ok('offline: a photo delete waits in a queue', r.queued.includes('phC'), JSON.stringify(r));
  ok('...and goes when back online', r.sent.some(x => x.endsWith('/phC')) && r.left.length === 0, JSON.stringify(r));
  ok('signing out does not delete account photos', await p.evaluate(() => { window.__deleted = []; stopSync(); return window.__deleted.length === 0; }));

  /* ---------- 6. finished means every model ---------- */
  p = await page();
  await p.evaluate(`data.minis.push({id:'u10',name:'Ten',sys:data.systems[0].id,fac:data.factions[0].id,total:10,done:3,stage:'Basing',photos:[],updated:1}); state.tab='coll'; state.openMini='u10'; render();`);
  await p.waitForTimeout(300); await p.click('[data-adv]'); await p.waitForTimeout(900);
  ok('a 10-model unit moved to Finished counts 10 of 10', await p.evaluate(() => { const m = data.minis.find(x=>x.id==='u10'); return m.done === 10; }));
  await p.click('[data-jump]'); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('.lrow[data-stage="Highlights"]').click()); await p.waitForTimeout(600);
  ok('moving it back resets the count', await p.evaluate(() => data.minis.find(x=>x.id==='u10').done === 0));
  ok('old finished entries are corrected when the app loads', await p.evaluate(() => {
    const d = JSON.parse(localStorage.getItem('mm.data')); d.minis.push({id:'old',name:'Old',stage:'Finished',total:5,done:2,photos:[]});
    localStorage.setItem('mm.data', JSON.stringify(d)); load(); return data.minis.find(m=>m.id==='old').done === 5; }));

  /* ---------- 7. restore asks first ---------- */
  await p.evaluate(() => { state.tab='home'; state.openMini=null; render(); });
  fs.writeFileSync(DIR+'restore_test.json', JSON.stringify({ v:3, minis:[{id:'r1',name:'From backup',stage:'Unbuilt',total:1,done:0}], paints:[], recipes:[] }));
  await p.click('#moreBtn'); await p.waitForTimeout(300);
  await p.setInputFiles('#impIn', DIR+'restore_test.json'); await p.waitForTimeout(500);
  const ask = await p.evaluate(() => ({ open: $('#dlg').open, text: document.getElementById('dlgBody').textContent.replace(/\s+/g,' ') }));
  ok('Restore asks before replacing', ask.open && /Replace everything with this backup/.test(ask.text), ask.text.slice(0,80));
  ok('...saying what is there now and what the backup holds', /now: \d+ entries/.test(ask.text) && /backup: 1 entry/.test(ask.text), ask.text.slice(0,200));
  await p.click('#dlg .row:last-child [data-dlg="cancel"]'); await p.waitForTimeout(300);
  ok('Keep what I have changes nothing', await p.evaluate(() => !data.minis.some(m => m.id === 'r1') && data.minis.length > 5));
  await p.click('#moreBtn'); await p.waitForTimeout(300);
  await p.setInputFiles('#impIn', DIR+'restore_test.json'); await p.waitForTimeout(500);
  await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(400);
  ok('Replace everything restores the backup', await p.evaluate(() => data.minis.length === 1 && data.minis[0].id === 'r1'));

  /* ---------- 8. the shop is always reachable ---------- */
  p = await page();
  await p.evaluate(`data.paints=[{id:'p0',name:'Nuln Oil',brand:'Citadel',range:'Shade',hex:'#111',stock:'Have it'}]; data.supplies=[]; data.wishlist=[{id:'w',name:'Lord',kind:'model',price:30}]; state.tab='paints'; render();`);
  await p.waitForTimeout(200);
  ok('Paints shows the shopping list and wishlist line with nothing low', /Shopping list.*wishlist 1/.test(await p.textContent('.shopline')), await p.textContent('.shopline'));
  await p.click('.shopline'); await p.waitForTimeout(300);
  ok('...and it opens the shop', await p.evaluate(() => state.tab === 'shop'));
  await p.evaluate(() => { state.tab='home'; render(); }); await p.click('#moreBtn'); await p.waitForTimeout(300);
  ok('the ⋯ menu has Shopping list and wishlist', await p.isVisible('#dlg [data-act="shop"]'));
  await p.click('#dlg [data-act="shop"]'); await p.waitForTimeout(300);
  ok('...which opens the shop and closes the menu', await p.evaluate(() => state.tab === 'shop' && !$('#dlg').open));
  ok('no page errors', p.errs.length === 0, p.errs.join(' | '));
  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length) process.exit(1);
})();
