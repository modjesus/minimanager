/* v005: price, dates, the picker, the shop, currency, and the motion that
   previously never ran. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');

let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                          else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

const signIn = p => p.evaluate(() => {
  authGate = 'in';
  syncState.user = { uid:'t', displayName:'T', email:'t@e.com' };
  state.tab = 'home'; render();
});

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForTimeout(2200);
  await signIn(p); await p.waitForTimeout(400);

  ok('version reads v015', await p.evaluate(() => APP_VERSION) === 'v015');
  ok('no script errors', errs.length === 0, errs.slice(0,2).join(' | '));

  /* ---------- money ---------- */
  const m = await p.evaluate(() => ({
    gbp: money(32.5), whole: money(32), zero: money(0),
    def: data.settings.currency, count: CURRENCIES.length
  }));
  ok('pounds by default', m.def === 'GBP', m.def);
  ok('formats money', /32[.,]5/.test(m.gbp) && /£/.test(m.gbp), m.gbp);
  ok('drops .00 on whole amounts', !/\.00/.test(m.whole), m.whole);
  ok('offers a decent list of currencies', m.count >= 25, String(m.count));

  const other = await p.evaluate(() => {
    data.settings.currency = 'JPY'; moneyFmtFor = null; const a = money(1200);
    data.settings.currency = 'SEK'; moneyFmtFor = null; const b = money(1200);
    data.settings.currency = 'GBP'; moneyFmtFor = null;
    return { jpy:a, sek:b };
  });
  ok('yen has no decimals', !/[.,]\d\d\b/.test(other.jpy), other.jpy);
  ok('other currencies are identified and formatted for the viewer, not the currency',
     /SEK|kr/i.test(other.sek) && /1[,.\s]?200/.test(other.sek), other.sek);

  /* ---------- price + date on a model ---------- */
  await p.evaluate(() => {
    const now = Date.now();
    data.systems = [{ id:'s1', name:'Warhammer: Age of Sigmar' }];
    data.minis = [
      { id:'m1', name:'Old Skeletons', sys:'s1', fac:'', total:20, done:0,
        stage:data.stages[0], price:28, acquired:'2021-03-16', tags:'', notes:'',
        photos:[], created:now, updated:now },
      { id:'m2', name:'Lord-Veritant', sys:'s1', fac:'', total:1, done:0,
        stage:'Basecoat', price:22.5, acquired:'2025-06-01', tags:'', notes:'',
        photos:[], created:now, updated:now },
      { id:'m3', name:'Finished Thing', sys:'s1', fac:'', total:5, done:5,
        stage:data.stages[data.stages.length-1], price:50, acquired:'2024-01-10',
        tags:'', notes:'', photos:[], created:now, updated:now },
      { id:'m4', name:'No Price Here', sys:'s1', fac:'', total:3, done:0,
        stage:data.stages[0], price:null, acquired:'', tags:'', notes:'',
        photos:[], created:now, updated:now }
    ];
    save(); state.tab='home'; render();
  });
  await p.waitForTimeout(400);

  const v = await p.evaluate(() => collectionValue());
  ok('unpainted value adds up', v.unpainted === 50.5, String(v.unpainted));
  ok('finished value is counted separately', v.finished === 50, String(v.finished));
  ok('entries with no price are excluded, not zeroed', v.priced === 3 && v.missing === 1,
     `priced ${v.priced}, missing ${v.missing}`);

  /* ---------- the value is hidden until asked ---------- */
  ok('the money is NOT shown on opening the app',
     !(await p.evaluate(() => document.body.innerText.includes('waiting to be painted'))));
  ok('there is a Show control', await p.isVisible('[data-act="showValue"]'));
  await p.click('[data-act="showValue"]'); await p.waitForTimeout(300);
  const shown = await p.textContent('#app');
  ok('revealing shows unpainted and finished together',
     /waiting to be painted/.test(shown) && /painted and finished/.test(shown));
  ok('it says how many entries have no price', /aren.t counted/.test(shown));
  ok('it can be hidden again', await p.isVisible('[data-act="hideValue"]'));
  ok('the reveal is not persisted across a reload',
     await p.evaluate(() => { const s = JSON.parse(localStorage.getItem('mm.data')||'{}');
       return !('showValue' in s); }));

  /* ---------- longest waiting ---------- */
  await p.evaluate(() => { state.tab='coll'; state.openMini=null; render(); });
  await p.waitForTimeout(300);
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(300);
  ok('a Longest waiting sort is offered', await p.isVisible('#dlg [data-sort="waiting"]'));
  await p.click('#dlg [data-sort="waiting"]'); await p.waitForTimeout(300);
  await p.evaluate(() => $('#dlg').close()); await p.waitForTimeout(250);
  const order = await p.evaluate(() => filtered().map(x => x.name));
  ok('oldest first', order[0] === 'Old Skeletons', order.join(' / '));
  ok('models with no date go last, not first',
     order[order.length-1] === 'No Price Here', order.join(' / '));
  ok('the age is shown while sorting by it',
     /yr|mo/.test(await p.textContent('#app')));

  /* ---------- the picker ---------- */
  await p.evaluate(() => { state.tab='pick'; state.pick={kind:'build',opts:{},result:null,last:null}; render(); });
  await p.waitForTimeout(300);
  ok('the picker screen opens', await p.isVisible('[data-act="doPick"]'));
  const buildPool = await p.evaluate(() => pickPool().map(x => x.name));
  ok('"to build" only offers unbuilt models',
     buildPool.length === 2 && buildPool.every(n => /Skeletons|No Price/.test(n)), buildPool.join(' / '));
  ok('it never offers a finished model', !buildPool.includes('Finished Thing'));

  await p.click('[data-act="doPick"]'); await p.waitForTimeout(700);
  const first = await p.evaluate(() => state.pick.result && state.pick.result.name);
  ok('picking lands on something', !!first, first);
  ok('"Not that one" appears', await p.isVisible('[data-act="openPicked"]'));

  let repeats = 0, prev = first;
  for (let i = 0; i < 6; i++){
    await p.click('[data-act="openPicked"]').catch(()=>{});
    await p.evaluate(() => { state.tab='pick'; render(); });
    await p.click('[data-act="doPick"]'); await p.waitForTimeout(600);
    const n = await p.evaluate(() => state.pick.result.name);
    if (n === prev) repeats++;
    prev = n;
  }
  ok('it never offers the same model twice running', repeats === 0, repeats + ' repeats');

  const quick = await p.evaluate(() => {
    state.pick.kind='either'; state.pick.opts={quick:true};
    return pickPool().map(x => x.name);
  });
  ok('"Something quick" filters by model count',
     quick.includes('Lord-Veritant') && !quick.includes('Old Skeletons'), quick.join(' / '));

  const oldest = await p.evaluate(async () => {
    state.pick.kind='either'; state.pick.opts={old:true};
    state.pick.last=null; state.pick.result=null;
    runPick();
    await new Promise(s => setTimeout(s, 600));   // the flick settles first
    return state.pick.result.name;
  });
  ok('"Favour the oldest" actually picks the oldest', oldest === 'Old Skeletons', oldest);

  const none = await p.evaluate(() => {
    state.pick.kind='build'; state.pick.opts={quick:true, sys:'nope'};
    state.pick.result=null; render();
    return { pool: pickPool().length, text: document.querySelector('#app').innerText };
  });
  ok('an impossible combination says so rather than breaking',
     none.pool === 0 && /Loosen one/.test(none.text));

  /* ---------- the shop ---------- */
  await p.evaluate(() => {
    data.paints = [
      { id:'p1', name:'Mephiston Red', brand:'Citadel', range:'Base', hex:'#9A2A2A',
        stock:'Out', type:'', notes:'', created:Date.now() },
      { id:'p2', name:'Nuln Oil', brand:'Citadel', range:'Shade', hex:'#1B2A3A',
        stock:'Running low', type:'', notes:'', created:Date.now() },
      { id:'p3', name:'Fine', brand:'Citadel', range:'Base', hex:'#333333',
        stock:'Have it', type:'', notes:'', created:Date.now() }
    ];
    data.supplies = [{ id:'g1', name:'Plastic glue', note:'thin', stock:'Out',
                       created:Date.now(), updated:Date.now() }];
    data.wishlist = [{ id:'w1', name:'Mega-Gargant', kind:'model', note:'AoS',
                       price:120, created:Date.now(), updated:Date.now() }];
    state.tab='shop'; state.shopTab='need'; state.ticked={}; save(); render();
  });
  await p.waitForTimeout(400);
  const need = await p.textContent('#app');
  ok('the Need list builds itself from stock states',
     /Mephiston Red/.test(need) && /Nuln Oil/.test(need));
  ok('paints you still have are not on the list', !/\bFine\b/.test(need));
  ok('glue sits under Supplies', /Plastic glue/.test(need) && /Supplies/.test(need));

  await p.click('[data-tick="p1"]'); await p.waitForTimeout(300);
  ok('ticking crosses it off',
     await p.evaluate(() => document.querySelector('[data-tick="p1"]').getAttribute('aria-pressed')) === 'true');
  ok('ticking does NOT quietly change the stock state',
     await p.evaluate(() => data.paints.find(x=>x.id==='p1').stock) === 'Out');
  ok('a button appears to actually restock', await p.isVisible('[data-act="restock"]'));
  await p.click('[data-act="restock"]'); await p.waitForTimeout(400);
  ok('restocking changes it for real',
     await p.evaluate(() => data.paints.find(x=>x.id==='p1').stock) === 'Have it');
  ok('and clears the ticks', await p.evaluate(() => Object.keys(state.ticked).length) === 0);

  await p.click('[data-shop="want"]'); await p.waitForTimeout(300);
  const want = await p.textContent('#app');
  ok('the Want tab shows the wishlist', /Mega-Gargant/.test(want));
  ok('wishlist prices use the chosen currency', /£120/.test(want), want.match(/around[^·\n]*/)?.[0]);
  await p.click('[data-delwish="w1"]'); await p.waitForTimeout(400);
  ok('wishlist items can be removed',
     await p.evaluate(() => data.wishlist.length) === 0);

  /* ---------- sync must carry the new collections ---------- */
  const sc = await p.evaluate(() => SYNC_COLLECTIONS);
  ok('supplies are set up to sync', sc.includes('supplies'));
  ok('the wishlist is set up to sync', sc.includes('wishlist'));

  /* ---------- THE MOTION: it used to never run ---------- */
  await p.evaluate(() => {
    state.tab='coll'; state.openMini='m1'; state.sort=''; render();
  });
  await p.waitForTimeout(500);
  await p.evaluate(() => {
    window.__ran = [];
    ['transitionrun','animationstart'].forEach(ev => document.addEventListener(ev, e => {
      /* An SVG element's .className is an SVGAnimatedString, not a string, so
         reading it gave "[object SVGAnimatedString]" and the pot level looked
         as though it never moved. getAttribute works for both. */
      const cn = (e.target.getAttribute && e.target.getAttribute('class'))
                 || e.target.className || e.target.tagName;
      window.__ran.push((e.animationName || e.propertyName) + ' on ' +
        String(cn).split(' ')[0]);
    }, true));
  });
  /* v009: the sideways strip of dots is gone. Forward one is now a single
     big button, and the paint level in the pot is the thing that travels. */
  const levels = [];
  for (let i = 0; i < 3; i++){
    levels.push(await p.evaluate(() => document.querySelector('.potfill').style.transform));
    await p.click('[data-adv]');
    await p.waitForTimeout(500);
  }
  levels.push(await p.evaluate(() => document.querySelector('.potfill').style.transform));
  const ran = await p.evaluate(() => window.__ran);
  ok('the paint level actually animates',
     ran.some(x => /transform on potfill/.test(x)), ran.slice(0,4).join(' | '));
  ok('the level moves a different amount at every stage',
     new Set(levels).size === levels.length, levels.join(' '));
  ok('the level rises rather than falls', (() => {
    const n = levels.map(t => parseFloat(t.replace(/[^\d.-]/g,'')));
    return n.every((v,i) => i === 0 || v < n[i-1]);
  })(), levels.join(' '));
  ok('the big button renames itself to the next stage',
     await p.evaluate(() => /Move to/.test(document.querySelector('.advance')?.textContent || '')));

  /* finishing fires the tick */
  await p.evaluate(() => { window.__ran = []; });
  await p.evaluate(() => {
    const m = data.minis.find(x => x.id === state.openMini);
    setStage(m, data.stages[data.stages.length-1]);
  });
  await p.waitForTimeout(500);
  const finRan = await p.evaluate(() => window.__ran);
  ok('finishing draws the big tick',
     finRan.some(x => /celebdraw/.test(x)), finRan.slice(0,5).join(' | '));
  ok('the tick cannot swallow a tap', await p.evaluate(() => {
    const c = document.querySelector('.celebrate');
    return !c || getComputedStyle(c).pointerEvents === 'none';
  }));
  ok('the finished mark travels into place',
     finRan.some(x => /opacity on finmark|transform on finmark/.test(x)) ||
     await p.evaluate(() => document.querySelector('.finmark')?.classList.contains('on')));
  await p.waitForTimeout(1800);
  ok('the tick clears itself afterwards',
     await p.evaluate(() => !document.querySelector('.celebrate')));

  /* v009: nothing scrolls sideways any more, so there is nothing to scroll
     back into view. What has to be true instead is that the finished state is
     fully visible without scrolling at all, and that the pot reads as full. */
  const atEnd = await p.evaluate(() => {
    const v = document.querySelector('.vessel');
    const lvl = document.querySelector('.potfill');
    return {
      full: v ? v.classList.contains('full') : null,
      level: lvl ? parseFloat(lvl.style.transform.replace(/[^\d.-]/g,'')) : null,
      advanceGone: !document.querySelector('.advance'),
      stageVisible: (() => { const n = document.querySelector('.stagename');
        if (!n) return false; const r = n.getBoundingClientRect();
        return r.left >= 0 && r.right <= document.documentElement.clientWidth; })()
    };
  });
  ok('the pot is marked full at the last stage', atEnd.full === true, JSON.stringify(atEnd));
  ok('the level reaches the top of the drop', atEnd.level <= 6.1, JSON.stringify(atEnd));
  ok('the forward button removes itself at the end', atEnd.advanceGone, JSON.stringify(atEnd));
  ok('the stage you reached needs no sideways scrolling to see',
     atEnd.stageVisible, JSON.stringify(atEnd));

  /* ---------- help panels animate now ---------- */
  await p.evaluate(() => { state.tab='coll'; state.openMini=null; render(); });
  await p.click('#actslot [data-act="addHere"], #app [data-act="addMini"]'); await p.waitForTimeout(300);
  await p.click('details.more > summary'); await p.waitForTimeout(300);
  await p.evaluate(() => { window.__h = [];
    document.addEventListener('transitionrun', e => {
      if (e.target.classList && e.target.classList.contains('helpwrap')) window.__h.push(e.propertyName);
    }, true); });
  await p.click('.q'); await p.waitForTimeout(400);
  ok('the "?" answer grows into place',
     await p.evaluate(() => window.__h.includes('grid-template-rows')),
     JSON.stringify(await p.evaluate(() => window.__h)));
  ok('the answer is readable once open',
     /32mm/.test(await p.textContent('#dlgBody')));
  await p.click('[data-dlg="cancel"]').catch(()=>{});
  await p.waitForTimeout(200);

  /* ---------- layout ---------- */
  for (const tab of ['pick','shop','home']){
    await p.evaluate(t => { state.tab=t; state.openMini=null; render(); }, tab);
    await p.waitForTimeout(300);
    const over = await p.evaluate(() => {
      const vw = document.documentElement.clientWidth, bad = [];
      document.querySelectorAll('*').forEach(el => {
        if (el.closest('.stepper')) return;
        const r = el.getBoundingClientRect();
        if (r.width && r.right > vw + 1) bad.push((el.className||el.tagName) + ' r=' + Math.round(r.right));
      });
      return bad.slice(0,3);
    });
    ok(`no sideways overflow on the ${tab} screen at 390px`, over.length === 0, over.join(', '));
  }
  const small = await p.evaluate(() => {
    const bad = [];
    document.querySelectorAll('button, select, input:not([type=hidden]), summary').forEach(el => {
      if (el.offsetParent === null) return;
      if (el.classList.contains('q') || el.classList.contains('tick')
          || el.classList.contains('linkbtn')) return;   // 44px via ::after, checked below
      const r = el.getBoundingClientRect();
      if (r.height && r.height < 37.5) bad.push((el.className||el.tagName) + ' h=' + Math.round(r.height));
    });
    return bad;
  });
  ok('controls stay tappable', small.length === 0, small.slice(0,3).join(', '));
  ok('the Show/Hide link has a 44px target behind it', await p.evaluate(() => {
    const el = document.querySelector('.linkbtn'); if (!el) return true;
    const a = getComputedStyle(el, '::after');
    return parseFloat(a.height) >= 44;
  }));
  ok('the tick control has a 44px target behind it', await p.evaluate(() => {
    const t = document.querySelector('.tick'); if (!t) return true;
    const a = getComputedStyle(t, '::after');
    return parseFloat(a.width) >= 44 && parseFloat(a.height) >= 44;
  }));

  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('\n  FAILURES:'); fail.forEach(f => console.log('    - ' + f)); process.exit(1); }
})();
