/* v004: the sign-in gate and the sync merge rules.

   The merge rules are the part worth testing hardest. They are pure
   functions, they decide whether somebody's edit survives, and a bug in
   them loses work silently rather than throwing. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');

let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                          else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await p.goto(URL);
  await p.waitForTimeout(2500);

  /* ---------- the gate ---------- */
  ok('version reads v015', await p.evaluate(() => APP_VERSION) === 'v015');
  ok('no uncaught script errors on a cold start', errs.length === 0, errs.slice(0,2).join(' | '));
  ok('the Firebase bundle loaded', await p.evaluate(() => typeof window.FB === 'object'));
  ok('the config is present', await p.evaluate(() => FIREBASE_CONFIG.projectId) === 'minimanager-3b297');

  ok('a signed-out visitor sees the gate, not the app',
     await p.isVisible('.gatecard') && !(await p.isVisible('[data-act="addMini"]')));
  ok('the tab bar is actually off screen while gated',
     await p.evaluate(() => {
       const n = document.querySelector('nav.tabs');
       return n.hidden === true && getComputedStyle(n).display === 'none'
              && n.getBoundingClientRect().height === 0;
     }));
  ok('no tab button is clickable while gated',
     await p.evaluate(() => [...document.querySelectorAll('nav.tabs button')]
       .every(b => b.offsetParent === null)));
  ok('there is a sign-in button', await p.isVisible('[data-act="signin"]'));
  ok('the sign-in button is a proper tap target',
     await p.evaluate(() => document.querySelector('[data-act="signin"]').getBoundingClientRect().height) >= 44);

  /* ---------- the privacy notice, BEFORE handing anything over ---------- */
  ok('the privacy notice is reachable before signing in', await p.isVisible('[data-act="privacy"]'));
  await p.click('[data-act="privacy"]'); await p.waitForTimeout(400);
  const privacy = await p.textContent('#app');
  ok('it says photos are stored in the United States',
     /photographs are stored in the United States/i.test(privacy));
  ok('it says the text is stored in London', /London/.test(privacy));
  ok('it says nobody else can see it', /Only you/i.test(privacy));
  ok('it says there is no tracking', /no analytics, no tracking/i.test(privacy));
  ok('it explains deletion', /Delete your account/i.test(privacy));
  ok('the privacy page does not leak the app behind it',
     !(await p.isVisible('[data-act="addMini"]')));

  /* ---------- the merge rules ---------- */
  const merge = await p.evaluate(() => {
    const out = {};
    const reset = items => { data.minis = JSON.parse(JSON.stringify(items)); };

    /* a newer edit from another device replaces the local copy */
    reset([{ id:'m1', name:'Old name', updated:1000 }]);
    out.remoteNewerWins = applyRemote('minis', { id:'m1', name:'New name', updated:2000 })
      && data.minis[0].name === 'New name';

    /* an older arrival must not clobber a newer local edit */
    reset([{ id:'m1', name:'Local edit', updated:5000 }]);
    const changed = applyRemote('minis', { id:'m1', name:'Stale', updated:3000 });
    out.localNewerSurvives = (changed === false) && data.minis[0].name === 'Local edit';

    /* an entity this device has never seen is added */
    reset([]);
    out.newEntityAdded = applyRemote('minis', { id:'m9', name:'From the Mac', updated:1 })
      && data.minis.length === 1;

    /* a tombstone removes it */
    reset([{ id:'m1', name:'Doomed', updated:1000 }]);
    out.tombstoneDeletes = applyRemote('minis', { id:'m1', deleted:true, updated:2000 })
      && data.minis.length === 0;

    /* a tombstone older than a local edit must NOT delete: the person
       edited it after deleting it elsewhere, so the edit wins */
    reset([{ id:'m1', name:'Rescued', updated:9000 }]);
    const t = applyRemote('minis', { id:'m1', deleted:true, updated:4000 });
    out.staleTombstoneIgnored = (t === false) && data.minis.length === 1;

    /* deleting something that was never here is not a change */
    reset([]);
    out.tombstoneForUnknownIsNoop = applyRemote('minis', { id:'zz', deleted:true, updated:1 }) === false;

    /* the fingerprint must ignore `updated`, or every sync would resend
       everything forever */
    out.fingerprintIgnoresStamp =
      fingerprint({ id:'a', name:'x', updated:1 }) === fingerprint({ id:'a', name:'x', updated:999 });
    out.fingerprintSeesRealChange =
      fingerprint({ id:'a', name:'x' }) !== fingerprint({ id:'a', name:'y' });

    /* the snapshot must cover every collection that syncs */
    data.minis = []; data.paints = [];
    const snap = snapshotOf(data);
    out.snapshotCoversAll = SYNC_COLLECTIONS.every(c => c in snap)
      && '_stages' in snap && '_settings' in snap;
    return out;
  });
  ok('a newer edit from another device wins', merge.remoteNewerWins);
  ok('a stale arrival does not clobber a newer local edit', merge.localNewerSurvives);
  ok('an entity from another device is added', merge.newEntityAdded);
  ok('a deletion propagates', merge.tombstoneDeletes);
  ok('a stale deletion does not destroy a newer local edit', merge.staleTombstoneIgnored);
  ok('a deletion for something unknown is a no-op', merge.tombstoneForUnknownIsNoop);
  ok('the change fingerprint ignores the timestamp', merge.fingerprintIgnoresStamp);
  ok('the change fingerprint still sees a real edit', merge.fingerprintSeesRealChange);
  ok('the snapshot covers every synced collection', merge.snapshotCoversAll);

  /* ---------- saving does not push when signed out ---------- */
  const noPush = await p.evaluate(() => {
    let pushed = false;
    const real = window.pushUp;
    syncState.on = false;
    schedulePush();
    return !pushed;
  });
  ok('saving while signed out does not try to push', noPush);

  /* ---------- the signed-in app ---------- */
  await p.evaluate(() => {
    authGate = 'in';
    syncState.user = { uid:'testuid', displayName:'Test Painter', email:'test@example.com' };
    syncState.status = 'ok'; data.settings.setupDone = true; setupChecked = true;
    state.tab = 'home';
    render();
  });
  await p.waitForTimeout(400);
  ok('once signed in the app appears', await p.isVisible('[data-act="addMini"]'));
  ok('the tab bar comes back',
     await p.evaluate(() => {
       const n = document.querySelector('nav.tabs');
       return n.hidden === false && n.getBoundingClientRect().height > 0;
     }));
  ok('the sync status is in place', !!(await p.$('#syncpill')));
  ok('it says nothing while all is well',
     await p.evaluate(() => { syncStatus('ok'); return document.getElementById('syncpill').hidden; }));
  ok('it speaks up when offline',
     await p.evaluate(() => { syncStatus('offline'); const e = document.getElementById('syncpill');
       const r = !e.hidden && /Offline/.test(e.textContent); syncStatus('ok'); return r; }));
  ok('it reads Synced', (await p.textContent('#syncpill')).trim() === 'Synced');

  /* ---------- the account screen ---------- */
  await p.evaluate(() => { state.tab = 'account'; render(); });
  await p.waitForTimeout(300);
  const acct = await p.textContent('#app');
  ok('the account screen names who is signed in', /Test Painter/.test(acct));
  ok('it offers sign out', await p.isVisible('[data-act="signout"]'));
  ok('it offers account deletion', await p.isVisible('[data-act="deleteAccount"]'));
  ok('it offers an export before deleting', await p.isVisible('[data-act="exportFirst"]'));
  ok('it says signing out deletes nothing', /does not delete anything/i.test(acct));
  ok('it warns deletion cannot be undone', /cannot be undone/i.test(acct));

  /* ---------- deletion is deliberately awkward ---------- */
  await p.click('[data-act="deleteAccount"]'); await p.waitForTimeout(400);
  ok('the delete dialog asks for confirmation', await p.isVisible('#delConfirm'));
  ok('it lists the photographs as going too', /photograph/i.test(await p.textContent('#dlgBody')));
  await p.fill('#delConfirm', 'yes');
  await p.click('[data-dlg="ok"]'); await p.waitForTimeout(400);
  ok('the wrong word does not delete anything', await p.isVisible('#delConfirm'));

  /* ---------- the menu no longer tells a lie ---------- */
  await p.evaluate(() => { document.querySelector('#dlg').close(); });
  const appSrc = await p.evaluate(() => document.documentElement.innerHTML.length > 0);
  const lie = await p.evaluate(() =>
    document.documentElement.innerHTML.includes('stored on this phone only'));
  ok('the menu no longer claims nothing is uploaded', lie === false);

  /* ---------- layout still holds ---------- */
  await p.evaluate(() => { authGate = 'out'; state.tab = 'home'; render(); });
  await p.waitForTimeout(300);
  const over = await p.evaluate(() => {
    const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.closest('.stepper')) return;
      const r = el.getBoundingClientRect();
      if (r.width && r.right > vw + 1) bad.push((el.className||el.tagName) + ' r=' + Math.round(r.right));
    });
    return bad;
  });
  ok('the gate does not overflow at 390px', over.length === 0, over.slice(0,3).join(', '));
  await p.close();

  const p2 = await b.newPage({ viewport:{ width:320, height:640 } });
  await p2.goto(URL); await p2.waitForTimeout(2000);
  await p2.evaluate(() => { document.documentElement.style.fontSize = '32px'; });
  await p2.waitForTimeout(400);
  const over2 = await p2.evaluate(() => {
    const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.closest('.stepper')) return;
      const r = el.getBoundingClientRect();
      if (r.width && r.right > vw + 1) bad.push((el.className||el.tagName) + ' r=' + Math.round(r.right));
    });
    return bad;
  });
  ok('the gate reflows at 320px and 200% text', over2.length === 0, over2.slice(0,3).join(', '));
  await p2.close();

  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('\n  FAILURES:'); fail.forEach(f => console.log('    - ' + f)); process.exit(1); }
})();
