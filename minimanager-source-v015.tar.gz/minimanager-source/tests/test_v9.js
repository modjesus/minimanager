/* v011: fewer things on show. Every option that moved must still be reachable,
   and the two iPhone glitches must stay fixed. */
const { chromium, webkit } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');
const SHOT = __dirname + '/';
let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                          else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

const SEED = `
authGate='in'; syncState.user={uid:'t',displayName:'Joe',email:'j@e.com'};
syncState.status='ok'; syncState.firstPullDone=true; data.settings.setupDone=true; setupChecked=true;
const s1={id:'s1',name:'Warhammer 40,000'}, s2={id:'s2',name:'Warhammer: Age of Sigmar'}, s3={id:'s3',name:'Necromunda'};
data.systems=[s1,s2,s3]; data.factions=[{id:'f1',sys:'s1',name:'Death Guard'}];
data.minis=[];
const st=data.stages;
for(let i=0;i<30;i++) data.minis.push({id:'m'+i,name:'Model '+i,sys:['s1','s2','s3'][i%3],fac:i%3?'':'f1',
  total:5,done:i%8===7?5:1,stage:st[i%8],price:i%4?10+i:null,acquired:i%5?'202'+(i%6)+'-0'+(1+i%9)+'-01':'',photos:[],updated:i});
data.paints=[]; ['Have it','Running low','Out','Wishlist','Have it'].forEach((k,i)=>data.paints.push({id:'p'+i,name:'Paint '+i,brand:'Citadel',range:'Base',hex:'#884422',stock:k}));
data.recipes=[{id:'r1',title:'Death Guard armour',category:'armour',steps:[{id:'x',technique:'Wash',paintIds:[]}]}];
state.tab='home'; state.openMini=null; render();
`;

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForTimeout(2200);
  await p.evaluate(SEED); await p.waitForTimeout(400);

  /* ---------- top bar ---------- */
  ok('the light/dark button is gone from the top bar', !(await p.$('#themeBtn')));
  ok('"Synced" says nothing while all is well', await p.evaluate(() => document.getElementById('syncpill').hidden));
  ok('Home has no Add in the top bar', await p.evaluate(() => document.getElementById('actslot').innerHTML === ''));

  /* ---------- home ---------- */
  const qa = await p.evaluate(() => [...document.querySelectorAll('#app button')].map(b => b.dataset.act).filter(Boolean));
  ok('Home keeps Add a miniature and Pick something', qa.includes('addMini') && qa.includes('pick'));
  ok('the other four quick actions are gone from Home',
     !['shop','addPaint','newRecipe','quickSwatch'].some(a => qa.includes(a)), qa.join(','));
  await p.screenshot({ path: SHOT + 'V11_home.png' });

  /* ---------- collection ---------- */
  await p.click('#tabs [data-tab="coll"]'); await p.waitForTimeout(300);
  ok('Collection: Add is in the top bar', await p.isVisible('#actslot [data-act="addHere"]'));
  ok('Collection: no heading repeating the title', !(await p.$('#app h2')));
  ok('Collection: no filter chips on the screen until asked for',
     (await p.$$('#app [data-fstage], #app [data-sort]')).length === 0);
  ok('Collection: one Filter button', await p.isVisible('[data-act="openFilter"]'));
  await p.screenshot({ path: SHOT + 'V11_coll.png' });

  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(400);
  ok('the panel opens', await p.evaluate(() => $('#dlg').open && $('#dlg').classList.contains('sheet')));
  ok('it has every stage and both sorts',
     (await p.$$('#dlg [data-fstage]')).length === 8 && (await p.$$('#dlg [data-sort]')).length === 2);
  ok('it sits at the bottom of a phone screen',
     await p.evaluate(() => { const r = $('#dlg').getBoundingClientRect(); return Math.abs(r.bottom - innerHeight) < 2 && r.left < 1; }));
  await p.screenshot({ path: SHOT + 'V11_sheet.png' });
  await p.click('#dlg [data-fstage="Unbuilt"]'); await p.waitForTimeout(300);
  ok('tapping a stage applies straight away', await p.evaluate(() => state.fStage) === 'Unbuilt');
  ok('the chip shows as on, in place', await p.getAttribute('#dlg [data-fstage="Unbuilt"]', 'aria-pressed') === 'true');
  ok('the button counts what will show', /Show 4 model entries/.test(await p.textContent('#dlg [data-dlg="ok"]')),
     await p.textContent('#dlg [data-dlg="ok"]'));
  await p.click('#dlg [data-sort="waiting"]'); await p.waitForTimeout(300);
  ok('the panel stays open while choosing', await p.evaluate(() => $('#dlg').open));
  await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(300);
  ok('Show closes it', await p.evaluate(() => !$('#dlg').open && !$('#dlg').classList.contains('sheet')));
  ok('the active filters show as chips with an ×', (await p.$$('#app [data-act="unfilter"]')).length === 2);
  ok('the Filter button shows how many are on', (await p.textContent('.fopen .fc')).trim() === '2');
  await p.screenshot({ path: SHOT + 'V11_coll_filtered.png' });
  await p.click('#app [data-act="unfilter"][data-k="sort"]'); await p.waitForTimeout(250);
  ok('× removes just that one', await p.evaluate(() => state.sort === '' && state.fStage === 'Unbuilt'));
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(300);
  await p.click('#dlg [data-act="unfilterAll"]'); await p.waitForTimeout(250);
  ok('Clear all filters clears them', await p.evaluate(() => !state.fStage && !state.sort));
  await p.click('#dlg [data-dlg="cancel"]'); await p.waitForTimeout(250);
  ok('the × in the panel header closes it', await p.evaluate(() => !$('#dlg').open));

  /* ---------- paints ---------- */
  await p.click('#tabs [data-tab="paints"]'); await p.waitForTimeout(300);
  ok('Paints: Add is in the top bar', await p.isVisible('#actslot [data-act="addPaint"]'));
  ok('Paints: the planner, comparison and Add several are off the screen',
     !(await p.$('#app [data-act="openPlanner"], #app [data-act="openCompare"], #app [data-act="setupPaintsOnly"]')));
  ok('Paints: the shopping list is one line', await p.isVisible('#app .shopline[data-act="shop"]'));
  ok('Paints: stock chips are behind Filter', !(await p.$('#app [data-fstock]')));
  await p.screenshot({ path: SHOT + 'V11_paints.png' });
  await p.evaluate(() => { data.settings.theme='dark'; applyTheme(); });
  await p.screenshot({ path: SHOT + 'V11_paints_dark.png' });
  await p.evaluate(() => { data.settings.theme=''; applyTheme(); });
  await p.click(".shopline"); await p.waitForTimeout(300);
  ok('the shopping line opens the shop', await p.evaluate(() => state.tab) === 'shop');

  /* everything moved must still be reachable from the menu */
  await p.click('#tabs [data-tab="home"]'); await p.waitForTimeout(200);
  await p.click('#moreBtn'); await p.waitForTimeout(300);
  for (const a of ['openPlanner','openCompare','setupPaintsOnly','setupStart'])
    ok('the menu offers ' + a, await p.isVisible('#dlg [data-act="' + a + '"]'));
  ok('the menu has the three appearance choices', (await p.$$('#dlg [data-act="themeSet"]')).length === 3);
  await p.click('#dlg [data-act="themeSet"][data-v="dark"]'); await p.waitForTimeout(250);
  ok('Dark applies at once', await p.evaluate(() => data.settings.theme === 'dark' && document.documentElement.dataset.theme === 'dark'));
  ok('...and shows as chosen without closing the menu',
     await p.evaluate(() => $('#dlg').open && $('#dlg [data-v="dark"]').getAttribute('aria-pressed') === 'true'));
  await p.click('#dlg [data-act="themeSet"][data-v=""]'); await p.waitForTimeout(250);
  ok('Match my device clears it', await p.evaluate(() => data.settings.theme === ''));
  await p.click('#dlg [data-act="openPlanner"]'); await p.waitForTimeout(300);
  ok('the planner opens from the menu, from any tab', await p.evaluate(() => state.tab === 'paints' && state.sub === 'planner' && !$('#dlg').open));
  ok('...with no Add in the top bar there', await p.evaluate(() => document.getElementById('actslot').innerHTML === ''));
  await p.evaluate(() => { state.sub = null; render(); });

  /* ---------- recipes ---------- */
  await p.click('#tabs [data-tab="recipes"]'); await p.waitForTimeout(300);
  ok('Recipes: New is in the top bar', await p.isVisible('#actslot [data-act="newRecipe"]'));

  /* ---------- the two iPhone glitches ---------- */
  ok('numbers use the body face, not a typewriter face',
     await p.evaluate(() => !/mono|Menlo|Courier/i.test(getComputedStyle(document.querySelector('.num') || document.body).fontFamily)));

  /* ---------- reflow ---------- */
  for (const w of [320, 390]){
    await p.setViewportSize({ width:w, height:740 });
    for (const t of ['home','coll','paints','recipes']){
      await p.evaluate(t2 => { state.tab=t2; render(); }, t); await p.waitForTimeout(150);
      const over = await p.evaluate(() => document.documentElement.scrollWidth - innerWidth);
      ok(`no sideways scroll on ${t} at ${w}px`, over <= 0, over + 'px');
    }
  }
  await p.evaluate(() => { state.tab='coll'; render(); }); await p.click('[data-act="openFilter"]'); await p.waitForTimeout(300);
  ok('the panel fits at 320px', await p.evaluate(() => { const d=$('#dlg'); return d.scrollWidth <= d.clientWidth + 1; }));
  await p.evaluate(() => $('#dlg').close());
  await p.setViewportSize({ width:1280, height:800 });
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(300);
  ok('on a wide screen it is a centred dialog, not a full-width strip',
     await p.evaluate(() => { const r = $('#dlg').getBoundingClientRect(); return r.width < 700 && r.left > 100; }));
  await p.evaluate(() => $('#dlg').close());
  ok('no page errors', errs.length === 0, errs.join(' | '));
  /* Four bugs in this app have been a new class quietly sharing a name with
     an old one (.lab, .chip, .srow/.bar, and .shoprow in this very release). */
  const src = require('fs').readFileSync(require('path').join(__dirname,'..','build','index.html'), 'utf8');
  for (const c of ['backlink','gamecard','crumb','mrow','shelf','findrow','fopen','fc','fsec','fclear','shopline','sl','on-x','sr-only']){
    const n = (src.match(new RegExp('\\.' + c.replace('-', '\\-') + '(?![\\w-])\\s*[{,]', 'g')) || []).length;
    ok(`.${c} is defined in exactly one rule`, n === 1, n + ' rules');
  }
  await b.close();

  /* ---------- WebKit: the engine iPhones use ---------- */
  try {
    const w = await webkit.launch();
    const q = await w.newPage({ viewport:{ width:390, height:844 } });
    await q.goto(URL); await q.waitForTimeout(2200);
    await q.evaluate(SEED); await q.evaluate(() => { state.tab='recipes'; render(); }); await q.waitForTimeout(300);
    const c = await q.evaluate(() => {
      const bt = document.querySelector('#app button b, #app button .nm, #app button');
      return [getComputedStyle(bt).color, getComputedStyle(document.body).color];
    });
    ok('WebKit: recipe names take the app colour, not system blue', c[0] === c[1], c.join(' vs '));
    await q.screenshot({ path: SHOT + 'V11_recipes_webkit.png' });
    await w.close();
  } catch (e) { console.log('  (WebKit not available: ' + e.message.split('\n')[0] + ')'); }

  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('  FAILURES:'); fail.forEach(f => console.log('   - ' + f)); process.exit(1); }
})();
