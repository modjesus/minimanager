# MiniManager source

Everything needed to rebuild and test the app that runs at minimanager.co.uk.
The site itself is the built `index.html` and `sw.js` at the top of the repo;
this folder is what they are built from.

| Folder / file | What it is |
| --- | --- |
| `src/` | The app: `index.html` (page and styles, with placeholders), `app.js`, `sync.js`, `presets.js`, `sw.js`, `firebase-config.js`, and the Firebase security rules (`firestore.rules`, `storage.rules`) |
| `tests/` | The automated checks, one file per release batch (`test_v3.js` … `test_v13.js`) |
| `build.py` | Puts it all into one file in `build/` and runs the build checks |
| `extract_assets.py` | Recreates `assets/` (catalogue, Firebase bundle, fonts, icon) from any built `index.html` |

To rebuild and test:

```
python3 extract_assets.py ../index.html
python3 build.py
npm i playwright@1 && for t in tests/test_v*.js; do node $t; done
```

Releases: copy `build/index.html` and `build/sw.js` to the top of the repo.
`APP_VERSION` in `src/app.js` and `CACHE` in `src/sw.js` must change together.
