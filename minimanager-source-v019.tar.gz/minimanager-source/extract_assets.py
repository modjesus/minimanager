"""Recreate assets/ from any built MiniManager index.html (for example the live
one in the repo). The build needs five things that are too big to keep as
separate source files: the paint catalogue, the Firebase bundle, two fonts and
the app icon. Every built index.html carries all five, so one can always be
recovered from the other.

Run:  python3 extract_assets.py ../index.html
"""
import base64, pathlib, re, sys

src = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "../index.html").read_text(encoding="utf-8")
out = pathlib.Path(__file__).resolve().parent / "assets"
out.mkdir(exist_ok=True)

def one(pattern, what):
    m = re.search(pattern, src, re.S)
    if not m: sys.exit(f"could not find {what}")
    return m.group(1)

icon = one(r'<link rel="icon" href="data:image/png;base64,([^"]+)"', "the app icon")
(out / "app-icon.png").write_bytes(base64.b64decode(icon))
(out / "indira.woff2").write_bytes(base64.b64decode(one(r"font-family:'Indira K';src:url\(data:font/woff2;base64,([^)]+)\)", "Indira K")))
(out / "inter.woff2").write_bytes(base64.b64decode(one(r"font-family:'Inter';src:url\(data:font/woff2;base64,([^)]+)\)", "Inter")))
cat = one(r'<script id="catalogue" type="application/json">(.*?)</script>', "the paint catalogue")
(out / "catalogue.json").write_text(cat.replace("\\u003c", "<"), encoding="utf-8")
blocks = re.findall(r"<script>\n(.*?)\n</script>", src, re.S)
fb = [b for b in blocks if "window.FB=" in b or "window.FB =" in b]
if not fb: sys.exit("could not find the Firebase bundle")
(out / "firebase-bundle.js").write_text(fb[0], encoding="utf-8")
for f in sorted(out.iterdir()): print(f"  {f.name:20s} {f.stat().st_size//1024} KB")
