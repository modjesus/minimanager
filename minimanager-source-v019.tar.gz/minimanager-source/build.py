"""Assemble MiniManager into one file (build/index.html + build/sw.js), then run every mandatory check.

Run:  python3 extract_assets.py <a built index.html>   (once, to recreate assets/)
      python3 build.py
"""
import base64, json, pathlib, re, subprocess, sys

HERE = pathlib.Path(__file__).resolve().parent
SRC = HERE / "src"
ASSETS = HERE / "assets"
OUT = HERE / "build"
OUT.mkdir(exist_ok=True)

b64 = lambda p: base64.b64encode(pathlib.Path(p).read_bytes()).decode()

html    = (SRC / "index.html").read_text(encoding="utf-8")
presets = (SRC / "presets.js").read_text(encoding="utf-8")
app     = (SRC / "app.js").read_text(encoding="utf-8")
sync    = (SRC / "sync.js").read_text(encoding="utf-8")
fbconf  = (SRC / "firebase-config.js").read_text(encoding="utf-8")
fbsdk   = (ASSETS / "firebase-bundle.js").read_text(encoding="utf-8")
cat     = (ASSETS / "catalogue.json").read_text(encoding="utf-8")

# `</script>` inside the JSON would end the block early; escape the angle bracket.
cat = cat.replace("<", "\\u003c")

subs = {
    "__INDIRA__": b64(ASSETS / "indira.woff2"),
    "__INTER__": b64(ASSETS / "inter.woff2"),
    "__ICON__": "data:image/png;base64," + b64(ASSETS / "app-icon.png"),
    "__CATALOGUE__": cat,
}
for token, value in subs.items():
    n = html.count(token)
    assert n >= 1, f"placeholder {token} not found"
    html = html.replace(token, value)
    print(f"  injected {token:16s} x{n}  ({len(value)//1024} KB)")

# Order is load-bearing. app.js runs the boot sequence at the end of its own
# body and calls authStart() there, so everything it calls must already be
# defined: the SDK, the config, the presets and the sync module, in that order.
for tag, code in (('<script src="firebase-bundle.js"></script>', fbsdk),
                  ('<script src="firebase-config.js"></script>', fbconf),
                  ('<script src="presets.js"></script>', presets),
                  ('<script src="sync.js"></script>', sync),
                  ('<script src="app.js"></script>', app)):
    assert tag in html, f"{tag} not found"
    html = html.replace(tag, "<script>\n" + code + "\n</script>")
for token in subs:
    assert token not in html, f"{token} survived"

(OUT / "index.html").write_text(html, encoding="utf-8")
(OUT / "sw.js").write_text((SRC / "sw.js").read_text(encoding="utf-8"), encoding="utf-8")
size = (OUT / "index.html").stat().st_size
print(f"\n  built  {size/1024/1024:.2f} MB  {html.count(chr(10))+1} lines\n")

fail = []

# ---- 1. every script block parses -----------------------------------------
blocks = re.findall(r'<script(?![^>]*\bsrc=)(?![^>]*application/json)[^>]*>(.*?)</script>', html, re.S)
print(f"  1. script blocks: {len(blocks)}")
for i, b in enumerate(blocks):
    p = pathlib.Path(OUT / f"_chk{i}.js"); p.write_text(b, encoding="utf-8")
    r = subprocess.run(["node", "--check", str(p)], capture_output=True, text=True)
    if r.returncode: fail.append(f"script {i}: {r.stderr.strip()[:300]}")
    else: print(f"     block {i}: parses ({b.count(chr(10))+1} lines)")

# ---- 2. style blocks balanced ---------------------------------------------
styles = re.findall(r"<style[^>]*>(.*?)</style>", html, re.S)
print(f"  2. style blocks: {len(styles)}")
for i, b in enumerate(styles):
    o, c = b.count("{"), b.count("}")
    if o != c: fail.append(f"style {i}: {o} open vs {c} close")
    else: print(f"     block {i}: balanced ({o} rules)")

# ---- 3. embedded JSON parses ----------------------------------------------
js = re.findall(r'<script[^>]*application/json[^>]*>(.*?)</script>', html, re.S)
print(f"  3. JSON blocks: {len(js)}")
for i, b in enumerate(js):
    try:
        d = json.loads(b)
        print(f"     block {i}: parses, {len(d['p'].splitlines())} paints, {len(d['b'])} brands")
    except Exception as e:
        fail.append(f"json {i}: {e}")

# ---- 4. the two version numbers agree -------------------------------------
app_v = re.search(r"const APP_VERSION = '(v\d+)'", html)
sw = (OUT / "sw.js").read_text(encoding="utf-8")
cache = re.search(r"const CACHE = '([^']+)'", sw)
print("  4. version numbers")
if not app_v: fail.append("APP_VERSION missing")
elif not cache: fail.append("sw CACHE missing")
elif app_v.group(1) not in cache.group(1):
    fail.append(f"APP_VERSION {app_v.group(1)} not in CACHE {cache.group(1)}")
else: print(f"     APP_VERSION {app_v.group(1)} == CACHE {cache.group(1)}")

r = subprocess.run(["node", "--check", str(OUT / "sw.js")], capture_output=True, text=True)
if r.returncode: fail.append("sw.js: " + r.stderr.strip()[:200])
else: print("     sw.js parses")

# ---- 5. contrast, including the new help panels ---------------------------
def lin(c):
    c /= 255
    return c/12.92 if c <= 0.03928 else ((c+0.055)/1.055)**2.4
def L(h):
    h = h.lstrip("#"); r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
    return 0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b)
def cr(a, b):
    la, lb = L(a), L(b); hi, lo = max(la, lb), min(la, lb)
    return (hi+0.05)/(lo+0.05)

print("  5. contrast of the fixed and new pairings")
checks = [("placeholder text: Ink Navy on Warm Grey", "#0F2A44", "#CFC7BA", 4.5),
          ("finished mark: Ink Navy on Gold",         "#0F2A44", "#C6A962", 4.5),
          ("body text: Ink Navy on Ivory",            "#0F2A44", "#FDF8EF", 4.5),
          ("dark body: Ivory on dark background",     "#FDF8EF", "#081C2E", 4.5),
          ("help text: Ink Navy on help panel",       "#0F2A44", "#E9E9DF", 4.5),
          ("help dd: secondary on help panel",        "#52606B", "#E9E9DF", 4.5),
          ("help dark: Ivory on dark help panel",     "#FDF8EF", "#213947", 4.5),
          ("help dark dd: secondary on dark help",    "#B6C5CF", "#213947", 4.5),
          ("help border vs page",                     "#C7D0C4", "#FDF8EF", 1.0),
          ("chip pressed: Ivory on Ink Navy",         "#FDF8EF", "#0F2A44", 4.5),
          ("chip rest: secondary on surface",         "#52606B", "#FFFFFF", 4.5),
          ("danger text on its panel",                "#A84743", "#F5E6DE", 4.5),
          ("danger text on ivory",                    "#A84743", "#FDF8EF", 4.5),
          ("danger button: white on danger",          "#FFFFFF", "#A84743", 4.5),
          ("danger dark: light red on dark panel",    "#F2A6A2", "#3A1F24", 4.5),
          ("danger dark on dark background",          "#F2A6A2", "#081C2E", 4.5),
          ("sync pill ok: success on surface",        "#47745E", "#FFFFFF", 4.5),
          ("privacy/link button colour on ivory",     "#2F719D", "#FDF8EF", 4.5),
          # v009 shape language. The brand gold measures 2.15 on ivory, so every
          # gold WORD uses --gold-ink instead; --gold stays for drops and rules.
          ("eyebrow: gold-ink on ivory",              "#7F5E10", "#FDF8EF", 4.5),
          ("eyebrow: gold-ink on surface",            "#7F5E10", "#FFFFFF", 4.5),
          ("eyebrow dark: brand gold on dark surface","#C6A962", "#142B3E", 4.5),
          ("eyebrow dark: brand gold on dark page",   "#C6A962", "#081C2E", 4.5),
          ("ladder current row text on gold tint",    "#0F2A44", "#F6F2E7", 4.5),
          ("ladder 'You are here' on gold tint",      "#7F5E10", "#F6F2E7", 4.5),
          ("ladder row, dark: ivory on gold tint",     "#FDF8EF", "#2F3E43", 4.5),
          ("ladder tag, dark: gold on gold tint",      "#C6A962", "#2F3E43", 4.5),
          ("tile caption: ivory on the photo fade",   "#FDF8EF", "#15232F", 4.5),
          ("shop 'Out': danger ink on surface",       "#A84743", "#FFFFFF", 4.5),
          # The brand gold must NOT be used for text; this records why.
          ("(reference) brand gold on ivory FAILS",   "#C6A962", "#FDF8EF", 1.0)]
for label, a, b, need in checks:
    v = cr(a, b)
    ok = v >= need
    print(f"     {label:42s} {v:5.2f}  {'PASS' if ok else 'FAIL'}")
    if not ok: fail.append(f"contrast {label}: {v:.2f} < {need}")

# ---- 5b. every drop/pot class is actually sized -----------------------------
# An SVG with no CSS width fills its container. A dropSvg() or potSvg() call
# naming a class the stylesheet never sizes turns a list row into a giant
# triangle -- which happened, and which every behaviour test passed.
print("  5b. every drop and pot class is sized")
svg_classes = set(re.findall(r"dropSvg\(\s*'([a-zA-Z][\w-]*)'", app))
svg_classes |= set(re.findall(r"potSvg\([^,]+,\s*'([a-zA-Z][\w-]*)", app))
# potSvg's default when no class is passed
if re.search(r"potSvg\([^,)]+\)", app): svg_classes.add('pot')
# a class token may carry a modifier, e.g. 'sdrop now'
base = set()
for c in svg_classes:
    base.add(c.split()[0])
for c in sorted(base):
    sized = re.search(r"\.%s\b[^{]*\{[^}]*width\s*:" % re.escape(c), "".join(styles))
    if sized:
        print("     .%-10s sized" % c)
    else:
        print("     .%-10s NOT SIZED" % c)
        fail.append("svg class .%s is used but never given a width" % c)

# ---- 6. the presets are sane ----------------------------------------------
print("  6. presets")
sysn = re.findall(r"\{ name:'([^']+)', groups:", presets)
print(f"     {len(sysn)} game systems")
if len(sysn) < 10: fail.append(f"only {len(sysn)} systems")
ucs = re.findall(r"\{ id:'(u-[a-z0-9-]+)',", presets)
if len(ucs) != len(set(ucs)): fail.append("duplicate undercoat id")
else: print(f"     {len(ucs)} undercoats, all ids unique")
for key in re.findall(r"help:'([a-zA-Z]+)'", app):
    if f"\n  {key}:" not in presets and f"  {key}: " not in presets:
        fail.append(f"help key '{key}' used in app.js but not defined in presets.js")
for key in re.findall(r"helpBlock\('([a-zA-Z]+)'\)", app) + re.findall(r"'([a-zA-Z]+)'\)\}", ""):
    if f"{key}:" not in presets:
        fail.append(f"helpBlock key '{key}' not defined")
print("     help keys resolve")

# ---- 7. the sync wiring actually connects -----------------------------------
print("  7. sync wiring")
need_in_app = ["authStart","startSync","stopSync","schedulePush","syncState",
               "syncPill","doSignIn","doSignOut","friendlyAuthError",
               "deleteEverything","pullPhoto","pushUp","syncStatus"]
for n in need_in_app:
    if n not in sync: fail.append(f"app.js calls {n} but sync.js does not define it")
# Look for a definition, not a call: several of these are arrow constants
# (const clearPhotos = () => ...) and do not contain "name(".
import re as _re
need_in_sync = ["arr","render","getPhoto","putPhoto","deadline","saveLocalOnly",
                "clearPhotos","applyTheme","openDialog","toast","esc","backBtn"]
for n in need_in_sync:
    if not _re.search(r"(function\s+%s\b|const\s+%s\s*=|let\s+%s\s*=)" % (n,n,n), app):
        fail.append(f"sync.js uses {n} but app.js does not define it")
if "data" not in app: fail.append("app.js has no data object")
if "window.FB" not in fbsdk: fail.append("firebase bundle does not expose window.FB")
if "FIREBASE_CONFIG" not in fbconf: fail.append("firebase config missing")
# the old lie must be gone
if "stored on this phone only" in app:
    fail.append("the menu still claims nothing is uploaded, which is no longer true")
# script order
order = [html.find(m) for m in ["window.FB","FIREBASE_CONFIG =","const SYSTEMS","SYNC_COLLECTIONS","const APP_VERSION"]]
if any(o == -1 for o in order): fail.append("a required block is missing from the build")
elif order != sorted(order): fail.append(f"scripts are inlined in the wrong order: {order}")
else: print("     SDK, config, presets, sync, app \u2014 in that order")
print("     every cross-file call resolves")

print()
if fail:
    print("  FAILED:"); [print("    - " + f) for f in fail]; sys.exit(1)
print("  ALL CHECKS PASSED")
