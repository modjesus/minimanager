/* ===========================================================================
   Sign-in and sync.

   The shape of this, and why:

   The app already keeps everything in `data` in memory and mirrors it to
   localStorage. That works offline, it is fast, and it is well tested. So
   this file does not replace it. It sits beside it and does two jobs:
   push local changes up, and fold remote changes down.

   Pushing works by comparing the current data against a snapshot of what was
   last sent, rather than by marking things dirty as they change. Dirty flags
   would mean touching every place in the app that edits anything, and the
   one place I forgot would silently never sync. A diff cannot be forgotten.

   Folding down uses last-write-wins on a millisecond `updated` stamp, per
   entity. Two devices editing two different miniatures both win. Two devices
   editing the SAME miniature, the later edit wins and the earlier is lost.
   That is a real limitation and the deploy note says so plainly; anything
   better means merge conflicts a person has to resolve, which is the wrong
   trade for a painting app.

   Deletes are tombstones. A deleted entity is kept as {id, deleted:true,
   updated} rather than removed, because an entity that simply vanishes from
   one device looks identical to one that has not arrived yet on the other,
   and the other device would helpfully recreate it forever.
   =========================================================================== */

/* Adding to this list is only half the job: firestore.rules whitelists the
   collection names a client may write, so a new one here without a matching
   rules change saves locally and silently never reaches the account. */
const SYNC_COLLECTIONS = ['minis','paints','recipes','swatches','systems',
                          'factions','undercoats','links','supplies','wishlist'];

let fb = null;              /* the initialised Firebase handles */
let unsubscribes = [];
let lastPushed = null;      /* snapshot of what we last sent, for diffing */
let syncState = { on:false, user:null, status:'off', pending:0, error:null,
  /* True only once EVERY collection has reported at least one snapshot.
     'ok' is not that signal: it is set by whichever collection answers
     first, so a device signing in for the first time can read "ok" with a
     mostly empty local copy while the rest is still arriving. Anything that
     asks "is this collection empty?" has to wait for this instead. */
  firstPullDone:false };
let pulledOnce = new Set();
let remoteSeen = {};        /* ids the account has sent, per collection, this session */
let remoteFp = {};          /* what the account holds for each of them */
let pushTimer = null;
let photoQueue = new Set();

function syncStatus(status, extra){
  syncState.status = status;
  if (extra) Object.assign(syncState, extra);
  const el = document.getElementById('syncpill');
  if (el) el.replaceWith(syncPill());
}

/* --- starting up ---------------------------------------------------------- */

function fbInit(){
  if (fb) return fb;
  if (typeof window.FB === 'undefined') throw new Error('Firebase bundle missing');
  const F = window.FB;
  const app = F.initializeApp(FIREBASE_CONFIG);
  const auth = F.getAuth(app);

  /* Firestore's own cache is what makes the app work on a train. It queues
     writes made offline and replays them on reconnect, which is the hard
     part of sync and not something worth reimplementing. */
  const db = F.initializeFirestore(app, {
    localCache: F.persistentLocalCache({ tabManager: F.persistentMultipleTabManager() })
  });
  const storage = F.getStorage(app);
  fb = { F, app, auth, db, storage };
  return fb;
}

async function authStart(onUser){
  const { F, auth } = fbInit();
  /* Local persistence, so closing the app does not sign you out. Without
     this the app would demand a sign-in every launch, and a required
     sign-in that cannot be satisfied offline is an app that will not open. */
  try { await F.setPersistence(auth, F.browserLocalPersistence); } catch (e) {}
  /* A redirect sign-in lands back here; collect it before deciding state. */
  try { await F.getRedirectResult(auth); } catch (e) { syncState.error = friendlyAuthError(e); }
  F.onAuthStateChanged(auth, onUser);
}

function friendlyAuthError(e){
  const c = (e && e.code) || '';
  if (c.includes('popup-closed') || c.includes('cancelled-popup')) return 'Sign-in was closed before it finished.';
  if (c.includes('popup-blocked')) return 'Your browser blocked the sign-in window.';
  if (c.includes('network')) return 'No connection, so sign-in could not complete.';
  if (c.includes('unauthorized-domain')) return 'This address is not authorised for sign-in yet.';
  if (c.includes('operation-not-allowed')) return 'Google sign-in is not switched on for this app.';
  return 'Sign-in did not work. ' + (e && e.message ? e.message : '');
}

async function doSignIn(){
  const { F, auth } = fbInit();
  const provider = new F.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  try {
    await F.signInWithPopup(auth, provider);
  } catch (e) {
    const c = (e && e.code) || '';
    /* A home-screen app on iOS often cannot open a popup at all. Falling
       back to a redirect is the only way in on that platform. */
    if (c.includes('popup-blocked') || c.includes('popup-closed') ||
        c.includes('operation-not-supported')){
      try { await F.signInWithRedirect(auth, provider); return; }
      catch (e2) { throw e2; }
    }
    throw e;
  }
}

async function doSignOut(){
  stopSync();
  const { F, auth } = fbInit();
  await F.signOut(auth);
}

/* --- the diff ------------------------------------------------------------- */

/* A stable string for one entity, used only to decide "did this change". */
function fingerprint(o){
  const keys = Object.keys(o).filter(k => k !== 'updated').sort();
  return hash53(JSON.stringify(keys.map(k => [k, o[k]])));
}
/* A short, stable digest of a record, so the record of "what the account
   already has" can be kept on the device without doubling its storage. */
function hash53(str){
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < str.length; i++){
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}

/* --- what the account already has ------------------------------------------
   Kept per account on this device, and only ever moved forward by a
   successful send or by something arriving from the account. Starting from
   it means a launch sends only what was edited here since the last sync.

   Before v015 a launch started from nothing, so every record on the device
   looked new and was sent stamped "now" — before anything had downloaded.
   A phone left out of date for a week would overwrite newer edits made on
   another device. That is what this replaces. */
const baselineKey = uid => 'mm.synced.' + uid;
function loadBaseline(uid){
  try { const v = JSON.parse(localStorage.getItem(baselineKey(uid)) || 'null'); return v && typeof v === 'object' ? v : null; }
  catch (e) { return null; }
}
function saveBaseline(){
  if (!syncState.user || !lastPushed) return;
  try { localStorage.setItem(baselineKey(syncState.user.uid), JSON.stringify(lastPushed)); } catch (e) {}
}

function snapshotOf(d){
  const s = {};
  SYNC_COLLECTIONS.forEach(c => {
    s[c] = {};
    arr(d[c]).forEach(x => { if (x && x.id) s[c][x.id] = fingerprint(x); });
  });
  s._stages = hash53(JSON.stringify(arr(d.stages)));
  s._settings = hash53(JSON.stringify(d.settings || {}));
  return s;
}

/* --- pushing up ----------------------------------------------------------- */

function schedulePush(){
  if (!syncState.on) return;
  clearTimeout(pushTimer);
  /* Coalesce. Typing in a notes field fires save() on every keystroke, and
     one write per keystroke is both slow and expensive. */
  pushTimer = setTimeout(() => { pushUp().catch(() => {}); }, 1200);
}

async function pushUp(){
  if (!syncState.on || !syncState.user) return;
  /* Nothing is sent until this device knows what the account already has:
     either from the record kept here, or from the first full download. */
  if (!syncState.baselineReady) return;
  const { F, db } = fb;
  const uid = syncState.user.uid;
  const now = snapshotOf(data);
  const prev = lastPushed || { _stages:null, _settings:null };
  const writes = [];

  SYNC_COLLECTIONS.forEach(c => {
    const before = (prev[c] || {});
    const after = now[c];
    arr(data[c]).forEach(x => {
      if (!x || !x.id) return;
      if (before[x.id] !== after[x.id]){
        /* Stamp the entity that actually changed, on the local object too.
           Without a stamp, applyRemote() treats it as older than anything
           and the other device's copy would always overwrite this edit.
           Most entities in the app never had an `updated` field at all. */
        x.updated = Date.now();
        writes.push(['set', `users/${uid}/${c}/${x.id}`, Object.assign({}, x)]);
      }
    });
    /* Anything we sent before and no longer hold is a delete. Tombstone it
       rather than removing it, so other devices learn about the deletion. */
    Object.keys(before).forEach(id => {
      if (!(id in after)) writes.push(['set', `users/${uid}/${c}/${id}`,
        { id, deleted:true, updated: Date.now() }, 'delete']);
    });
  });

  /* A safety net. Deleting more than 25 things in one go, or emptying a
     whole list, only happens on
     purpose through Restore a backup, which says so first. Anything else
     that looks like a mass delete (a device whose local copy was lost or
     damaged) is not sent; the account keeps them and they come back to
     this device on the next launch. */
  const deletes = writes.filter(w => w[3] === 'delete').length;
  /* Also a whole list emptied at once (5 or more records gone, none left). */
  const emptied = SYNC_COLLECTIONS.some(c => Object.keys(prev[c] || {}).length >= 5 && !Object.keys(now[c]).length);
  if ((deletes > 25 || emptied) && !syncState.allowMassDelete){
    console.warn('MiniManager: held back ' + deletes + ' deletions that looked accidental');
    for (let i = writes.length - 1; i >= 0; i--) if (writes[i][3] === 'delete') writes.splice(i, 1);
  }
  syncState.allowMassDelete = false;

  if (now._stages !== prev._stages)
    writes.push(['set', `users/${uid}/stages/list`, { items: arr(data.stages), updated: Date.now() }]);
  if (now._settings !== prev._settings)
    writes.push(['set', `users/${uid}/settings/app`, Object.assign({}, data.settings, { updated: Date.now() })]);

  if (!writes.length) return;

  syncStatus('syncing', { pending: writes.length });
  try {
    /* Firestore batches cap at 500 operations. */
    for (let i = 0; i < writes.length; i += 400){
      const batch = F.writeBatch(db);
      writes.slice(i, i + 400).forEach(w => {
        const parts = w[1].split('/');
        batch.set(F.doc(db, ...parts), w[2], { merge: false });
      });
      await batch.commit();
    }
    lastPushed = now;
    saveBaseline();
    syncStatus('ok', { pending: 0, error: null });
  } catch (e) {
    /* Offline is not an error. Firestore has queued the writes and will
       send them itself; saying "failed" here would be a lie. */
    syncStatus(navigator.onLine ? 'error' : 'offline',
      { error: navigator.onLine ? (e.message || 'Could not save to your account.') : null });
  }
  pushPhotos().catch(() => {});
  flushCloudDeletes().catch(() => {});
}

/* --- folding down --------------------------------------------------------- */

function startSync(user){
  stopSync();
  syncState.on = true;
  syncState.user = user;
  syncState.firstPullDone = false;
  syncState.baselineReady = false;
  pulledOnce = new Set();
  remoteSeen = {}; remoteFp = {}; SYNC_COLLECTIONS.forEach(c => { remoteSeen[c] = new Set(); remoteFp[c] = {}; });
  const { F, db } = fbInit();
  const uid = user.uid;
  syncStatus('syncing');

  SYNC_COLLECTIONS.forEach(c => {
    const q = F.collection(db, `users/${uid}/${c}`);
    unsubscribes.push(F.onSnapshot(q, snap => {
      let changed = false;
      snap.docChanges().forEach(ch => {
        const remote = ch.doc.data();
        if (!remote || !remote.id) return;
        remoteSeen[c].add(remote.id);
        if (applyRemote(c, remote)) changed = true;
        markInAccount(c, remote);
      });
      if (changed){ saveLocalOnly(); render(); }
      saveBaseline();
      pulledOnce.add(c);
      if (!syncState.firstPullDone && pulledOnce.size >= SYNC_COLLECTIONS.length){
        syncState.firstPullDone = true;
        if (!syncState.baselineReady) firstSyncOnThisDevice();
        render();                 /* anything waiting on a full pull can go now */
      }
      syncStatus('ok', { error: null });
    }, err => {
      syncStatus(navigator.onLine ? 'error' : 'offline',
        { error: navigator.onLine ? 'Could not read your account. ' + (err.message || '') : null });
    }));
  });

  unsubscribes.push(F.onSnapshot(F.doc(db, `users/${uid}/stages/list`), d => {
    const v = d.data();
    if (v && Array.isArray(v.items) && v.items.length &&
        JSON.stringify(v.items) !== JSON.stringify(data.stages)){
      data.stages = v.items; saveLocalOnly();
      if (lastPushed){ lastPushed._stages = snapshotOf(data)._stages; saveBaseline(); }
      render();
    }
  }, () => {}));

  unsubscribes.push(F.onSnapshot(F.doc(db, `users/${uid}/settings/app`), d => {
    const v = d.data();
    if (v){
      const { updated, ...rest } = v;
      if (JSON.stringify(rest) !== JSON.stringify(data.settings)){
        data.settings = rest; saveLocalOnly();
        if (lastPushed){ lastPushed._settings = snapshotOf(data)._settings; saveBaseline(); }
        applyTheme(); render();
      }
    }
  }, () => {}));

  /* Start from what this device last knew the account had, and send only
     what changed here since. A device syncing this account for the first
     time waits for the full download instead (firstSyncOnThisDevice). */
  lastPushed = loadBaseline(uid);
  syncState.baselineReady = !!lastPushed;
  if (syncState.baselineReady) pushUp().catch(() => {});
}

/* Note what the account now holds for one entity. If this device's copy
   differs (it was edited here more recently), the next send goes out. */
function markInAccount(coll, remote){
  if (!remoteFp[coll]) remoteFp[coll] = {};
  if (remote.deleted) delete remoteFp[coll][remote.id];
  else remoteFp[coll][remote.id] = fingerprint(remote);
  if (!lastPushed) return;
  if (!lastPushed[coll]) lastPushed[coll] = {};
  if (remote.deleted) delete lastPushed[coll][remote.id];
  else lastPushed[coll][remote.id] = remoteFp[coll][remote.id];
}

/* First time this account syncs on this device: everything the account
   holds has now arrived. Treat all of it as already there, and send only
   what exists on this device alone — things made here before signing in. */
function firstSyncOnThisDevice(){
  const base = snapshotOf(data);
  /* Start from exactly what the account sent. Anything on this device that
     differs (edited here in the first seconds) or is missing from it goes out. */
  SYNC_COLLECTIONS.forEach(c => { base[c] = Object.assign({}, remoteFp[c] || {}); });
  lastPushed = base;
  syncState.baselineReady = true;
  saveBaseline();
  pushUp().catch(() => {});
}

/* Returns true if local data actually changed. */
function applyRemote(coll, remote){
  if (!Array.isArray(data[coll])) data[coll] = [];
  const list = data[coll];
  const i = list.findIndex(x => x && x.id === remote.id);

  if (remote.deleted){
    if (i === -1) return false;
    const localUpdated = list[i].updated || 0;
    if ((remote.updated || 0) < localUpdated) return false;  /* local edit is newer */
    list.splice(i, 1);
    return true;
  }

  if (i === -1){ list.push(remote); return true; }
  /* Last write wins, by the millisecond stamp the editing device set. */
  if ((remote.updated || 0) <= (list[i].updated || 0)) return false;
  list[i] = remote;
  return true;
}

function stopSync(){
  unsubscribes.forEach(u => { try { u(); } catch (e) {} });
  unsubscribes = [];
  syncState.on = false;
  syncState.user = null;
  lastPushed = null;
  clearTimeout(pushTimer);
  syncStatus('off');
}

/* --- photographs ----------------------------------------------------------
   These are the part that cannot be recreated, and the part that costs
   money, so they are handled separately and lazily. Uploads go one at a
   time; downloads happen only when a photo is actually needed on screen. */

async function pushPhotos(){
  if (!syncState.on || !syncState.user) return;
  const { F, storage } = fb;
  const uid = syncState.user.uid;
  const wanted = arr(data.swatches).map(s => s.photoId)
    .concat(arr(data.minis).flatMap(m => arr(m.photos)))
    .filter(Boolean);

  for (const pid of wanted){
    if (photoQueue.has(pid)) continue;
    if (localStorage.getItem('mm.up.' + pid) === '1') continue;
    photoQueue.add(pid);
    try {
      const rec = await deadline(getPhoto(pid), 20000, 'Reading the photo');
      const blob = rec && rec.blob;
      if (!blob){ photoQueue.delete(pid); continue; }
      const r = F.storageRef(storage, `users/${uid}/photos/${pid}`);
      await deadline(F.uploadBytes(r, blob, { contentType: blob.type || 'image/jpeg' }),
                     120000, 'Uploading the photo');
      try { localStorage.setItem('mm.up.' + pid, '1'); } catch (e) {}
    } catch (e) {
      /* Leave it unmarked; the next sync will try again. */
    }
    photoQueue.delete(pid);
  }
}

/* A photo deleted on this device is deleted from the account too. Queued,
   so a delete made offline still happens the next time there is signal.
   Before v015 only the phone's copy went, and the account kept it. */
const PENDING_DEL = 'mm.photoDeletes';
function queueCloudDelete(pid){
  if (!pid) return;
  try {
    const q = JSON.parse(localStorage.getItem(PENDING_DEL) || '[]');
    if (q.indexOf(pid) === -1) q.push(pid);
    localStorage.setItem(PENDING_DEL, JSON.stringify(q));
    localStorage.removeItem('mm.up.' + pid);
  } catch (e) {}
  flushCloudDeletes().catch(() => {});
}
async function flushCloudDeletes(){
  if (!syncState.on || !syncState.user || !navigator.onLine) return;
  const { F, storage } = fb;
  let q = [];
  try { q = JSON.parse(localStorage.getItem(PENDING_DEL) || '[]'); } catch (e) { return; }
  const left = [];
  for (const pid of q){
    try { await F.deleteObject(F.storageRef(storage, `users/${syncState.user.uid}/photos/${pid}`)); }
    catch (e){ if (!/object-not-found/.test(e.code || e.message || '')) left.push(pid); }
  }
  try { localStorage.setItem(PENDING_DEL, JSON.stringify(left)); } catch (e) {}
}

/* Called when a photo is wanted on screen but is not on this device. */
async function pullPhoto(pid){
  if (!syncState.on || !syncState.user) return null;
  const { F, storage } = fb;
  const uid = syncState.user.uid;
  const r = F.storageRef(storage, `users/${uid}/photos/${pid}`);
  const blob = await deadline(F.getBlob(r), 60000, 'Fetching the photo');
  await putPhoto(pid, blob);
  try { localStorage.setItem('mm.up.' + pid, '1'); } catch (e) {}
  return blob;
}

/* --- deleting an account --------------------------------------------------
   Required, not optional. Sign-in is mandatory in this app, so a person
   must be able to get everything back out and then be gone completely.
   This deletes the cloud copy, the photographs, the local copy and the
   account itself, in that order, and reports honestly if a step fails. */

async function deleteEverything(progress){
  const { F, db, storage, auth } = fbInit();
  const user = auth.currentUser;
  if (!user) throw new Error('You are not signed in.');
  const uid = user.uid;
  stopSync();

  progress('Deleting your photographs…');
  try {
    const listing = await F.listAll(F.storageRef(storage, `users/${uid}/photos`));
    for (const item of listing.items){
      try { await F.deleteObject(item); } catch (e) {}
    }
  } catch (e) { /* nothing stored yet */ }

  progress('Deleting your collection…');
  const colls = SYNC_COLLECTIONS.concat(['stages','settings']);
  for (const c of colls){
    try {
      const snap = await F.getDocs(F.collection(db, `users/${uid}/${c}`));
      const docs = snap.docs;
      for (let i = 0; i < docs.length; i += 400){
        const batch = F.writeBatch(db);
        docs.slice(i, i + 400).forEach(d => batch.delete(d.ref));
        await batch.commit();
      }
    } catch (e) {}
  }

  progress('Clearing this device…');
  try { localStorage.clear(); } catch (e) {}
  try { await clearPhotos(); } catch (e) {}

  progress('Closing your account…');
  try {
    await F.deleteUser(user);
  } catch (e) {
    /* Google requires a recent sign-in before it will delete an account. */
    if ((e.code || '').includes('requires-recent-login')){
      const provider = new F.GoogleAuthProvider();
      await F.reauthenticateWithPopup(user, provider);
      await F.deleteUser(user);
    } else {
      throw e;
    }
  }
}

/* --- exporting before leaving --------------------------------------------- */
function syncPill(){
  const s = syncState.status;
  const label = s === 'ok' ? 'Synced'
    : s === 'syncing' ? 'Syncing…'
    : s === 'offline' ? 'Offline'
    : s === 'error' ? 'Sync problem'
    : '';
  const el = document.createElement('span');
  el.id = 'syncpill';
  el.className = 'syncpill s-' + s;
  el.setAttribute('role', 'status');
  el.textContent = label;
  /* Says nothing while everything is fine. It appears only when something
     needs your attention: offline, or a problem saving. */
  el.hidden = !label || s === 'ok' || s === 'syncing';
  return el;
}
