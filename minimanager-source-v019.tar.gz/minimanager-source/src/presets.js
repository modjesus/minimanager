/* ---------------------------------------------------------------------------
   What the app knows about the hobby before you type anything.

   Rules this file follows, because getting them wrong is worse than being thin:

   - Every army list was checked against at least two independent sources.
     Where the sources disagreed, the publisher's own spelling won.
   - Nothing here is padded from memory. A system with no verified list gets
     no list at all, and the person types their own.
   - Every list ends with "Type my own", always. A kitbash army, an
     out-of-print one, or a game nobody has heard of must never be locked out.
   - A colour value is only ever written here when a real one was published.
     Where no manufacturer value exists, hex is null and the app shows the
     swatch as unknown rather than inventing one. Guessing a colour and
     showing it as fact is the one thing this app must never do.
--------------------------------------------------------------------------- */

/* --- game systems and their armies ---------------------------------------- */
const SYSTEMS = [
  { name:'Warhammer 40,000', groups:[
    { label:'Imperium', items:['Space Marines','Deathwatch','Grey Knights','Adepta Sororitas',
      'Astra Militarum','Adeptus Custodes','Adeptus Mechanicus','Imperial Knights','Imperial Agents'] },
    { label:'Chaos', items:['Chaos Space Marines','Death Guard','Thousand Sons','World Eaters',
      "Emperor's Children",'Chaos Daemons','Chaos Knights'] },
    { label:'Xenos', items:['Necrons','Orks','Aeldari','Drukhari','Harlequins','Tyranids',
      "T'au Empire",'Genestealer Cults','Leagues of Votann'] }
  ]},

  { name:'Warhammer: Age of Sigmar', groups:[
    { label:'Order', items:['Stormcast Eternals','Cities of Sigmar','Daughters of Khaine',
      'Fyreslayers','Idoneth Deepkin','Kharadron Overlords','Lumineth Realm-Lords',
      'Seraphon','Sylvaneth'] },
    { label:'Chaos', items:['Slaves to Darkness','Blades of Khorne','Disciples of Tzeentch',
      'Hedonites of Slaanesh','Maggotkin of Nurgle','Skaven'] },
    { label:'Death', items:['Soulblight Gravelords','Nighthaunt','Flesh-Eater Courts',
      'Ossiarch Bonereapers'] },
    { label:'Destruction', items:['Orruk Warclans','Ironjawz','Kruleboyz','Gloomspite Gitz',
      'Ogor Mawtribes','Sons of Behemat'] },
    { label:'No longer in print', items:['Beasts of Chaos','Bonesplitterz'] }
  ]},

  { name:'Kill Team', groups:[
    { label:'', items:['Kommandos','Death Korps','Novitiates','Pathfinders','Legionaries',
      'Corsair Voidscarred','Blooded','Phobos Strike Team','Void-dancer Troupe','Warpcoven',
      'Wyrmblade','Hunter Clade','Gellerpox Infected','Elucidian Starstriders','Angels of Death',
      'Imperial Navy Breachers','Farstalker Kinband','Kasrkin','Hierotek Circle','Exaction Squad',
      'Hand of the Archon','Fellgor Ravagers','Hearthkyn Salvagers','Chaos Cult',
      'Inquisitorial Agents','Blades of Khaine','Scout Squad','Nemesis Claw','Mandrakes',
      'Brood Brothers','Hernkyn Yaegirs','Tempestus Aquilons','Vespid Stingwings'] }
  ]},

  { name:'Warhammer: The Horus Heresy', groups:[
    { label:'Loyalist Legions', items:['Dark Angels','White Scars','Space Wolves','Imperial Fists',
      'Blood Angels','Iron Hands','Ultramarines','Salamanders','Raven Guard'] },
    { label:'Traitor Legions', items:["Emperor's Children",'Iron Warriors','Night Lords',
      'World Eaters','Death Guard','Thousand Sons','Sons of Horus','Word Bearers','Alpha Legion'] },
    { label:'Other armies', items:['Solar Auxilia','Mechanicum Taghmata','Knights and Titans',
      'Legio Custodes','Sisters of Silence','Blackshields'] }
  ]},

  { name:'Warhammer: The Old World', groups:[
    { label:'Forces of Fantasy', items:['Dwarfen Mountain Holds','Empire of Man',
      'Kingdom of Bretonnia','Wood Elf Realms','High Elf Realms'] },
    { label:'Ravening Hordes', items:['Orc and Goblin Tribes','Warriors of Chaos',
      'Beastmen Brayherds','Tomb Kings of Khemri'] },
    { label:'Arcane Journal', items:['Grand Cathay'] },
    { label:'Legacy armies', items:['Chaos Dwarfs','Dark Elves','Daemons of Chaos','Lizardmen',
      'Ogre Kingdoms','Skaven','Vampire Counts'] }
  ]},

  { name:'Necromunda', groups:[
    { label:'House gangs', items:['House Cawdor','House Delaque','House Escher','House Goliath',
      'House Orlock','House Van Saar'] },
    { label:'Other gangs', items:['Palanite Enforcers','Venator Gangs','Corpse Grinder Cults',
      'Justicar Courts','Outcast Gangs','Free Ogryn Gangs','Genestealer Cults',
      'Chaos Helot Cults','Malstrain','Spyre Hunting Parties','Ironhead Squat Prospectors',
      'Ash Waste Nomad Gangs'] }
  ]},

  { name:'Warcry', groups:[
    { label:'', items:['Iron Golems','Untamed Beasts','The Splintered Fang','The Unmade',
      'Cypher Lords','Corvus Cabal','Spire Tyrants','Scions of the Flame',
      'Khainite Shadowstalkers','Tarantulos Brood','Darkoath Savagers','Rotmire Creed',
      'Horns of Hashut','Chaos Legionnaires','Askurgan Trueblades','Hunters of Huanchi',
      'Claws of Karanak','Questor Soulsworn','Royal Beastflayers','Crimson Court',
      "Xandire's Truthseekers",'Wildercorps Hunters','Gorger Mawpack','Vulkyn Flameseekers',
      'Kruleboyz Monsta-killaz','Pyregheists','Ydrilan Riverblades','Twistweald',
      'Teratic Cohort'] }
  ]},

  { name:'Blood Bowl', groups:[
    { label:'', items:['Amazon','Black Orc','Bretonnian','Chaos Chosen','Chaos Dwarf',
      'Chaos Renegade','Dark Elf','Dwarf','Elven Union','Gnome','Goblin','Halfling','Human',
      'Imperial Nobility','Khorne','Lizardmen','Necromantic Horror','Norse','Nurgle','Ogre',
      'Old World Alliance','Orc','Shambling Undead','Skaven','Snotling','Tomb Kings',
      'Underworld Denizens','Vampire','Wood Elf'] }
  ]},

  /* Middle-earth has 96 published army lists, which is unusable in a dropdown.
     These are the most commonly collected, taken from that verified set. */
  { name:'Middle-earth Strategy Battle Game', groups:[
    { label:'Good', items:['The Fellowship','The Shire','Rivendell','Lothlórien',
      'Kingdom of Rohan','Minas Tirith','Men of the West','Númenor','Arnor','The Grey Company',
      'Erebor & Dale','Iron Hills',"Thorin's Company",'The White Council','Fangorn','The Eagles',
      'Kingdom of Khazad-dûm'] },
    { label:'Evil', items:['Barad-dûr','Legions of Mordor','Minas Morgul','Cirith Ungol',
      'The Black Riders','Army of the White Hand','Muster of Isengard','Moria','Goblin-Town',
      'Harad','Umbar','Corsair Fleets','The Easterlings','Army of Gundabad',"Azog's Hunters",
      'Shadows of Angmar','Army of Carn Dûm'] }
  ]},

  { name:'Bolt Action', groups:[
    { label:'Main armies', items:['Great Britain','Germany','United States','Soviet Union',
      'Imperial Japan','Italy','British Commonwealth','France'] },
    { label:'Further nations', items:['Belgium','Bulgaria','Finland','Greece','Hungary',
      'Netherlands','Norway','Partisans','Poland','Romania'] }
  ]},

  { name:'Star Wars: Legion', groups:[
    { label:'', items:['Rebel Alliance','Galactic Empire','Galactic Republic',
      'Separatist Alliance','Shadow Collective'] }
  ]},

  { name:'Marvel: Crisis Protocol', groups:[
    { label:'', items:['A-Force','Asgard','Avengers','Black Order','Brotherhood of Mutants',
      'Cabal','Convocation','Criminal Syndicate','Dark Dimension','Defenders',
      'Guardians of the Galaxy','Hellfire Club','Hydra','Inhumans','Midnight Sons','New Mutants',
      'Sentinels','S.H.I.E.L.D.','Spider-Foes','Uncanny X-Men','Wakanda','Weapon X',
      'Web Warriors','X-Force','Winter Guard','Servants of the Apocalypse'] }
  ]},

  { name:'Infinity', groups:[
    { label:'', items:['PanOceania','Yu Jing','Ariadna','Haqqislam','Nomads','Combined Army',
      'ALEPH','Tohaa','O-12','JSA','NA2'] }
  ]},

  { name:'Malifaux', groups:[
    { label:'', items:['Guild','Arcanists','Resurrectionists','Neverborn','Outcasts','Bayou',
      'Ten Thunders',"Explorer's Society"] }
  ]},

  /* No verified army structure, so no list. The person types their own. */
  /* Indie and small-press games.
     These ship with EMPTY army lists on purpose. The game's name is a
     trademark used only so you can label your own models — that is covered
     by the notice in the menu — but a faction list is the publisher's own
     material, and for most of these there is no licence that would allow
     reproducing one. Several of them do not work that way anyway: a
     Turnip28 warband is built out of unit types, not picked from factions.
     "Type my own" covers every one of them. */
  { name:'Turnip28', groups:[] },
  { name:'Trench Crusade', groups:[] },
  { name:'Grimdark Future', groups:[] },
  { name:'Age of Fantasy', groups:[] },
  { name:'The 9th Age', groups:[] },
  { name:'Kings of War', groups:[] },
  { name:'Gaslands', groups:[] },
  { name:'Five Parsecs from Home', groups:[] },
  { name:'Rangers of Shadow Deep', groups:[] },
  { name:'Battletech', groups:[] },
  { name:'SAGA', groups:[] },
  { name:'Flames of War', groups:[] },
  { name:'Frostgrave', groups:[] },
  { name:'Dungeons & Dragons', groups:[] },
  { name:'Pathfinder', groups:[] },
  { name:'Display and busts', groups:[] },
  { name:'Historical', groups:[] },
  { name:'Terrain and scenery', groups:[] }
];

/* --- undercoats ------------------------------------------------------------
   Names and colour values for the first four brands come out of the paint
   catalogue already inside this app. The Colour Forge publishes no colour
   values anywhere I could find, so those carry hex:null and the app draws
   them as "colour unknown". Photograph one and the app will know. */
const UNDERCOAT_PRESETS = [
  /* kept from the first version so existing swatches still point somewhere */
  { id:'u-black',    name:'Black',    brand:'Any',      hex:'#111111', cat:'black' },
  { id:'u-white',    name:'White',    brand:'Any',      hex:'#FFFFFF', cat:'white' },
  { id:'u-grey',     name:'Grey',     brand:'Any',      hex:'#9A9A9A', cat:'grey'  },
  { id:'u-zenithal', name:'Zenithal', brand:'Any',      hex:null,      cat:'zenithal' },

  { id:'u-cit-chaosblack',  name:'Chaos Black',              brand:'Citadel', hex:'#000000' },
  { id:'u-cit-coraxwhite',  name:'Corax White',              brand:'Citadel', hex:'#FFFFFF' },
  { id:'u-cit-greyseer',    name:'Grey Seer',                brand:'Citadel', hex:'#A2A5A7' },
  { id:'u-cit-wraithbone',  name:'Wraithbone',               brand:'Citadel', hex:'#DBD1B2' },
  { id:'u-cit-mechgrey',    name:'Mechanicus Standard Grey', brand:'Citadel', hex:'#39484A' },
  { id:'u-cit-zandri',      name:'Zandri Dust',              brand:'Citadel', hex:'#988E56' },
  { id:'u-cit-macragge',    name:'Macragge Blue',            brand:'Citadel', hex:'#103E7C' },
  { id:'u-cit-mephiston',   name:'Mephiston Red',            brand:'Citadel', hex:'#960D0A' },
  { id:'u-cit-leadbelcher', name:'Leadbelcher',              brand:'Citadel', hex:'#868686' },
  { id:'u-cit-retributor',  name:'Retributor Armour',        brand:'Citadel', hex:'#EDC06A' },
  { id:'u-cit-deathguard',  name:'Death Guard Green',        brand:'Citadel', hex:'#556229' },

  { id:'u-tap-black',   name:'Matt Black',       brand:'The Army Painter', hex:'#000000' },
  { id:'u-tap-white',   name:'Matt White',       brand:'The Army Painter', hex:'#FFFFFF' },
  { id:'u-tap-grey',    name:'Uniform Grey',     brand:'The Army Painter', hex:'#545D62' },
  { id:'u-tap-bone',    name:'Skeleton Bone',    brand:'The Army Painter', hex:'#D0C59A' },
  { id:'u-tap-leather', name:'Leather Brown',    brand:'The Army Painter', hex:'#713E29' },
  { id:'u-tap-plate',   name:'Plate Mail Metal', brand:'The Army Painter', hex:'#858584' },
  { id:'u-tap-ultra',   name:'Ultramarine Blue', brand:'The Army Painter', hex:'#154275' },
  { id:'u-tap-army',    name:'Army Green',       brand:'The Army Painter', hex:'#66693A' },
  { id:'u-tap-red',     name:'Pure Red',         brand:'The Army Painter', hex:'#C3231E' },
  { id:'u-tap-flesh',   name:'Barbarian Flesh',  brand:'The Army Painter', hex:'#E59B66' },

  { id:'u-val-black', name:'Black',             brand:'Vallejo', hex:'#060606' },
  { id:'u-val-white', name:'White',             brand:'Vallejo', hex:'#FFFFFF' },
  { id:'u-val-grey',  name:'Grey',              brand:'Vallejo', hex:'#C0C0C2' },
  { id:'u-val-panzer',name:'German Panzer Grey',brand:'Vallejo', hex:'#404042' },
  { id:'u-val-bone',  name:'Skeleton Bone',     brand:'Vallejo', hex:'#BAA789' },
  { id:'u-val-tan',   name:'Desert Tan',        brand:'Vallejo', hex:'#D1BE9E' },

  { id:'u-s75-black', name:'Primer Surface Black', brand:'Scale75', hex:'#101318' },
  { id:'u-s75-grey',  name:'Primer Surface Gray',  brand:'Scale75', hex:'#646464' },
  { id:'u-s75-white', name:'Primer Surface White', brand:'Scale75', hex:'#C9CFD5' },

  /* The Colour Forge. Real names, no published colour values. */
  { id:'u-cf-mattblack',   name:'Matt Black',         brand:'The Colour Forge', hex:null },
  { id:'u-cf-ravenblack',  name:'Raven Black',        brand:'The Colour Forge', hex:null },
  { id:'u-cf-mattwhite',   name:'Matt White',         brand:'The Colour Forge', hex:null },
  { id:'u-cf-stdgrey',     name:'Standard Grey',      brand:'The Colour Forge', hex:null },
  { id:'u-cf-wolfkin',     name:'Wolfkin Grey',       brand:'The Colour Forge', hex:null },
  { id:'u-cf-ghoul',       name:'Ghoul Grey',         brand:'The Colour Forge', hex:null },
  { id:'u-cf-ashen',       name:'Ashen Grey',         brand:'The Colour Forge', hex:null },
  { id:'u-cf-wightbone',   name:'Wight Bone',         brand:'The Colour Forge', hex:null },
  { id:'u-cf-ossified',    name:'Ossified Earth',     brand:'The Colour Forge', hex:null },
  { id:'u-cf-desertsand',  name:'Desert Sand',        brand:'The Colour Forge', hex:null },
  { id:'u-cf-trenchbrown', name:'Trench Brown',       brand:'The Colour Forge', hex:null },
  { id:'u-cf-hyrax',       name:'Hyrax Brown',        brand:'The Colour Forge', hex:null },
  { id:'u-cf-sanguine',    name:'Sanguine Red',       brand:'The Colour Forge', hex:null },
  { id:'u-cf-reliquary',   name:'Reliquary Red',      brand:'The Colour Forge', hex:null },
  { id:'u-cf-convict',     name:'Convict Orange',     brand:'The Colour Forge', hex:null },
  { id:'u-cf-sunset',      name:'Sunset Yellow',      brand:'The Colour Forge', hex:null },
  { id:'u-cf-valrak',      name:'Valrak Yellow',      brand:'The Colour Forge', hex:null },
  { id:'u-cf-salamander',  name:'Salamander Green',   brand:'The Colour Forge', hex:null },
  { id:'u-cf-deathrattle', name:'Death Rattle Green', brand:'The Colour Forge', hex:null },
  { id:'u-cf-renegade',    name:'Renegade Green',     brand:'The Colour Forge', hex:null },
  { id:'u-cf-governor',    name:'Governor Green',     brand:'The Colour Forge', hex:null },
  { id:'u-cf-republic',    name:'Republic Blue',      brand:'The Colour Forge', hex:null },
  { id:'u-cf-tempest',     name:'Tempest Blue',       brand:'The Colour Forge', hex:null },
  { id:'u-cf-midwinter',   name:'Midwinter Ice',      brand:'The Colour Forge', hex:null },
  { id:'u-cf-imperial',    name:'Imperial Purple',    brand:'The Colour Forge', hex:null },
  { id:'u-cf-rogue',       name:'Rogue Pink',         brand:'The Colour Forge', hex:null },
  { id:'u-cf-peachy',      name:'Peachy Peach',       brand:'The Colour Forge', hex:null },
  { id:'u-cf-deadanimal',  name:'Dead Animal Bits',   brand:'The Colour Forge', hex:null },
  { id:'u-cf-siege',       name:'Siege Armour',       brand:'The Colour Forge', hex:null },
  { id:'u-cf-steelforge',  name:'Steelforge Silver',  brand:'The Colour Forge', hex:null },
  { id:'u-cf-gauntlet',    name:'Gauntlet Gold',      brand:'The Colour Forge', hex:null }
];

/* --- techniques, in the order you would actually do them ------------------- */
const TECHNIQUES = [
  ['Undercoat',      'The first thin coat of all, sprayed or brushed on. It gives the paint something to grip, and its colour changes everything that follows.'],
  ['Basecoat',       'The first solid colour on an area. Two thin coats beat one thick one every time.'],
  ['Wash',           'Very thin, dark paint flooded over an area. It runs into the recesses and does the shading for you.'],
  ['Shade',          'The same idea as a wash, applied more carefully into particular recesses rather than over everything.'],
  ['Drybrush',       'Wipe nearly all the paint off the brush on a tissue, then flick it across raised detail. It catches the edges only.'],
  ['Layer',          'A slightly lighter colour painted inside the edges of the one below, building up towards the light.'],
  ['Edge highlight', 'A fine line of a lighter colour along a sharp edge, as if light were catching it.'],
  ['Glaze',          'Paint thinned almost to water, laid over a finished area to tint it without hiding what is underneath.'],
  ['Stipple',        'Dabbing with the tip of the brush to make a rough, speckled texture. Rust, stubble, worn paint.'],
  ['Blend',          'Working two colours into each other while both are still wet, so there is no visible join.'],
  ['Sponge chipping','Dabbing paint on with a torn piece of sponge to make scratches and chipped armour.'],
  ['Contrast',       'A single thick coat of a contrast or speedpaint that pools in the recesses and thins on the raised areas. Does base, shade and highlight at once.'],
  ['Metallic',       'Paint with real metal flake in it. Shake it properly and it will behave.'],
  ['Transfer',       'Waterslide decals. Gloss varnish first, decal on, matt varnish over.'],
  ['Basing',         'Everything on the base itself. Texture, sand, grass, snow, rocks.'],
  ['Varnish',        'The protective coat at the very end. Matt for most models, gloss under transfers, satin for leather and skin.']
];

/* --- base sizes ------------------------------------------------------------
   From a published Citadel reference chart, cross-checked. */
/* Unit types.
   Deliberately plain category words rather than any publisher's own
   classifications. These eleven are the shared vocabulary of the hobby and
   work for Warhammer, Turnip28, Trench Crusade, Bolt Action, Frostgrave and a
   game nobody has written yet. Nothing here is copied from anyone's book, and
   points costs and unit profiles are not in this app for exactly that reason:
   those are the publisher's copyright and there is no licence that covers
   reproducing them. "Type my own" carries whatever a given game calls things. */
const UNIT_TYPES = [
  'Infantry', 'Cavalry', 'Character', 'Monster', 'Vehicle', 'Artillery',
  'Flyer', 'Swarm', 'Beast', 'Warmachine', 'Terrain'
];

const BASE_SIZES = [
  ['25mm',        'Small infantry'],
  ['28.5mm',      'Older infantry squads'],
  ['32mm',        'Standard infantry'],
  ['40mm',        'Characters and heavy infantry'],
  ['50mm',        'Large infantry'],
  ['60mm',        'Monsters and small vehicles'],
  ['80mm',        'Bigger monsters'],
  ['90mm',        'Large walkers'],
  ['100mm',       'Large monsters and vehicles'],
  ['130mm',       'Very large monsters'],
  ['160mm',       'Very large vehicles'],
  ['60×35.5mm',   'Cavalry and beasts (oval)'],
  ['75×42mm',     'Bikes and beasts (oval)'],
  ['90×52.5mm',   'Bikes and walkers (oval)'],
  ['105×70mm',    'Medium walkers (oval)'],
  ['120×92mm',    'Flyers and big walkers (oval)'],
  ['170×109mm',   'Knights and the largest walkers (oval)'],
  ['25×50mm',     'Rank-and-file cavalry (rectangular)'],
  ['20×20mm',     'Rank-and-file infantry (rectangular)']
];

/* --- currencies ------------------------------------------------------------
   Only the code is stored. Intl.NumberFormat then supplies the symbol and,
   more importantly, puts it in the right place and uses the right separators
   — 1 234,56 kr and £1,234.56 are both correct and hardcoding "£" in front
   of a number would be wrong for most of this list. */
const CURRENCIES = [
  ['GBP','Pound sterling'],      ['EUR','Euro'],
  ['USD','US dollar'],           ['CAD','Canadian dollar'],
  ['AUD','Australian dollar'],   ['NZD','New Zealand dollar'],
  ['SEK','Swedish krona'],       ['NOK','Norwegian krone'],
  ['DKK','Danish krone'],        ['ISK','Icelandic króna'],
  ['CHF','Swiss franc'],         ['PLN','Polish złoty'],
  ['CZK','Czech koruna'],        ['HUF','Hungarian forint'],
  ['RON','Romanian leu'],        ['BGN','Bulgarian lev'],
  ['JPY','Japanese yen'],        ['CNY','Chinese yuan'],
  ['HKD','Hong Kong dollar'],    ['SGD','Singapore dollar'],
  ['KRW','South Korean won'],    ['INR','Indian rupee'],
  ['ZAR','South African rand'],  ['BRL','Brazilian real'],
  ['MXN','Mexican peso'],        ['ARS','Argentine peso'],
  ['TRY','Turkish lira'],        ['ILS','Israeli new shekel'],
  ['AED','UAE dirham'],          ['PHP','Philippine peso'],
  ['MYR','Malaysian ringgit'],   ['THB','Thai baht']
];

/* --- the small tappable lists --------------------------------------------- */
const CHIPS = {
  category: ['Skin','Bone','Metal','Cloth','Leather','Wood','Stone','Fur','Gems','Glass',
             'Weapons','Armour','Bases','Hair','Scales'],
  dry:      ['10 min','20 min','1 hour','Overnight'],
  mix:      ['Neat','1:1 water','2:1 water','1:1 medium','2:1 medium','A touch of flow aid'],
  light:    ['Daylight lamp','By a window','Warm bulb','Overhead light'],
  area:     ['Armour','Armour trim','Weapon','Blade','Skin','Face','Cloak','Cloth','Leather',
             'Hair','Base','Eyes','Gems'],
  tag:      ['Tournament','Kitbash','Commission','Gift','Converted','Magnetised','Test model',
             'Warlord','Second hand','3D printed']
};

/* --- the "?" helpers -------------------------------------------------------
   Each is written for someone who has never done any of this. */
const HELP = {
  paintType: { title:'What the paint types mean', dl:[
    ['Base',      'Thick and opaque. The first solid colour, straight over the undercoat.'],
    ['Layer',     'Thinner. Built up on top of a base to lighten or shade an area.'],
    ['Wash / Shade','Very thin and dark. Runs into the recesses and does your shading for you.'],
    ['Contrast',  'Base, shade and highlight in one coat. Works best over a pale undercoat.'],
    ['Ink',       'Very strong transparent colour. Brilliant for glazing, overpowering if used neat.'],
    ['Dry',       'Stiff, almost dry out of the pot. Made for drybrushing raised edges.'],
    ['Metallic',  'Has real metal flake in it. Needs a proper shake and a clean brush.'],
    ['Technical', 'Not really a colour. Textures, bloods, rusts, crackle effects.'],
    ['Primer',    'The undercoat itself, in a can or a bottle.']
  ]},

  undercoat: { title:'Why the undercoat matters', p:[
    'The same paint looks like a different colour depending on what is underneath it. This is the single biggest thing that changes how a model turns out, and it is the thing most guides skip.',
    'Dark undercoats deepen every colour and hide mistakes. Pale undercoats make colours bright and are what contrast and speedpaints are designed for. Grey sits between the two.',
    'Zenithal means black first, then white sprayed from directly above only. It paints the light and shadow onto the model before you have put any colour on at all.',
    'This app exists partly to answer this question properly. Photograph the same paint over two different undercoats and you will never have to guess again.'
  ]},

  stages: { title:'What the stages mean', dl:[
    ['Unbuilt',    'Still on the sprue, or still in the box.'],
    ['Built',      'Glued together, not yet painted. Mould lines are worth doing now.'],
    ['Primed',     'Undercoated and ready for colour.'],
    ['Basecoat',   'The solid colours are all down, nothing shaded yet. It will look flat. That is normal.'],
    ['Shading',    'Washes and shades in the recesses. This is where it starts to look like something.'],
    ['Highlights', 'Layers and edge highlights, working towards the light.'],
    ['Basing',     'The base itself. Texture, grass, snow, rim painted.'],
    ['Finished',   'Varnished and done. On the shelf.']
  ]},

  thinning: { title:'How much to thin paint', p:[
    'Most paint straight from the pot is too thick, and thick paint fills in the detail you paid for.',
    'Aim for the consistency of milk, not cream. On a wet palette or a tile, mix in water a drop at a time until the paint flows off the brush rather than dragging.',
    'Two or three thin coats always beat one thick one. It feels slower and it is faster, because you are not fixing anything.',
    'Use a medium rather than water when the paint starts going chalky or refusing to stick.'
  ]},

  varnish: { title:'Which varnish and when', dl:[
    ['Matt',   'The usual finish for miniatures. Kills shine and makes the paint look like cloth, skin and stone.'],
    ['Satin',  'A slight sheen. Good for leather, and for skin if you want it to look alive.'],
    ['Gloss',  'Shiny. Mostly used as a hard protective layer underneath transfers, or on anything wet-looking.'],
    ['Order',  'Gloss first for protection and transfers, matt last for the look. Never varnish in cold or damp air, it goes cloudy.']
  ]},

  baseSize: { title:'Common base sizes', table:BASE_SIZES },

  unitType: { title:'What sort of thing is it?', p:[
    'A rough category, so you can sort and filter a collection that spans several games. Nothing depends on getting it exactly right, and you can leave it blank.',
    'These are plain words rather than any particular game’s own classifications, so they work whatever you collect. If your game calls it something else, use Type my own.',
    'Points costs and unit profiles are not here, and are not coming. Those are the publisher’s copyright and there is no licence that allows an app like this to reproduce them — so if you want to track points, type in the numbers from your own book and the app will add them up for you.'
  ]},

  technique: { title:'What the techniques mean', dl:TECHNIQUES },

  swatch: { title:'Photographing a swatch', p:[
    'This is the part that makes the app worth having. A photograph of the paint as it actually went on, over a named undercoat, is real evidence. A colour value typed into a catalogue is not.',
    'Use the same light every time and say which it was, so two swatches can be compared fairly. A daylight lamp or an overcast window are both fine. A warm bulb will make everything look yellow.',
    'Fill the frame with the painted area. Say how many coats it took, because two coats of a thin paint look nothing like four.'
  ]},

  colourPlan: { title:'Planning a colour scheme', dl:[
    ['Complementary', 'Opposite sides of the colour wheel. Maximum contrast, which is why red and green shout at each other. Use one as the main colour and the other only as a small accent.'],
    ['Analogous',     'Neighbours on the wheel. Calm and natural, good for whole armies that should look like they belong together.'],
    ['Triadic',       'Three evenly spaced colours. Lively and balanced, but hard to control on a small model.'],
    ['Split',         'One colour plus the two either side of its opposite. Most of the contrast, less of the shouting.'],
    ['The rule of thumb','One dominant colour, one supporting, one tiny accent. Roughly 60, 30 and 10 parts of the model.']
  ]},

  stock: { title:'What the stock settings do', p:[
    'Nothing automatic. They are there so you can look at your paints before you go to a shop, and so a recipe can tell you that you are out of something it needs.'
  ]}
};
