/* MiniManager — Firebase connection details.

   These are NOT secret. A Firebase web config is designed to be public and
   sits in the page source of every Firebase web app in the world. It
   identifies the project; it does not grant access to anything.

   What actually protects the data is firestore.rules and storage.rules,
   which are enforced on Google's servers and cannot be edited from a
   browser. Anyone can read these six lines and still reach nothing but
   their own data.

   Project: minimanager-3b297, created 12 Oct 2026.
   Firestore lives in europe-west2 (London). That choice is permanent. */
const FIREBASE_CONFIG = {
  apiKey:            'AIzaSyCb6NBdcgNFbg3J3959MWB0ub_FBOoKv44',
  authDomain:        'minimanager-3b297.firebaseapp.com',
  projectId:         'minimanager-3b297',
  storageBucket:     'minimanager-3b297.firebasestorage.app',
  messagingSenderId: '934649165202',
  appId:             '1:934649165202:web:420c7895d537bcc773fd4b'
};
