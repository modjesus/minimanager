/* v017: the collection quick fixes from the wargamer audit. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');
let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); } else { fail.push(n); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };
const SEED = `authGate='in'; syncState.user={uid:'t',email:'j@e.com'}; syncState.status='ok'; syncState.firstPullDone=true;
  data.settings.setupDone=true; setupChecked=true; data.systems=[]; data.factions=[]; data.paints=[];
  const w=systemIdByName('Warhammer 40,000'), dg=factionIdByName('Death Guard',w), ty=factionIdByName('Tyranids',w);
  const mk=(id,n,fac,unit,stage,total,done)=>({id,name:n,sys:w,fac,unit,stage,total,done,photos:[],tags:'',notes:'',updated:1});
  data.minis=[mk('c','Lord of Contagion',dg,'Character','Highlights',1,0), mk('s','Poxwalkers',dg,'Infantry','Basecoat',20,5),
    mk('v','Rhino',dg,'Vehicle','Primed',1,0), mk('t','Ruined manufactorum',dg,'Terrain','Unbuilt',1,0), mk('x','Lost marine',ty,'Infantry','Built',1,0)];
  state.tab='home'; render();`;
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForTimeout(1800); await p.evaluate(SEED); await p.waitForTimeout(400);

  const c = await p.evaluate(() => counts());
  ok('terrain is not counted as a model', c.total === 23, JSON.stringify(c));
  ok('finished counts models', c.done === 5);
  ok('on the bench counts models not yet finished', c.started === 15 + 1 + 1 + 1, String(c.started));
  ok('still to build counts models, terrain apart', c.backlog === 0, String(c.backlog));
  ok('terrain is counted on its own', c.terrain === 1);
  const led = await p.evaluate(() => [...document.querySelectorAll('.lcell span')].map(e => e.textContent).join('|'));
  ok('every ledger figure says it counts models', /models on the bench/.test(led) && /still to build/.test(led), led);
  ok('terrain gets its own line', /1<\/span> terrain project|1 terrain project/.test(await p.textContent('.terrline')));

  await p.evaluate(() => { const g = armyGroups().find(x => facName(x.fac)==='Death Guard'); state.tab='coll'; state.openGame=g.sys; state.openArmy=g.key; render(); });
  await p.waitForTimeout(300);
  ok('army head separates terrain', /22 models finished|5 of 22 models finished/.test(await p.textContent('.armyhead')) && /1 terrain project/.test(await p.textContent('.armyhead')), await p.textContent('.armyhead'));
  ok('shelves say units and models', /3 units · 22 models/.test((await p.$$eval('.shelf', e => e.map(x => x.textContent.replace(/\s+/g,' ')).join('|')))),
     await p.$$eval('.shelf', e => e.map(x => x.textContent.replace(/\s+/g,' ')).join('|')));

  /* typing every model finished moves the unit to Finished */
  await p.evaluate(() => { state.openMini='s'; render(); }); await p.waitForTimeout(300);
  await p.click('[data-act="moveOn"]'); await p.waitForTimeout(300);
  await p.click('#dlg [data-mvto="7"]'); await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(500);
  ok('20 of 20 finished means Finished', await p.evaluate(() => { const m = data.minis.find(x => x.id==='s'); return m.stage === 'Finished' && m.done === 20; }));

  /* moving a unit to another army */
  await p.evaluate(() => { state.openMini='c'; render(); }); await p.waitForTimeout(300);
  ok('game and army are on the model page', !!(await p.$('#eSys')) && !!(await p.$('#eFac')));
  await p.selectOption('#eFac', 'Tyranids'); await p.click('[data-act="saveMini"]'); await p.waitForTimeout(400);
  const moved = await p.evaluate(() => { const m = data.minis.find(x => x.id==='c'); return { fac: facName(m.fac), army: state.openArmy === armyKey(m) }; });
  ok('a unit can be moved to another army', moved.fac === 'Tyranids', JSON.stringify(moved));
  ok('the way back now leads to the new army', moved.army);
  ok('the way back is labelled with the new army', (await p.textContent('.backlink')).includes('Tyranids'));
  await p.selectOption('#eSys', '__own'); await p.waitForTimeout(150);
  ok('typing your own game is offered', await p.isVisible('#eSysOwn'));
  await p.fill('#eSysOwn', 'Necromunda'); await p.selectOption('#eSys', 'Necromunda').catch(()=>{});
  await p.evaluate(() => { const s = document.getElementById('eSys'); s.value='Necromunda'; s.dispatchEvent(new Event('change',{bubbles:true})); });
  await p.waitForTimeout(150);
  ok('a new game brings its own word (gang)', (await p.textContent('label[for="eFac"]')).trim() === 'Gang', await p.textContent('label[for="eFac"]'));
  ok('...and its own list', await p.evaluate(() => [...document.querySelectorAll('#eFac option')].some(o => /Escher/.test(o.value))));

  /* add box: how many is beside the name */
  await p.evaluate(() => { state.openMini=null; state.openArmy=null; state.openGame=null; state.tab='coll'; render(); }); await p.waitForTimeout(300);
  await p.click('#actslot [data-act="addHere"]'); await p.waitForTimeout(300);
  ok('How many is visible without opening More details', await p.isVisible('#mTotal'));
  await p.fill('#mName', 'Plague Marines'); await p.fill('#mTotal', '10'); await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(400);
  ok('...and is saved', await p.evaluate(() => data.minis.some(m => m.name==='Plague Marines' && m.total===10)));

  ok('photo wording no longer says photos stay on this phone', !(await p.evaluate(() => document.documentElement.innerHTML.includes('stays on this phone'))));
  /* v019: a paint with a photographed swatch no longer scrolls sideways */
  await p.evaluate(() => { data.undercoats = data.undercoats && data.undercoats.length ? data.undercoats : [{id:'uz',name:'Zenithal',brand:'Any'}];
    data.paints.push({id:'pz',name:'Death Guard Green',brand:'Citadel',range:'Base',hex:'#6D774D',stock:'Have it'});
    data.swatches.push({id:'sz',paintId:'pz',undercoatId:data.undercoats[0].id,photoId:'nophoto',coats:2,lighting:'Daylight',notes:'',created:1});
    state.tab='paints'; state.openPaint='pz'; state.sub=null; render(); });
  await p.waitForTimeout(400);
  const side = await p.evaluate(() => { const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('#app *').forEach(el => { const r = el.getBoundingClientRect(); if (r.width && r.right > vw + 1) bad.push((el.getAttribute('class')||el.tagName)+' '+Math.round(r.right)); });
    return bad.slice(0,3); });
  ok('a paint with a swatch fits the phone, no sideways scroll', side.length === 0, side.join(', '));
  ok('no page errors', errs.length === 0, errs.join(' | '));
  console.log(`\n  ${pass} passed, ${fail.length} failed`); await b.close(); process.exit(fail.length ? 1 : 0);
})();
