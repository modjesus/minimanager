/* v018: how many models are at each stage. The wargamer audit's squad:
   20 assembled, 15 primed, 10 basecoated, 5 finished. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');
let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); } else { fail.push(n); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };
const SEED = `authGate='in'; syncState.user={uid:'t',email:'j@e.com'}; syncState.status='ok'; syncState.firstPullDone=true;
  data.settings.setupDone=true; setupChecked=true; data.systems=[]; data.factions=[]; data.paints=[];
  const w=systemIdByName('Warhammer 40,000'), dg=factionIdByName('Death Guard',w);
  const mk=(id,n,unit,stage,total,done)=>({id,name:n,sys:w,fac:dg,unit,stage,total,done,photos:[],tags:'',notes:'',updated:1});
  data.minis=[mk('c','Lord of Contagion','Character','Highlights',1,0), mk('s','Poxwalkers','Infantry','Unbuilt',20,0),
    mk('v','Rhino','Vehicle','Primed',1,0), mk('t','Ruined manufactorum','Terrain','Unbuilt',1,0),
    mk('old','Plague Marines','Infantry','Basecoat',20,5)];
  state.tab='coll'; state.openMini='s'; state.openGame=w; state.openArmy=armyKey(data.minis[1]); render();`;
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForTimeout(1800); await p.evaluate(SEED); await p.waitForTimeout(400);

  /* converting what is already there */
  const old = await p.evaluate(() => { const m = data.minis.find(x => x.id==='old'); return { c: stageCounts(m), label: stageLabel(m) }; });
  ok('"Basecoat, 5 of 20 finished" reads as 15 at Basecoat and 5 finished', old.c.join() === '0,0,0,15,0,0,0,5', old.c.join());
  ok('...and is labelled with the span its models cover', old.label === 'Basecoat to Finished', old.label);

  /* the squad, through the move panel */
  const move = async (to, n, from) => {
    await p.click('#app [data-act="moveOn"]'); await p.waitForTimeout(250);
    if (from != null) await p.click(`#dlg [data-mvfrom="${from}"]`);
    await p.click(`#dlg [data-mvto="${to}"]`);
    if (n != null){ const max = await p.evaluate(() => +document.getElementById('mvN').textContent);
      for (let i = max; i > n; i--) await p.click('#dlg [data-mvstep="-1"]'); }
    await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(350);
  };
  ok('a unit of 20 offers "Move models on", not the single-model button',
     !!(await p.$('#app [data-act="moveOn"]')) && !(await p.$('#app [data-adv]')));
  await p.click('#app [data-act="moveOn"]'); await p.waitForTimeout(250);
  const first = await p.evaluate(() => ({ from: document.querySelector('#dlg [data-mvfrom][aria-pressed="true"]')?.textContent.trim(),
    to: document.querySelector('#dlg [data-mvto][aria-pressed="true"]')?.textContent.trim(), n: document.getElementById('mvN').textContent,
    ok: document.querySelector('#dlg [data-dlg="ok"]').textContent }));
  ok('it suggests all 20 from Unbuilt to the next stage', /Unbuilt/.test(first.from) && first.to === 'Built' && first.n === '20', JSON.stringify(first));
  ok('the button says exactly what will happen', first.ok === 'Move 20 to Built', first.ok);
  await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(350);
  await move(2, 15);   // 15 primed
  await move(3, 10, 2);   // 10 of the primed to basecoat
  await move(7, 5, 3);    // 5 of those to finished
  const sq = await p.evaluate(() => { const m = data.minis.find(x => x.id==='s');
    return { c: stageCounts(m).join(), rt: runningTotals(m).map(r => r.reached).join(), done: m.done, stage: m.stage, sig: m.atSig === atSig(m) }; });
  ok('the squad holds 5 built, 5 primed, 5 basecoated, 5 finished', sq.c === '0,5,5,5,0,0,0,5', sq.c);
  ok('running totals: 20 built, 15 primed, 10 basecoated, 5 finished', sq.rt.startsWith('20,15,10') && sq.rt.endsWith(',5'), sq.rt);
  ok('the finished number older copies read is still right', sq.done === 5 && sq.stage === 'Built' && sq.sig, JSON.stringify(sq));
  const page = await p.textContent('#app .unitprog');
  ok('the page reads the way a painter says it',
     /20\s*built/.test(page) && /15\s*primed/.test(page) && /10\s*basecoated/.test(page) && /5\s*finished/.test(page), page.replace(/\s+/g,' ').slice(0,200));
  ok('the page shows how many are still to go', /15\s*to go/.test(page));
  ok('one bar shows every stage', await p.evaluate(() => document.querySelectorAll('#app .unitprog .sbar span').length === 4));

  /* totals, model by model */
  const c = await p.evaluate(() => counts());
  /* The Plague Marines (15 at Basecoat, 5 finished) are in this army too. */
  ok('finished: 10 of 42 models (terrain apart)', c.done === 10 && c.total === 42, JSON.stringify(c));
  ok('on the bench: 15 squad + 15 marines + character + Rhino', c.started === 32, String(c.started));
  ok('still to build: none', c.backlog === 0 + 0, String(c.backlog));

  /* a half-built unit is on the bench, and its unbuilt models still count as unbuilt */
  await p.evaluate(() => { data.minis.push({id:'h',name:'Blightlords',sys:data.minis[0].sys,fac:data.minis[0].fac,unit:'Infantry',stage:'Unbuilt',total:10,done:0,photos:[],updated:2});
    const m = data.minis.find(x => x.id==='h'); const cc = stageCounts(m); cc[0]=4; cc[1]=6; setCounts(m, cc); render(); });
  const h = await p.evaluate(() => { const m = data.minis.find(x => x.id==='h'); state.pick.kind = 'build';
    return { started: isStarted(m), unbuilt: allUnbuilt(m), backlog: counts().backlog, inBuildPick: pickPool().includes(m) }; });
  ok('a unit with some models built is on the bench', h.started && !h.unbuilt, JSON.stringify(h));
  ok('its 4 unbuilt models are still counted as still to build', h.backlog === 4, String(h.backlog));
  ok('Pick for me can still choose it as something to build', h.inBuildPick);

  /* older copies of the app */
  const oldEdit = await p.evaluate(() => { const m = data.minis.find(x => x.id==='s'); m.stage = 'Primed'; m.done = 0; return stageCounts(m).join(); });
  ok('a change made by an older copy of the app is respected', oldEdit === '0,0,20,0,0,0,0,0', oldEdit);

  /* changing how many models a unit has */
  await p.evaluate(() => { const m = data.minis.find(x => x.id==='s'); setCounts(m, [0,5,5,5,0,0,0,5]); state.openMini='s'; render(); });
  await p.waitForTimeout(300);
  await p.fill('#eTotal', '22'); await p.click('[data-act="saveMini"]'); await p.waitForTimeout(300);
  ok('two more models arrive unbuilt', await p.evaluate(() => stageCounts(data.minis.find(x => x.id==='s')).join()) === '2,5,5,5,0,0,0,5');
  await p.fill('#eTotal', '15'); await p.click('[data-act="saveMini"]'); await p.waitForTimeout(300);
  ok('fewer models come off the earliest stages first', await p.evaluate(() => stageCounts(data.minis.find(x => x.id==='s')).join()) === '0,0,5,5,0,0,0,5',
     await p.evaluate(() => stageCounts(data.minis.find(x => x.id==='s')).join()));

  /* moving finished models back */
  await p.evaluate(() => { const m = data.minis.find(x => x.id==='s'); setCounts(m, [0,0,0,0,0,0,0,15]); render(); });
  await p.waitForTimeout(300);
  ok('a finished unit offers to move some back', /Move some back/.test(await p.textContent('#app [data-act="moveOn"]')));
  await move(6, 1);
  ok('moving one back to Basing leaves 14 finished', await p.evaluate(() => data.minis.find(x => x.id==='s').done) === 14);

  /* filter and search */
  await p.evaluate(() => { const m = data.minis.find(x => x.id==='s'); setCounts(m, [0,5,5,0,0,0,0,5]); });
  const f = await p.evaluate(() => { state.fStage = 'Primed'; const r = filtered().map(m => m.name); state.fStage = '';
    state.sheet = 'coll'; const html = filterSheetBody(); state.sheet = '';
    const chip = (html.match(/data-fstage="Primed"[^>]*>\s*Primed <span class="n">(\d+)/) || [])[1];
    state.q = 'primed'; const q = filtered().length; state.q = '';
    return { r, chip, q }; });
  ok('filtering by Primed finds the squad by its primed models', f.r.includes('Poxwalkers'), JSON.stringify(f));
  ok('the stage filter counts models at each stage', f.chip === '6', String(f.chip));
  ok('search finds a unit by any stage its models are at', f.q >= 2, String(f.q));

  /* Home */
  await p.evaluate(() => { data.minis.find(x => x.id==='s').updated = Date.now() + 1e6; data.minis.find(x => x.id==='s').photos = ['ph1'];
    state.tab='home'; state.openMini=null; render(); });
  await p.waitForTimeout(300);
  ok('Home shows a unit with its stage bar and "Move models on"',
     !!(await p.$('#app .herobar')) && /Move models on/.test(await p.textContent('#app .homeadv')));

  /* spreadsheet */
  const csv = await p.evaluate(() => { let out=''; const d = window.download; window.download = (n, t) => { out = t; }; exportCsv(); window.download = d; return out; });
  ok('the spreadsheet lists models at each stage', /Built 5; Primed 5; Finished 5/.test(csv), csv.split('\n').find(l => /Poxwalkers/.test(l)));

  /* stays tidy at 320px and 200% text */
  const p2 = await b.newPage({ viewport:{ width:320, height:640 } });
  await p2.goto(URL); await p2.waitForTimeout(1800); await p2.evaluate(SEED);
  await p2.evaluate(() => { document.documentElement.style.fontSize='32px'; const m = data.minis.find(x => x.id==='s'); setCounts(m,[0,5,5,5,0,0,0,5]); render(); });
  await p2.waitForTimeout(400);
  const wide = async () => p2.evaluate(() => { const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('#app *, #dlg *').forEach(el => { if (el.closest('.helpwrap:not(.open)')) return;
      const r = el.getBoundingClientRect(); if (r.width && r.right > vw + 1) bad.push((el.getAttribute('class')||el.tagName)+' '+Math.round(r.right)); });
    return bad.slice(0,3); });
  const w1 = await wide();
  ok('the unit page fits at 320px and 200% text', w1.length === 0, w1.join(', '));
  await p2.click('#app [data-act="moveOn"]'); await p2.waitForTimeout(400);
  const w2 = await wide();
  ok('the move panel fits at 320px and 200% text', w2.length === 0, w2.join(', '));
  ok('the move buttons are real tap targets', await p2.evaluate(() =>
     [...document.querySelectorAll('#dlg .stepbtn, #dlg [data-mvto]')].every(e => e.getBoundingClientRect().height >= 44)));

  ok('no page errors', errs.length === 0, errs.join(' | '));
  console.log(`\n  ${pass} passed, ${fail.length} failed`); await b.close(); process.exit(fail.length ? 1 : 0);
})();
