/* v014: the review's fixes. */
const { chromium } = require('playwright'); const fs = require('fs');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');
const SHOT = __dirname + '/';
const SEED = fs.readFileSync(SHOT+'test_v7.js','utf8').match(/const SEED = `([\s\S]*?)`;/)[1];
let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); } else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 }, hasTouch:true });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForTimeout(2000); await p.evaluate(SEED);
  await p.evaluate(`data.paints=[{id:'p0',name:'Nuln Oil',brand:'Citadel',range:'Shade',hex:'#14100E',stock:'Have it'},{id:'p1',name:'Leadbelcher',brand:'Citadel',range:'Base',hex:'#888D8F',stock:'Have it'}];
    data.swatches=[{id:'sw1',paintId:'p1',undercoatId:'',photoId:'',coats:1,lighting:'',notes:'',created:1}]; state.tab='home'; render();`);
  await p.waitForTimeout(400);

  /* Home */
  const order = await p.evaluate(() => {
    const h = document.querySelector('#app h2'), hero = document.querySelector('#app .hero');
    return { first: h && h.textContent, benchBeforeHero: !!(h && hero && (h.compareDocumentPosition(hero) & Node.DOCUMENT_POSITION_FOLLOWING)) };
  });
  ok('Home opens on Continue painting', order.first === 'Continue painting', order.first);
  ok('the totals come after it', order.benchBeforeHero);
  ok('no "N on the bench" line repeating the ledger', !/\d+ on the bench/i.test(await p.textContent('#app .ehead')));
  await p.screenshot({ path: SHOT + 'V14_home.png' });
  await p.evaluate(`data.minis.forEach(m=>{ if(m.stage!==data.stages[0] && m.stage!==data.stages[data.stages.length-1]) m.stage=data.stages[0]; }); render();`);
  ok('with nothing on the bench, the totals lead', await p.evaluate(() => document.querySelector('#app .ehead .eb').textContent === 'Your collection'));
  await p.evaluate(SEED); await p.waitForTimeout(200);

  /* Hangouts gone */
  ok('four tabs, no Hangouts', (await p.$$eval('#tabs button', b => b.map(x => x.textContent.trim()))).join(',') === 'Home,Collection,Paints,Recipes');

  /* Paints: one line, not 167 tags */
  await p.evaluate(`state.tab='paints'; state.openPaint=null; state.sub=null; render();`); await p.waitForTimeout(300);
  ok('one line says colours are estimates', /maker.s estimates until you photograph a swatch/.test(await p.textContent('.estline')));
  const tags = await p.$$eval('#app .paintrow .tagmini', t => t.map(x => x.textContent.trim()));
  ok('only the photographed paint carries a mark', tags.length === 1 && tags[0] === '1 swatch', tags.join(','));
  ok('the paint page still calls the colour an estimate', await p.evaluate(() => { state.openPaint='p0'; render(); return /estimate/i.test(document.getElementById('app').textContent); }));

  /* slides */
  await p.evaluate(`state.openPaint=null; state.tab='coll'; state.openGame=null; state.openArmy=null; render();`); await p.waitForTimeout(300);
  await p.evaluate(() => { window.__navs = []; new MutationObserver(() => { const v = document.documentElement.dataset.nav; if (v) window.__navs.push(v); })
    .observe(document.documentElement, { attributes:true, attributeFilter:['data-nav'] }); });
  await p.click('.gamecard'); await p.waitForTimeout(500);
  await p.click('.arow'); await p.waitForTimeout(500);
  await p.click('.backlink'); await p.waitForTimeout(500);
  const navs = await p.evaluate(() => window.__navs.join(','));
  ok('going deeper slides forward, Back slides back', navs === 'fwd,fwd,back', navs);
  ok('the slide marker is cleared afterwards', await p.evaluate(() => !document.documentElement.dataset.nav));
  ok('the screens still change', await p.evaluate(() => !!state.openGame && !state.openArmy));

  /* sheet: drag down closes, short drag springs back, x slides out */
  await p.click('.backlink'); await p.waitForTimeout(500);
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(400);
  ok('the panel has a handle', await p.isVisible('#dlg .grab'));
  const box = await p.$eval('#dlg .dlghead', e => { const r = e.getBoundingClientRect(); return { x: r.left + 40, y: r.top + 20 }; });
  await p.mouse.move(box.x, box.y); await p.mouse.down(); await p.mouse.move(box.x, box.y + 40, { steps: 8 }); 
  const mid = await p.evaluate(() => $('#dlg').style.transform);
  ok('it follows the finger', /translateY\(4\dpx\)|translateY\(3\dpx\)/.test(mid), mid);
  await p.waitForTimeout(250); await p.mouse.up(); await p.waitForTimeout(400);
  ok('a short, slow drag springs back', await p.evaluate(() => $('#dlg').open && !$('#dlg').style.transform));
  await p.mouse.move(box.x, box.y); await p.mouse.down(); await p.mouse.move(box.x, box.y + 160, { steps: 6 }); await p.mouse.up();
  await p.waitForTimeout(500);
  ok('a long drag closes it', await p.evaluate(() => !$('#dlg').open && !state.sheet));
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(400);
  await p.click('#dlg .dlghead [data-dlg="cancel"]'); await p.waitForTimeout(80);
  ok('× slides it down first', await p.evaluate(() => $('#dlg').classList.contains('leaving')));
  await p.waitForTimeout(400);
  ok('...then it is closed', await p.evaluate(() => !$('#dlg').open));
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(400);
  await p.click('#dlg [data-fstage="Unbuilt"]'); await p.waitForTimeout(200);
  await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(500);
  ok('Show still applies and closes', await p.evaluate(() => !$('#dlg').open && state.fStage === 'Unbuilt'));
  await p.evaluate(() => { state.fStage=''; render(); });
  /* other dialogs still close normally */
  await p.click('#moreBtn'); await p.waitForTimeout(300);
  await p.click('#dlg .dlghead [data-dlg="cancel"]'); await p.waitForTimeout(300);
  ok('the ⋯ menu still closes at once', await p.evaluate(() => !$('#dlg').open));

  /* reduced motion: fade, not slide */
  const q = await b.newPage({ viewport:{ width:390, height:844 }, reducedMotion:'reduce' });
  await q.goto(URL); await q.waitForTimeout(2000); await q.evaluate(SEED);
  await q.evaluate(() => { window.__navs = []; new MutationObserver(() => { const v = document.documentElement.dataset.nav; if (v) window.__navs.push(v); })
    .observe(document.documentElement, { attributes:true, attributeFilter:['data-nav'] }); });
  await q.click('.gamecard'); await q.waitForTimeout(400);
  ok('Reduce Motion: a fade, not a slide', (await q.evaluate(() => window.__navs.join(','))) === 'fade');
  await q.click('[data-act="backGames"]'); await q.waitForTimeout(300);
  await q.click('[data-act="openFilter"]'); await q.waitForTimeout(300);
  await q.click('#dlg .dlghead [data-dlg="cancel"]'); await q.waitForTimeout(60);
  ok('Reduce Motion: the panel closes at once', await q.evaluate(() => !$('#dlg').open));

  /* big text */
  const z = await b.newPage({ viewport:{ width:320, height:700 } });
  await z.goto(URL); await z.waitForTimeout(2000); await z.evaluate(SEED);
  await z.addStyleTag({ content:'html{font-size:200% !important}' });
  for (const [n, js] of [['Collection',`state.tab='coll';render();`],['one army',`state.openArmy=armyKey(data.minis[0]);render();`],['a model',`state.openMini='m2';render();`],['Home',`state.tab='home';state.openMini=null;render();`]]){
    await z.evaluate(js); await z.waitForTimeout(200);
    const over = await z.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    ok(`200% text at 320px, no sideways scroll: ${n}`, over <= 0, over + 'px');
  }
  ok('no page errors', errs.length === 0, errs.join(' | '));
  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length) process.exit(1);
})();
