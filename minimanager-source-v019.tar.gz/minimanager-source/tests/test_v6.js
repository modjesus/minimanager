/* v009: the shape language and unit types.

   The thing worth testing hardest here is that gold is never used for a WORD.
   The brand gold measures 2.15:1 on the ivory page, so a gold label is
   unreadable; every gold text colour must be --gold-ink instead. A screenshot
   will not catch that, and neither will a human eye in good light. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');

let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                          else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

const lum = h => { const c=[1,3,5].map((_,i)=>parseInt(h.slice(1+i*2,3+i*2),16)/255)
  .map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4); return .2126*c[0]+.7152*c[1]+.0722*c[2]; };
const cr = (a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
const hex = rgb => { const m = rgb.match(/\d+/g);
  return '#' + m.slice(0,3).map(n=>(+n).toString(16).padStart(2,'0')).join('').toUpperCase(); };

const SEED = `
authGate='in';
syncState.user={uid:'t',displayName:'Joe',email:'j@e.com'}; syncState.status='ok'; data.settings.setupDone=true; setupChecked=true;
urlCache.set('p1','data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==');
data.minis=[
 {id:'m1',name:'Intercessor Squad',stage:data.stages[3],total:5,done:0,photos:['p1'],unit:'Infantry',updated:9},
 {id:'m2',name:'Ogre Bulls',stage:data.stages[data.stages.length-1],total:6,done:6,unit:'Monster',updated:8},
 {id:'m3',name:'Turnip28 Toffs',stage:data.stages[0],total:10,done:0,updated:7}
];
data.paints=[{id:'q1',name:'Mephiston Red',brand:'Citadel',range:'Base',hex:'#7C1D1D',stock:'Running low',updated:1}];
data.supplies=[{id:'s1',name:'Plastic glue',stock:'Out',updated:1}];
`;

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await p.goto(URL); await p.waitForTimeout(2200);
  await p.evaluate(SEED);

  ok('version reads v019', await p.evaluate(() => APP_VERSION) === 'v019');

  /* ---------- unit types: plain words, nobody's copyright ---------- */
  const ut = await p.evaluate(() => UNIT_TYPES);
  ok('eleven unit types ship', ut.length === 11, 'got ' + ut.length);
  ok('they are the universal categories',
     ['Infantry','Cavalry','Character','Monster','Vehicle','Artillery','Flyer','Swarm','Beast','Warmachine','Terrain']
       .every(x => ut.includes(x)), ut.join(','));
  /* The whole point: no publisher's force-organisation vocabulary. */
  ok('no publisher force-organisation slots crept in',
     !ut.some(x => /^(HQ|Troops|Elites|Fast Attack|Heavy Support|Lord of War|Battleline)$/i.test(x)),
     ut.join(','));
  ok('the help says points costs are not coming',
     /publisher/i.test(HELPTXT = await p.evaluate(() => JSON.stringify(HELP.unitType))) &&
     /copyright/i.test(HELPTXT));

  /* v019: a unit of several models has its own progress card (test_v13); the
     pot and ladder are for a single model, so this one is a single model. */
  await p.evaluate(() => { data.minis.find(x => x.id==='m1').total = 1; state.tab='coll'; state.openMini='m1'; render(); });
  await p.waitForTimeout(450);
  ok('the unit type field is on the entry screen',
     await p.evaluate(() => !!document.querySelector('#eUnit')));
  ok('the saved unit type is pre-selected',
     await p.evaluate(() => document.querySelector('.chipwrap [data-val="Infantry"]')
       ?.getAttribute('aria-pressed')) === 'true');
  ok('"Type my own" is offered for other games',
     await p.evaluate(() => !!document.querySelector('[data-own]')));
  ok('the unit type shows in the summary line',
     (await p.textContent('#app')).includes('Infantry'));

  /* ---------- the pot ---------- */
  const pot = await p.evaluate(() => ({
    svg: !!document.querySelector('.pot'),
    level: !!document.querySelector('.potfill'),
    name: document.querySelector('.stagename')?.textContent,
    adv: document.querySelector('.advance')?.textContent.trim(),
    jump: !!document.querySelector('[data-jump]'),
    ladderShut: !document.getElementById('ladder').classList.contains('open'),
    rows: document.querySelectorAll('.lrow').length
  }));
  ok('the pot is drawn', pot.svg && pot.level);
  ok('it names the stage you are on', pot.name === 'Basecoat', pot.name);
  ok('the big button names the next stage', /Move to Shading/.test(pot.adv || ''), pot.adv);
  ok('the ladder starts shut', pot.ladderShut);
  ok('the ladder holds every stage', pot.rows === 8, 'rows ' + pot.rows);

  /* every ladder row must be a real tap target, which was the whole problem */
  const taps = await p.evaluate(() => {
    document.querySelector('[data-jump]').click();
    return [...document.querySelectorAll('.lrow')].map(r => Math.round(r.getBoundingClientRect().height));
  });
  await p.waitForTimeout(400);
  ok('every stage is at least a 44px target', Math.min(...taps) >= 44, 'smallest ' + Math.min(...taps));
  ok('no stage name is truncated to a stub',
     await p.evaluate(() => [...document.querySelectorAll('.lname')]
       .every(e => e.scrollWidth <= e.clientWidth + 1)));
  ok('exactly one row is marked as where you are',
     await p.evaluate(() => document.querySelectorAll('.lrow[data-s="now"]').length) === 1);

  /* jumping backwards from the ladder */
  await p.evaluate(() => [...document.querySelectorAll('.lrow')]
    .find(r => r.dataset.stage === 'Built').click());
  await p.waitForTimeout(600);
  ok('tapping a stage in the ladder moves you there',
     await p.evaluate(() => data.minis.find(m=>m.id==='m1').stage) === 'Built');
  ok('picking from the ladder closes it',
     await p.evaluate(() => !document.getElementById('ladder').classList.contains('open')));
  ok('the level fell when you went backwards',
     await p.evaluate(() => parseFloat(document.querySelector('.potfill').style.transform
       .replace(/[^\d.-]/g,''))) > 68);

  /* ---------- the ledger ---------- */
  await p.evaluate(() => { state.openMini=null; state.tab='home'; render(); });
  await p.waitForTimeout(450);
  const home = await p.evaluate(() => ({
    hero: document.querySelector('.hero b')?.textContent,
    heroSize: parseFloat(getComputedStyle(document.querySelector('.hero b')).fontSize),
    heroFont: getComputedStyle(document.querySelector('.hero b')).fontFamily,
    cells: document.querySelectorAll('.lcell').length,
    keyline: !!document.querySelector('.pline'),
    oldBoxes: document.querySelectorAll('.stat, .stats').length,
    eyebrow: document.querySelector('.ehead .eb')?.textContent.trim()
  }));
  ok('one number is the hero', home.hero === '6', home.hero);
  ok('the hero is set in the display face', /Indira/.test(home.heroFont), home.heroFont);
  ok('the hero is genuinely large', home.heroSize >= 44, String(home.heroSize));
  ok('three figures sit on the ledger', home.cells === 3, String(home.cells));
  ok('a painted progress line sits under the total', home.keyline);
  ok('the four identical stat boxes are gone', home.oldBoxes === 0, String(home.oldBoxes));
  ok('the editorial eyebrow is there', home.eyebrow === 'Your collection', home.eyebrow);

  /* ---------- gold is never a word ---------- */
  const golds = await p.evaluate(() => {
    const out = [];
    document.querySelectorAll('.ehead .eb,.grouphead,.pill,.ltag,.lcell span,.vsub').forEach(el => {
      const cs = getComputedStyle(el);
      if (el.textContent.trim()) out.push({ what: el.className || el.tagName,
        colour: cs.color, bg: cs.backgroundColor, size: parseFloat(cs.fontSize) });
    });
    return out;
  });
  const BRAND_GOLD = '#C6A962';
  ok('no visible text is painted in the raw brand gold',
     golds.every(g => hex(g.colour) !== BRAND_GOLD),
     golds.filter(g => hex(g.colour) === BRAND_GOLD).map(g=>g.what).join(','));
  ok('every gold label clears 4.5:1 on the page',
     golds.every(g => cr(hex(g.colour), '#FDF8EF') >= 4.5),
     golds.filter(g => cr(hex(g.colour),'#FDF8EF') < 4.5)
          .map(g => g.what + ' ' + cr(hex(g.colour),'#FDF8EF').toFixed(2)).join(', '));

  /* ---------- photo-first tiles ---------- */
  /* Tiles of every model at once, the way only a test needs them: the app
     itself never shows two armies' models in one grid any more. */
  await p.evaluate(() => { document.getElementById('app').innerHTML =
    '<div class="grid">' + data.minis.map(tile).join('') + '</div>'; hydratePhotos(); });
  await p.waitForTimeout(300);
  const tiles = await p.evaluate(() => {
    const withPhoto = document.querySelector('.tile:not(.nophoto)');
    const without = document.querySelector('.tile.nophoto');
    const g = el => el ? getComputedStyle(el) : null;
    return {
      photoBorder: withPhoto ? g(withPhoto).borderTopWidth : null,
      metaOverlaid: withPhoto ? g(withPhoto.querySelector('.meta')).position : null,
      metaFade: withPhoto ? g(withPhoto.querySelector('.meta')).backgroundImage.includes('gradient') : null,
      captionColour: withPhoto ? g(withPhoto.querySelector('.meta')).color : null,
      emptyHasFade: without ? g(without.querySelector('.meta')).backgroundImage.includes('gradient') : null,
      emptyCaption: without ? g(without.querySelector('.meta')).color : null,
      mark: !!document.querySelector('.tile .mk')
    };
  });
  ok('a photographed tile has no border round it', tiles.photoBorder === '0px', tiles.photoBorder);
  ok('its caption sits over the photo', tiles.metaOverlaid === 'absolute');
  ok('the caption has a fade behind it', tiles.metaFade === true);
  ok('the caption clears 4.5:1 against the darkest part of that fade',
     cr(hex(tiles.captionColour), '#15232F') >= 4.5,
     cr(hex(tiles.captionColour), '#15232F').toFixed(2));
  ok('an entry with no photo gets no dark fade over nothing', tiles.emptyHasFade === false);
  ok('its caption is ordinary page text',
     cr(hex(tiles.emptyCaption), '#FFFFFF') >= 4.5,
     cr(hex(tiles.emptyCaption), '#FFFFFF').toFixed(2));
  ok('the stage bar is drawn on the tile', await p.evaluate(() => !!document.querySelector('.tile .lvl')));

  /* the sparkle is reserved for finished, and nothing else */
  await p.evaluate(() => { document.getElementById('app').innerHTML =
    '<div class="grid">' + data.minis.map(tile).join('') + '</div>'; });
  await p.waitForTimeout(200);
  const marks = await p.evaluate(() => [...document.querySelectorAll('.tile')].map(t => {
    const name = t.querySelector('.meta b').textContent;
    const svg = t.querySelector('.mk');
    const d = svg ? svg.querySelector('path').getAttribute('d') : '';
    return { name, kind: !svg ? 'none' : d.startsWith('M 150 16') ? 'sparkle' : 'drop' };
  }));
  const kind = n => (marks.find(m => m.name === n) || {}).kind;
  ok('finished gets the sparkle', kind('Ogre Bulls') === 'sparkle', JSON.stringify(marks));
  ok('in progress gets the bar, not a corner mark', kind('Intercessor Squad') === 'none' && await p.evaluate(() => !!document.querySelector('.tile .lvl')), JSON.stringify(marks));
  ok('untouched gets no mark at all', kind('Turnip28 Toffs') === 'none', JSON.stringify(marks));

  /* ---------- the shopping list ---------- */
  await p.evaluate(() => { state.tab='shop'; state.shopTab='need'; render(); });
  await p.waitForTimeout(400);
  const shop = await p.evaluate(() => {
    const rows = [...document.querySelectorAll('.shoprow')];
    return {
      drops: document.querySelectorAll('.shopdrop').length,
      squares: document.querySelectorAll('.shoprow .sw').length,
      paintDropFilled: rows[0]?.querySelector('.shopdrop path').getAttribute('fill'),
      glueDropHollow: rows[rows.length-1]?.querySelector('.shopdrop path').getAttribute('fill'),
      pillBorder: getComputedStyle(document.querySelector('.pill')).borderTopWidth
    };
  });
  ok('every shop row shows a drop', shop.drops === 2, String(shop.drops));
  ok('the old square chips are gone', shop.squares === 0, String(shop.squares));
  ok('a paint drop carries its real colour', shop.paintDropFilled === '#7C1D1D', shop.paintDropFilled);
  ok('a supply with no colour gets a hollow drop', shop.glueDropHollow === 'none', shop.glueDropHollow);
  ok('the stock pill lost its border', shop.pillBorder === '0px', shop.pillBorder);

  /* ---------- reduced motion keeps the meaning ---------- */
  await p.emulateMedia({ reducedMotion:'reduce' });
  await p.evaluate(() => { state.tab='coll'; state.openMini='m1'; render(); });
  await p.waitForTimeout(400);
  const rm = await p.evaluate(() => {
    const d = getComputedStyle(document.querySelector('.potfill')).transitionDuration;
    return parseFloat(d);
  });
  ok('the paint level still moves under reduced motion, just quickly',
     rm > 0.05 && rm < 0.4, String(rm));
  await p.emulateMedia({ reducedMotion:'no-preference' });

  /* ---------- nothing overflows, nothing errored ---------- */
  for (const tab of ['home','coll','paints','shop']){
    await p.evaluate(t => { state.tab=t; state.openMini=null; render(); }, tab);
    await p.waitForTimeout(350);
    const over = await p.evaluate(() => {
      const vw = document.documentElement.clientWidth, bad = [];
      document.querySelectorAll('*').forEach(el => {
        /* A shut help panel or ladder still has laid-out children; the
           wrapper clips them with overflow:hidden, so they are not visible
           overflow and must not be counted. */
        if (el.closest('.helpwrap:not(.open), .ownwrap:not(.open), .ladder:not(.open)')) return;
        const r = el.getBoundingClientRect();
        if (r.width && r.right > vw + 1) bad.push((el.getAttribute?.('class') || el.tagName) + ' ' + Math.round(r.right)); });
      return bad.slice(0,3);
    });
    ok(`no sideways overflow on ${tab} at 390px`, over.length === 0, over.join(', '));
  }

  /* 320px at 200% text is the hardest case this app has to survive */
  const p2 = await b.newPage({ viewport:{ width:320, height:640 } });
  await p2.goto(URL); await p2.waitForTimeout(2000);
  await p2.evaluate(SEED);
  await p2.evaluate(() => { document.documentElement.style.fontSize='32px';
                            state.tab='coll'; state.openMini='m1'; render(); });
  await p2.waitForTimeout(500);
  const over2 = await p2.evaluate(() => {
    const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.closest('.helpwrap:not(.open), .ownwrap:not(.open), .ladder:not(.open)')) return;
      const r = el.getBoundingClientRect();
      if (r.width && r.right > vw + 1) bad.push((el.getAttribute?.('class') || el.tagName) + ' ' + Math.round(r.right)); });
    return bad.slice(0,3);
  });
  ok('the stage screen reflows at 320px and 200% text', over2.length === 0, over2.join(', '));

  /* Every "?" answer open at once, at the hardest size. The base-size chart
     is a table, and a table will not shrink below its own content unless it
     is told to — it used to run 457px wide on a 320px screen. */
  await p2.evaluate(() => document.querySelectorAll('.q').forEach(q => q.click()));
  await p2.waitForTimeout(600);
  const over3 = await p2.evaluate(() => {
    const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.closest('.helpwrap:not(.open), .ownwrap:not(.open), .ladder:not(.open)')) return;
      const r = el.getBoundingClientRect();
      if (r.width && r.right > vw + 1) bad.push((el.getAttribute?.('class') || el.tagName) + ' ' + Math.round(r.right)); });
    return bad.slice(0,3);
  });
  ok('the open "?" answers reflow at 320px and 200% text too',
     over3.length === 0, over3.join(', '));
  ok('the ladder open at 320px and 200% text does not overflow either',
     await p2.evaluate(async () => {
       data.minis.find(x => x.id==='m1').total = 1; render();   /* the ladder is the single-model view */
       document.querySelector('[data-jump]').click();
       await new Promise(r => setTimeout(r, 400));
       const vw = document.documentElement.clientWidth;
       return [...document.querySelectorAll('.lrow, .lrow *')]
         .every(el => el.getBoundingClientRect().right <= vw + 1);
     }));
  await p2.close();

  ok('no uncaught errors anywhere in this run', errs.length === 0, errs.slice(0,2).join(' | '));

  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('\n  FAILURES:'); fail.forEach(f => console.log('    - ' + f)); process.exit(1); }
})();
