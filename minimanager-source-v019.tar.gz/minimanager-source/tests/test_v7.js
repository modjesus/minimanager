/* v013: game, then army, then models.

   The rule Joe set: armies are never mixed. Death Guard must never sit in
   the same grid or list as Tyranids. And the oldest rule here still holds:
   no model may drop out of sight because it has no game or army set. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');
const SHOT = __dirname + '/';
let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                          else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

const SEED = `
authGate='in'; syncState.user={uid:'t',email:'j@e.com'}; syncState.status='ok'; syncState.firstPullDone=true;
data.settings.setupDone=true; setupChecked=true;
data.systems=[]; data.factions=[];
const S=n=>systemIdByName(n), F=(n,s)=>factionIdByName(n,s);
const w40=S('Warhammer 40,000'), nec=S('Necromunda'), kt=S('Kill Team');
const dg=F('Death Guard',w40), ty=F('Tyranids',w40), del=F('House Delaque',nec), esc_=F('House Escher',nec), vs=F('Voidscarred',kt);
let t=0;
const mk=(n,fac,sys,stage,total,done,acq)=>({id:'m'+(++t),name:n,fac,sys,stage:data.stages[stage],total,done,
  price:10,acquired:acq||'',photos:[],updated:t});
data.minis=[
  mk('Plague Marines',dg,w40,7,7,7),  mk('Poxwalkers',dg,w40,5,20,12), mk('Bloat-drone',dg,w40,2,1,0),
  mk('Mortarion',dg,w40,0,1,0,'2023-03-18'), mk('Blightlords',dg,w40,0,5,0,'2024-11-23'),
  mk('Tyranid Warriors',ty,w40,5,3,1), mk('Termagants',ty,w40,0,20,0,'2025-02-14'),
  mk('Delaque gang',del,nec,7,8,8), mk('Escher gang',esc_,nec,3,8,0),
  mk('Kill team',vs,kt,5,9,4),
  mk('Loose marine',null,w40,1,1,0), mk('Mystery box',null,null,0,3,0)
];
state.tab='coll'; state.openGame=null; state.openArmy=null; state.openMini=null; state.q=''; render();
`;

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForTimeout(2200);
  await p.evaluate(SEED); await p.waitForTimeout(500);

  /* ---------- step 1: your games ---------- */
  const games = await p.$$eval('.gamecard', els => els.map(e => e.querySelector('b').textContent + '|' + e.querySelector('.aname > span').textContent.replace(/\s+/g,' ').trim()));
  ok('Collection opens on your games, one line each', games.length === 3, games.join(' / '));
  ok('biggest game first', games[0].startsWith('Warhammer 40,000'), games[0]);
  ok('anything with no game set is still there, as a quiet link last',
     /with no game set/.test(await p.textContent('#app .idxmore')) &&
     await p.evaluate(() => document.querySelector('#app .idxmore') === [...document.querySelectorAll('#app button')].pop()));
  ok('Necromunda counts gangs', /2 gangs/.test(games.find(g => g.startsWith('Necromunda')) || ''), games.join(' / '));
  ok('Kill Team counts squads', /1 squad\b/.test(games.find(g => g.startsWith('Kill Team')) || ''), games.join(' / '));
  ok('no model tiles at the top level', (await p.$$('#app .tile')).length === 0);
  ok('the top bar says Collection', (await p.textContent('#screenTitle')) === 'Collection');
  await p.screenshot({ path: SHOT + 'V13_games.png' });

  /* ---------- step 2: one game's armies ---------- */
  await p.click('.gamecard:has-text("Warhammer 40,000")'); await p.waitForTimeout(500);
  ok('the top bar names the game', (await p.textContent('#screenTitle')) === 'Warhammer 40,000');
  ok('a way back to Collection at the top', (await p.textContent('.backlink')).includes('Collection'));
  const armies = await p.$$eval('.arow b', els => els.map(e => e.textContent));
  ok('only this game\'s armies, biggest first', armies.join(',') === 'Death Guard,Tyranids', armies.join(','));
  ok('unfiled models are a quiet link last', /with no army set/.test(await p.textContent('#app .idxmore')));
  ok('armies only, no models mixed in', (await p.$$('#app .tile, #app .mrow')).length === 0);
  await p.screenshot({ path: SHOT + 'V13_game.png' });

  /* ---------- step 3: one army ---------- */
  await p.click('.arow:has-text("Death Guard")'); await p.waitForTimeout(500);
  ok('the top bar names the army', (await p.textContent('#screenTitle')) === 'Death Guard');
  ok('the way back names the game', (await p.textContent('.backlink')).includes('Warhammer 40,000'));
  const shelves = await p.$$eval('.shelf h2', els => els.map(e => e.textContent));
  ok('three shelves in order: bench, still to build, finished', shelves.join(',') === 'On the bench,Still to build,Finished', shelves.join(','));
  const names = await p.$$eval('#app .tile .meta b, #app .mrow .grow', els => els.map(e => e.textContent.trim()));
  ok('every model shown is Death Guard', names.sort().join(',') === 'Blightlords,Bloat-drone,Mortarion,Plague Marines,Poxwalkers', names.join(','));
  const waiting = await p.$$eval('#app .mrow .grow', els => els.map(e => e.textContent.trim()));
  ok('still to build runs longest waiting first', waiting.join(',') === 'Mortarion,Blightlords', waiting.join(','));
  ok('the bench runs furthest along first', (await p.$$eval('.grid', g => g[0].querySelector('.tile .meta b').textContent)) === 'Poxwalkers');
  ok('no stage chips any more', (await p.$$('#app [data-astage]')).length === 0);
  await p.screenshot({ path: SHOT + 'V13_army.png', fullPage: true });

  /* Add here files it under Death Guard */
  await p.click('#actslot [data-act="addHere"]'); await p.waitForTimeout(500);
  ok('Add inside an army offers to file it there', (await p.textContent('#dlgBody')).includes('Death Guard'));
  await p.click('#dlg [data-dlg="cancel"]'); await p.waitForTimeout(200);

  /* open a model, then back */
  await p.click('#app .tile:has-text("Poxwalkers")'); await p.waitForTimeout(500);
  ok('a model\'s way back names its army', (await p.textContent('.backlink')).includes('Death Guard'));
  await p.click('.backlink'); await p.waitForTimeout(500);
  ok('...and goes back to that army', await p.evaluate(() => !state.openMini && state.openArmy && (document.getElementById('screenTitle').textContent === 'Death Guard')));
  await p.click('.backlink'); await p.waitForTimeout(250);
  await p.click('.backlink'); await p.waitForTimeout(250);
  ok('back, back lands on your games', (await p.$$('.gamecard')).length === 3);

  /* a game with several gangs always shows the step */
  await p.click('.gamecard:has-text("Necromunda")'); await p.waitForTimeout(500);
  ok('Necromunda shows both its gangs', (await p.$$eval('.arow b', e => e.map(x => x.textContent).sort().join(','))) === 'House Delaque,House Escher');
  await p.click('.backlink'); await p.waitForTimeout(500);
  await p.click('.gamecard:has-text("Kill Team")'); await p.waitForTimeout(500);
  ok('Kill Team still shows the squad step with one squad',
     await p.evaluate(() => document.querySelectorAll('.arow').length === 1 && !state.openArmy));
  await p.click('.backlink'); await p.waitForTimeout(200);

  /* ---------- search: grouped ---------- */
  await p.fill('#q', 'a'); await p.waitForTimeout(400);
  const groups = await p.evaluate(() => {
    const out = []; let cur = null;
    document.querySelectorAll('#app .crumb, #app .mrow').forEach(el => {
      if (el.classList.contains('crumb')) out.push(cur = { head: el.textContent.trim(), keys: new Set() });
      else { const m = data.minis.find(x => x.id === el.dataset.open); cur.keys.add(armyKey(m)); }
    });
    return out.map(g => ({ head: g.head, armies: g.keys.size }));
  });
  ok('search results come under game and army headings', groups.length >= 4, JSON.stringify(groups));
  ok('no heading holds two armies', groups.every(g => g.armies === 1), JSON.stringify(groups));
  await p.screenshot({ path: SHOT + 'V13_search.png' });
  await p.click('#app .crumb'); await p.waitForTimeout(500);
  ok('a heading opens that army', await p.evaluate(() => !!state.openArmy && state.q === ''));
  await p.evaluate(() => { state.openArmy = null; state.openGame = null; render(); });

  /* ---------- filter: stage and sort, grouped ---------- */
  await p.click('[data-act="openFilter"]'); await p.waitForTimeout(500);
  ok('the filter has no game or army rows (those are the steps)', (await p.$$('#dlg [data-fsys], #dlg [data-ffac]')).length === 0);
  await p.click('#dlg [data-fstage="Unbuilt"]'); await p.waitForTimeout(200);
  await p.click('#dlg [data-sort="waiting"]'); await p.waitForTimeout(200);
  await p.click('#dlg [data-dlg="ok"]'); await p.waitForTimeout(500);
  const unb = await p.$$eval('#app .crumb', e => e.map(x => x.textContent.trim()));
  ok('unbuilt across everything, still grouped by army', unb.length === 3 && unb[0].includes('Death Guard'), unb.join(' / '));
  await p.evaluate(() => { state.fStage=''; state.sort=''; render(); });

  /* ---------- home ---------- */
  await p.evaluate(() => { state.tab='home'; state.openGame=null; state.openArmy=null; render(); });
  await p.waitForTimeout(500);
  const home = await p.evaluate(() => {
    const out = [];
    document.querySelectorAll('#app .crumb').forEach(c => {
      const grid = c.nextElementSibling;
      const keys = new Set([...grid.querySelectorAll('.tile')].map(t => armyKey(data.minis.find(m => m.id === t.dataset.open))));
      out.push(keys.size);
    });
    return out;
  });
  ok('Home: the bench is grouped by army', home.length >= 2, JSON.stringify(home));
  ok('Home: no group mixes two armies', home.every(n => n === 1), JSON.stringify(home));
  ok('Home: nothing unbuilt on the bench', await p.evaluate(() =>
     [...document.querySelectorAll('#app .tile')].every(t => stageIx(data.minis.find(m => m.id === t.dataset.open)) > 0)));
  await p.screenshot({ path: SHOT + 'V13_home.png' });
  await p.click('#app .crumb'); await p.waitForTimeout(500);
  ok('Home: an army heading opens that army in Collection', await p.evaluate(() => state.tab === 'coll' && !!state.openArmy));
  await p.evaluate(() => { state.tab='home'; state.openArmy=null; state.openGame=null; render(); });
  await p.click('#app .tile'); await p.waitForTimeout(500);
  await p.click('.backlink'); await p.waitForTimeout(500);
  ok('Home → model → back goes to that model\'s army', await p.evaluate(() => state.tab === 'coll' && !!state.openArmy && !state.openMini));

  /* ---------- reflow and dark ---------- */
  await p.setViewportSize({ width:320, height:700 });
  for (const [name, js] of [['games','state.openGame=null;state.openArmy=null;'],
                            ['game',"state.openGame=data.systems[0].id;state.openArmy=null;"],
                            ['army',"state.openArmy=armyKey(data.minis[0]);"]]){
    await p.evaluate(`state.tab='coll';state.openMini=null;${js}render();`); await p.waitForTimeout(200);
    const over = await p.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    ok(`no sideways scroll at 320px: ${name}`, over <= 0, over + 'px');
    const small = await p.evaluate(() => [...document.querySelectorAll('#app button, header button')]
      .filter(b => b.offsetParent && b.getBoundingClientRect().height < 40).map(b => b.className + ' ' + Math.round(b.getBoundingClientRect().height)));
    ok(`everything tappable is tall enough: ${name}`, small.length === 0, small.join(','));
  }
  await p.setViewportSize({ width:390, height:844 });
  await p.emulateMedia({ colorScheme:'dark' });
  await p.evaluate(() => { state.openArmy=armyKey(data.minis[0]); render(); }); await p.waitForTimeout(500);
  await p.screenshot({ path: SHOT + 'V13_army_dark.png' });
  ok('no page errors', errs.length === 0, errs.join(' | '));
  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('  FAILURES:'); fail.forEach(f => console.log('   - ' + f)); process.exit(1); }
})();
