/* v003 checks. Everything new, plus the two things I nearly broke:
   the paint-stock filter chips and the stage strip's .lab captions. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');

let pass = 0, fail = [];
const ok  = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                           else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

(async () => {
  const b = await chromium.launch();

  /* ---------- a fresh install, phone sized ---------- */
  let p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto(URL); await p.waitForTimeout(2200);
  // v004 puts a sign-in gate in front of everything. Stand in for a signed-in
  // user so the rest of these checks still exercise the app itself.
  await p.evaluate(() => {
    authGate = 'in';
    syncState.user = { uid:'testuid', displayName:'Test', email:'t@example.com' };
    state.tab = 'home'; render();
  });
  await p.waitForTimeout(400);

  ok('boots with no script errors', errs.length === 0, errs.slice(0,2).join(' | '));
  ok('version reads v019', await p.evaluate(() => APP_VERSION) === 'v019');

  /* ---------- presets loaded ---------- */
  const presets = await p.evaluate(() => ({
    systems: SYSTEMS.length,
    fortyk: (SYSTEMS.find(s => s.name === 'Warhammer 40,000')||{groups:[]}).groups
              .reduce((n,g) => n + g.items.length, 0),
    aos: (SYSTEMS.find(s => s.name === 'Warhammer: Age of Sigmar')||{groups:[]}).groups
              .reduce((n,g) => n + g.items.length, 0),
    undercoats: data.undercoats.length,
    colourForge: data.undercoats.filter(u => u.brand === 'The Colour Forge').length,
    citadel: data.undercoats.filter(u => u.brand === 'Citadel').length,
    noFakeHex: data.undercoats.filter(u => u.brand === 'The Colour Forge' && u.hex).length,
    techniques: TECHNIQUES.length,
    baseSizes: BASE_SIZES.length
  }));
  ok('20 game systems', presets.systems >= 20, String(presets.systems));
  ok('40K army list present', presets.fortyk === 25, String(presets.fortyk));
  ok('Age of Sigmar army list present', presets.aos === 27, String(presets.aos));
  ok('undercoats topped up from presets', presets.undercoats === 65, String(presets.undercoats));
  ok('Colour Forge primers included', presets.colourForge === 31, String(presets.colourForge));
  ok('Citadel sprays included', presets.citadel === 11, String(presets.citadel));
  ok('no invented Colour Forge colours', presets.noFakeHex === 0,
     presets.noFakeHex + ' had a made-up hex');
  ok('techniques carry a meaning', presets.techniques >= 16 &&
     await p.evaluate(() => TECHNIQUES.every(t => t[1] && t[1].length > 20)));
  ok('base size chart present', presets.baseSizes >= 17, String(presets.baseSizes));

  /* ---------- quick add ---------- */
  await p.click('#actslot [data-act="addHere"], #app [data-act="addMini"]'); await p.waitForTimeout(250);
  ok('add dialog opens', await p.isVisible('#mName'));
  ok('only one field is visible at first',
     await p.isVisible('#mName') && !(await p.isVisible('#mSys')));
  ok('"More details" is there and closed',
     await p.isVisible('details.more > summary') &&
     !(await p.evaluate(() => document.querySelector('details.more').open)));

  await p.click('details.more > summary'); await p.waitForTimeout(200);
  ok('More details opens', await p.isVisible('#mSys'));

  /* ---------- the army list follows the system ---------- */
  await p.selectOption('#mSys', 'Warhammer 40,000'); await p.waitForTimeout(200);
  const k40 = await p.evaluate(() => [...document.querySelectorAll('#mFac option')].map(o => o.textContent));
  ok('40K armies appear', k40.includes('Adeptus Custodes') && k40.includes('Necrons'));
  ok('40K armies are grouped',
     await p.evaluate(() => document.querySelectorAll('#mFac optgroup').length >= 3));

  await p.selectOption('#mFac', 'Necrons'); await p.waitForTimeout(100);
  await p.selectOption('#mSys', 'Warhammer: Age of Sigmar'); await p.waitForTimeout(250);
  const aos = await p.evaluate(() => [...document.querySelectorAll('#mFac option')].map(o => o.textContent));
  ok('army list swaps with the system', aos.includes('Stormcast Eternals') && !aos.includes('Necrons'));
  ok('stale army is cleared, not carried over',
     await p.evaluate(() => document.querySelector('#mFac').value) === '');

  ok('every army list offers "Type my own"', aos.some(o => o.indexOf('Type my own') === 0));
  await p.selectOption('#mFac', '__own'); await p.waitForTimeout(200);
  ok('"Type my own" reveals a text box', await p.isVisible('#mFacOwn'));

  await p.fill('#mFacOwn', 'My Own Warband');
  await p.fill('#mName', 'Test Unit');
  await p.click('[data-dlg="ok"]'); await p.waitForTimeout(400);
  const saved = await p.evaluate(() => {
    const m = data.minis[data.minis.length - 1];
    return { name:m.name, sys:sysName(m.sys), fac:facName(m.fac) };
  });
  ok('saves with a typed army', saved.name === 'Test Unit' && saved.fac === 'My Own Warband',
     JSON.stringify(saved));
  ok('saves the system it was filed under', saved.sys === 'Warhammer: Age of Sigmar', saved.sys);

  /* ---------- it remembers last time ---------- */
  await p.click('#actslot [data-act="addHere"], #app [data-act="addMini"]'); await p.waitForTimeout(250);
  ok('next add remembers where the last one went',
     (await p.textContent('#dlgBody')).includes('My Own Warband'));
  await p.click('[data-dlg="cancel"]'); await p.waitForTimeout(200);

  /* ---------- the "?" helpers ---------- */
  await p.click('#actslot [data-act="addHere"], #app [data-act="addMini"]'); await p.waitForTimeout(200);
  await p.click('details.more > summary'); await p.waitForTimeout(200);
  /* v009 note: unit type now sits above base size, so the first "?" on the
     form is no longer the base-size one. Target it by its own label instead
     of by position, which is what this test should always have done. */
  const qb = await p.$('.flab:has(label[for="mBase"]) .q');
  ok('a "?" button exists on the base size field', !!qb);
  ok('the unit type field has its own "?" above it',
     await p.evaluate(() => !!document.querySelector('.flab:has(#mUnitlab) .q')));
  /* Every answer must start shut, not just the first one on the form. */
  ok('every answer starts closed',
     await p.evaluate(() => [...document.querySelectorAll('.helpwrap')].every(w =>
       !w.classList.contains('open')
       && w.querySelector('div').getBoundingClientRect().height < 1)));
  await qb.click(); await p.waitForTimeout(250);
  /* Which helpwrap belongs to which field depends on the form's order, so
     assert on whichever one actually opened rather than on position. */
  const opened = await p.evaluate(() => {
    const w = [...document.querySelectorAll('.helpwrap')].filter(x => x.classList.contains('open'));
    return { count: w.length,
             tall: w.length === 1 && w[0].querySelector('div').getBoundingClientRect().height > 10,
             text: w.length === 1 ? w[0].textContent : '' };
  });
  ok('tapping "?" opens exactly one answer', opened.count === 1, 'opened ' + opened.count);
  ok('the answer actually has height', opened.tall);
  ok('aria-expanded flips to true',
     await p.evaluate(el => el.getAttribute('aria-expanded'), qb) === 'true');
  ok('the answer is the real base size chart', opened.text.includes('32mm'),
     opened.text.slice(0,60));
  await qb.click(); await p.waitForTimeout(200);
  ok('tapping again closes it',
     await p.evaluate(() => !document.querySelector('.helpwrap').classList.contains('open')));
  ok('"?" does not submit or close the dialog', await p.isVisible('#mName'));
  await p.click('[data-dlg="cancel"]'); await p.waitForTimeout(200);

  /* ---------- chips ---------- */
  await p.click('[data-tab="recipes"]'); await p.waitForTimeout(300);
  await p.click('[data-act="newRecipe"]'); await p.waitForTimeout(300);
  ok('recipe category is chips, not an empty box', await p.isVisible('[data-chipwrap] .chip'));
  await p.click('.chip[data-val="Metal"]'); await p.waitForTimeout(150);
  ok('tapping a chip stores its value',
     await p.evaluate(() => document.querySelector('#rnCat').value) === 'Metal');
  await p.click('.chip[data-val="Bone"]'); await p.waitForTimeout(150);
  ok('picking another replaces it (single choice)',
     await p.evaluate(() => document.querySelector('#rnCat').value) === 'Bone');
  ok('only one chip is pressed',
     await p.evaluate(() => document.querySelectorAll('[data-chipwrap] .chip[aria-pressed="true"]').length) === 1);
  await p.click('.chip[data-own="1"]'); await p.waitForTimeout(200);
  ok('"Type my own" shows its box', await p.isVisible('.chipown'));
  await p.fill('.chipown', 'Rust');
  await p.waitForTimeout(150);
  ok('typing writes through to the stored value',
     await p.evaluate(() => document.querySelector('#rnCat').value) === 'Rust');
  await p.fill('#rnTitle', 'Test Recipe');
  await p.click('[data-dlg="ok"]'); await p.waitForTimeout(400);
  ok('recipe saves with the typed category',
     await p.evaluate(() => (data.recipes[data.recipes.length-1]||{}).category) === 'Rust');

  /* ---------- regression: the chips I nearly broke ---------- */
  await p.evaluate(() => {
    data.paints.push({ id:'tp1', name:'Test Paint', brand:'Citadel', range:'Base',
      code:'', hex:'#884422', type:'Base', stock:'Have it', notes:'', created:Date.now() });
    save(); state.tab='paints'; render();
  });
  await p.waitForTimeout(400);
  await p.click('[data-act="openPaintFilter"]'); await p.waitForTimeout(300);
  const filterChip = await p.$('#dlg [data-fstock="Have it"]');
  ok('paint stock filter chips still exist', !!filterChip);
  if (filterChip){
    await filterChip.click(); await p.waitForTimeout(300);
    ok('stock filter chip still works (not swallowed by the new handler)',
       await p.evaluate(() => state.pStock) === 'Have it');
    ok('the panel updates in place and the list behind follows',
       await p.evaluate(() => $('#dlg').open && /Show \d+ paint/.test($('#dlg [data-dlg="ok"]').textContent)));
  }
  await p.evaluate(() => { if ($('#dlg').open) $('#dlg').close(); state.pStock=''; });

  /* ---------- regression: the v009 class names did not collide ----------
     Three separate bugs in this app have been a new class name quietly taking
     over an older one (.lab, .chip, .srow/.bar). The old stepper and its .lab
     caption are gone, so this now guards the names that replaced them. */
  await p.evaluate(() => { state.tab='coll'; state.openMini = data.minis[0].id; render(); });
  await p.waitForTimeout(400);
  const cls = await p.evaluate(() => {
    const out = {};
    const nm = document.querySelector('.stagename');
    out.stagename = nm ? parseFloat(getComputedStyle(nm).fontSize) : null;
    out.potfill = !!document.querySelector('.potfill');
    const jb = document.querySelector('[data-jump]');
    if (jb) jb.click();
    const ln = document.querySelector('.lrow .lname');
    out.lname = ln ? parseFloat(getComputedStyle(ln).fontSize) : null;
    const tg = document.querySelector('.ltag');
    out.ltagUpper = tg ? getComputedStyle(tg).textTransform : null;
    out.oldStepperGone = !document.querySelector('.stepper, .stepitem, .stagenow');
    return out;
  });
  ok('the stage name renders at display size, not caption size',
     cls.stagename >= 24, JSON.stringify(cls));
  ok('the pot level element is present', cls.potfill);
  ok('the ladder stage name is body-sized, not squashed to a caption',
     cls.lname >= 14, JSON.stringify(cls));
  ok('the ladder tag is small caps', cls.ltagUpper === 'uppercase', JSON.stringify(cls));
  ok('the old sideways stepper is gone entirely', cls.oldStepperGone);

  /* ---------- tap targets ---------- */
  const small = await p.evaluate(() => {
    const bad = [];
    document.querySelectorAll('button, select, input:not([type=hidden]), summary').forEach(el => {
      if (el.offsetParent === null) return;
      if (el.classList.contains('q')) return;   /* 28px dot, 44px ::after target */
      const r = el.getBoundingClientRect();
      if (r.height && r.height < 43.5) bad.push((el.className||el.tagName) + ' h=' + Math.round(r.height));
    });
    return bad;
  });
  ok('every visible control is at least 44px tall', small.length === 0, small.slice(0,4).join(', '));

  /* the "?" dot is small on purpose; its tap target is padded out */
  await p.evaluate(() => { state.tab='paints'; state.openPaint = 'tp1'; render(); });
  await p.waitForTimeout(400);
  const qTap = await p.evaluate(() => {
    const q = document.querySelector('.q'); if (!q) return null;
    const a = getComputedStyle(q, '::after');
    return { w: parseFloat(a.width), h: parseFloat(a.height) };
  });
  ok('the "?" dot has a 44px tap target behind it',
     qTap && qTap.w >= 44 && qTap.h >= 44, JSON.stringify(qTap));

  /* the overhang must not sit on top of the control below it */
  const stolen = await p.evaluate(() => {
    const q = document.querySelector('.q'); if (!q) return 'no ? found';
    const ctl = q.closest('.flab').nextElementSibling;
    if (!ctl) return 'no control after the label row';
    const r = ctl.getBoundingClientRect();
    const hit = document.elementFromPoint(r.left + 8, r.top + 2);
    return (hit === ctl || ctl.contains(hit)) ? '' : 'top edge taken by ' + (hit && hit.className);
  });
  ok('the "?" overhang does not steal taps from the field below', stolen === '', stolen);

  /* ---------- no sideways scroll ---------- */
  const over = await p.evaluate(() => {
    const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.closest('.stepper')) return;          /* scrolls on purpose */
      const r = el.getBoundingClientRect();
      if (r.width && r.right > vw + 1) bad.push((el.className||el.tagName) + ' r=' + Math.round(r.right));
    });
    return bad;
  });
  ok('nothing overflows sideways at 390px', over.length === 0, over.slice(0,3).join(', '));
  await p.close();

  /* ---------- 320px at 200% text ---------- */
  const p2 = await b.newPage({ viewport:{ width:320, height:640 } });
  await p2.goto(URL); await p2.waitForTimeout(2200);
  await p2.evaluate(() => { authGate = 'in';
    syncState.user = { uid:'t', displayName:'T', email:'t@e.com' };
    state.tab = 'home'; render(); });
  await p2.waitForTimeout(400);
  await p2.evaluate(() => { document.documentElement.style.fontSize = '32px'; });
  await p2.waitForTimeout(400);
  const over2 = await p2.evaluate(() => {
    const vw = document.documentElement.clientWidth, bad = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.closest('.stepper')) return;
      const r = el.getBoundingClientRect();
      if (r.width && r.right > vw + 1) bad.push((el.className||el.tagName) + ' r=' + Math.round(r.right));
    });
    return bad;
  });
  ok('reflows at 320px and 200% text', over2.length === 0, over2.slice(0,3).join(', '));

  /* ---------- labels ---------- */
  await p2.evaluate(() => { document.documentElement.style.fontSize = ''; });
  await p2.click('#actslot [data-act="addHere"], #app [data-act="addMini"]'); await p2.waitForTimeout(250);
  await p2.click('details.more > summary'); await p2.waitForTimeout(250);
  const unlabelled = await p2.evaluate(() => {
    const bad = [];
    document.querySelectorAll('#dlgBody select, #dlgBody input:not([type=hidden])').forEach(el => {
      if (el.offsetParent === null) return;
      const lab = el.id && document.querySelector(`label[for="${el.id}"]`);
      if (!lab && !el.getAttribute('aria-label') && !el.placeholder) bad.push(el.id || el.className);
    });
    return bad;
  });
  ok('every field in the add form has a label', unlabelled.length === 0, unlabelled.join(', '));
  await p2.close();

  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('\n  FAILURES:'); fail.forEach(f => console.log('    - ' + f)); process.exit(1); }
})();
