/* v009: getting started.

   The two dangerous failures here are both about WHEN it appears, not how it
   looks. Offering to set up a collection that already has three hundred
   models in it, because the sync had only half arrived, would be alarming
   and would look like data loss. And skipping must leave nothing behind. */
const { chromium } = require('playwright');
const URL = 'file://' + require('path').join(__dirname, '..', 'build', 'index.html');

let pass = 0, fail = [];
const ok = (n, c, d) => { if (c) { pass++; console.log(`  PASS  ${n}`); }
                          else { fail.push(n + (d ? ' — ' + d : '')); console.log(`  FAIL  ${n}${d ? ' — ' + d : ''}`); } };

/* Joe's real situation: signed in, two systems on the list, nothing else. */
const EMPTY = `
authGate='in'; syncState.user={uid:'t',displayName:'Joe',email:'j@e.com'};
syncState.status='ok'; syncState.firstPullDone=true;
data.systems=[{id:uid(),name:'Warhammer 40,000'},{id:uid(),name:'Warhammer: Age of Sigmar'}];
data.minis=[]; data.paints=[]; data.settings.setupDone=false;
setupChecked=false; state.setup.step=0; state.tab='home'; render();
`;

(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  await p.goto(URL); await p.waitForTimeout(2200);

  /* ---------- when it appears, and when it must not ---------- */
  await p.evaluate(EMPTY); await p.waitForTimeout(500);
  ok('it offers itself on a genuinely empty collection',
     await p.evaluate(() => state.setup.step) === 1);

  /* The one that matters: a second phone, signed in, data still arriving.
     syncStatus('ok') is set by whichever collection answers first. */
  await p.evaluate(`
    state.setup.step=0; setupChecked=false; data.settings.setupDone=false;
    data.minis=[]; data.paints=[];
    syncState.status='ok'; syncState.firstPullDone=false;   /* still pulling */
    state.tab='home'; render();`);
  await p.waitForTimeout(400);
  ok('it does NOT appear while the first sync is still arriving',
     await p.evaluate(() => state.setup.step) === 0,
     'step ' + await p.evaluate(() => state.setup.step));
  /* ...and then does, once everything has landed and it really is empty */
  await p.evaluate(`syncState.firstPullDone=true; render();`);
  await p.waitForTimeout(400);
  ok('...and does appear once the pull finishes',
     await p.evaluate(() => state.setup.step) === 1);

  await p.evaluate(`
    state.setup.step=0; setupChecked=false; data.settings.setupDone=false;
    data.minis=[{id:'x',name:'Something',stage:data.stages[0],total:1,done:0,updated:1}];
    syncState.firstPullDone=true; state.tab='home'; render();`);
  await p.waitForTimeout(400);
  ok('it does not appear for someone who already has models',
     await p.evaluate(() => state.setup.step) === 0);
  ok('and it marks itself done so it never asks them',
     await p.evaluate(() => data.settings.setupDone) === true);

  await p.evaluate(`
    state.setup.step=0; setupChecked=false; data.settings.setupDone=true;
    data.minis=[]; data.paints=[]; state.tab='home'; render();`);
  await p.waitForTimeout(400);
  ok('it does not ask again once it has been dismissed',
     await p.evaluate(() => state.setup.step) === 0);

  /* ---------- step 1 ---------- */
  await p.evaluate(EMPTY); await p.waitForTimeout(500);
  const s1 = await p.evaluate(() => ({
    chips: document.querySelectorAll('[data-setupsys]').length,
    ticked: [...document.querySelectorAll('[data-setupsys][aria-pressed="true"]')].map(e => e.textContent.trim()),
    turnip: !!document.querySelector('[data-setupsys="Turnip28"]'),
    exitTop: Math.round(document.querySelector('[data-act="setupSkip"]').getBoundingClientRect().top),
    exitTall: Math.round(document.querySelector('[data-act="setupSkip"]').getBoundingClientRect().height)
  }));
  ok('every game system is offered', s1.chips === 32, String(s1.chips));
  ok('Turnip28 is one of them', s1.turnip);
  ok('the systems you already have come pre-ticked',
     s1.ticked.length === 2 && s1.ticked.includes('Warhammer 40,000'), s1.ticked.join(','));
  ok('the way out is at the top of the screen', s1.exitTop < 844 / 3, String(s1.exitTop));
  ok('and it is a real tap target', s1.exitTall >= 44, String(s1.exitTall));

  await p.click('[data-setupsys="Turnip28"]'); await p.waitForTimeout(250);
  /* Unticking something you already own must not delete it. */
  await p.click('[data-setupsys="Warhammer 40,000"]'); await p.waitForTimeout(250);
  await p.click('[data-act="setupNext"]'); await p.waitForTimeout(500);
  const after1 = await p.evaluate(() => data.systems.map(s => s.name));
  ok('a newly ticked system is created', after1.includes('Turnip28'), after1.join(','));
  ok('unticking one you already had does NOT delete it',
     after1.includes('Warhammer 40,000'), after1.join(','));
  ok('it moves to step two', await p.evaluate(() => state.setup.step) === 2);

  /* ---------- step 2 ---------- */
  await p.selectOption('#suSys', 'Warhammer 40,000'); await p.waitForTimeout(400);
  await p.selectOption('#suFac', { label:'Death Guard' }).catch(() => {});
  await p.waitForTimeout(200);
  await p.fill('#suUnit', 'Plague Marines'); await p.fill('#suCount', '7');
  await p.press('#suUnit', 'Enter'); await p.waitForTimeout(400);
  const u1 = await p.evaluate(() => ({
    units: state.setup.units,
    cleared: document.querySelector('#suUnit').value === '',
    countReset: document.querySelector('#suCount').value === '1',
    focused: document.activeElement && document.activeElement.id,
    rows: document.querySelectorAll('.uli').length
  }));
  ok('return adds the unit', u1.units.length === 1 && u1.units[0].name === 'Plague Marines',
     JSON.stringify(u1.units));
  ok('the count is kept', u1.units[0] && u1.units[0].total === 7, JSON.stringify(u1.units));
  ok('the name field clears itself', u1.cleared);
  ok('the count resets to 1', u1.countReset);
  ok('focus stays in the name field so you can keep typing', u1.focused === 'suUnit', u1.focused);

  await p.fill('#suUnit', 'Poxwalkers'); await p.fill('#suCount', '10');
  await p.press('#suUnit', 'Enter'); await p.waitForTimeout(400);
  await p.fill('#suUnit', 'Mistake'); await p.press('#suUnit', 'Enter'); await p.waitForTimeout(400);
  ok('three units are listed',
     await p.evaluate(() => document.querySelectorAll('.uli').length) === 3);
  await p.evaluate(() => document.querySelectorAll('[data-setupdelunit]')[2].click());
  await p.waitForTimeout(400);
  const u2 = await p.evaluate(() => ({ units: state.setup.units.map(x => x.name),
                                       fac: state.setup.facName }));
  ok('removing one takes the right one out',
     u2.units.join(',') === 'Plague Marines,Poxwalkers', u2.units.join(','));
  ok('the chosen army survives a re-render', u2.fac === 'Death Guard', u2.fac);

  /* half-typed unit must not be silently dropped on Next */
  await p.fill('#suUnit', 'Blightlords'); await p.fill('#suCount', '5');
  await p.click('[data-act="setupNext"]'); await p.waitForTimeout(600);
  ok('a unit still in the box is picked up by Next',
     await p.evaluate(() => state.setup.units.length) === 3,
     String(await p.evaluate(() => state.setup.units.length)));
  ok('it moves to step three', await p.evaluate(() => state.setup.step) === 3);

  /* ---------- step 3 ---------- */
  const s3 = await p.evaluate(() => ({
    brand: document.querySelector('#suBrand').value,
    range: document.querySelector('#suRange').value,
    rows: document.querySelectorAll('.prow').length,
    disabled: document.querySelector('[data-act="setupFinish"]').disabled,
    tapTargets: Math.min(...[...document.querySelectorAll('.prow')]
      .slice(0,20).map(r => Math.round(r.getBoundingClientRect().height)))
  }));
  /* Catalogue order would land on Citadel Technical, which is nobody's
     starting point. */
  ok('the default brand is a sensible guess, not whatever starts with A',
     s3.brand === 'Citadel', s3.brand);
  ok('the default range is the big one, not whatever is first in the file',
     s3.range === 'Layer', s3.range);
  ok('the range is listed', s3.rows > 20, String(s3.rows));
  ok('every paint row is a real tap target', s3.tapTargets >= 44, String(s3.tapTargets));
  ok('you cannot finish having ticked nothing', s3.disabled === true);

  await p.evaluate(() => [...document.querySelectorAll('.prow')].slice(0,4).forEach(r => r.click()));
  await p.waitForTimeout(350);
  const t3 = await p.evaluate(() => ({
    pressed: document.querySelectorAll('.prow[aria-pressed="true"]').length,
    count: document.querySelector('.pcount').textContent.replace(/\s+/g,' ').trim(),
    disabled: document.querySelector('[data-act="setupFinish"]').disabled,
    label: document.querySelector('[data-act="setupFinish"]').textContent.trim()
  }));
  ok('ticking marks the row', t3.pressed === 4, String(t3.pressed));
  ok('the running count updates', /^4 ticked/.test(t3.count), t3.count);
  ok('the finish button wakes up', t3.disabled === false);
  ok('and says how many', /all 4/.test(t3.label), t3.label);
  /* Ticking must not rebuild the list: you would lose your place halfway
     down a rack of ninety pots. */
  const scrolled = await p.evaluate(async () => {
    window.scrollTo(0, 600); await new Promise(r => setTimeout(r, 120));
    const before = window.scrollY;
    document.querySelectorAll('.prow')[8].click();
    await new Promise(r => setTimeout(r, 250));
    return { before, after: window.scrollY };
  });
  ok('ticking does not throw away your scroll position',
     Math.abs(scrolled.after - scrolled.before) < 20, JSON.stringify(scrolled));
  await p.evaluate(() => document.querySelectorAll('.prow')[8].click());
  await p.waitForTimeout(200);

  /* search across everything */
  await p.fill('#suPq', 'mephiston'); await p.waitForTimeout(600);
  const search = await p.evaluate(() => ({
    rows: document.querySelectorAll('.prow').length,
    first: document.querySelector('.pnm') ? document.querySelector('.pnm').textContent : '',
    stillTicked: document.querySelectorAll('.prow[aria-pressed="true"]').length
  }));
  ok('search finds a paint by name', /Mephiston/i.test(search.first), search.first.slice(0,40));
  ok('what you already ticked is remembered across a search',
     await p.evaluate(() => Object.keys(state.setup.picked).filter(k => state.setup.picked[k]).length) === 4);
  await p.click('[data-act="setupClearQ"]'); await p.waitForTimeout(500);

  /* ---------- finishing ---------- */
  await p.click('[data-act="setupFinish"]'); await p.waitForTimeout(700);
  const done = await p.evaluate(() => ({
    step: state.setup.step,
    minis: data.minis.length,
    models: data.minis.reduce((n,m) => n + (Number(m.total)||1), 0),
    paints: data.paints.length,
    armies: data.factions.map(f => f.name),
    sys: data.minis[0] ? sysName(data.minis[0].sys) : '',
    stage: data.minis[0] ? data.minis[0].stage : '',
    setupDone: data.settings.setupDone,
    hero: document.querySelector('.hero b').textContent
  }));
  ok('the entries are created', done.minis === 3, String(done.minis));
  ok('the counts are carried through', done.models === 22, String(done.models));
  ok('the paints are added', done.paints === 4, String(done.paints));
  ok('the army is created', done.armies.includes('Death Guard'), done.armies.join(','));
  ok('the models are filed under the right system', done.sys === 'Warhammer 40,000', done.sys);
  ok('new models start at the first stage', done.stage === data0(), done.stage);
  function data0(){ return 'Unbuilt'; }
  ok('setup is marked done', done.setupDone === true);
  ok('it finishes by showing the real collection', done.hero === '0', done.hero);

  await p.click('[data-act="setupGo"]'); await p.waitForTimeout(500);
  const out = await p.evaluate(() => ({ step: state.setup.step, tab: state.tab,
                                        tiles: document.querySelectorAll('#app .tile, #app .mrow').length, army: !!state.openArmy }));
  ok('it lands you in your collection', out.tab === 'coll' && out.step === 0, JSON.stringify(out));
  ok('...inside the army it just made, with the models in it', out.army && out.tiles === 3, JSON.stringify(out));

  /* ---------- running it again must not duplicate ---------- */
  await p.evaluate(() => { startSetup('paints'); });
  await p.waitForTimeout(600);
  const again = await p.evaluate(() => ({
    step: state.setup.step, only: state.setup.only,
    heading: document.querySelector('.ehead h3').textContent,
    exit: !!document.querySelector('[data-act="setupSkip"]'),
    noSteps: !document.querySelector('.stepcap')
  }));
  ok('the paint picker opens on its own', again.step === 3 && again.only === 'paints');
  ok('it drops the step counter when used alone', again.noSteps);
  ok('it still has a way out', again.exit);
  ok('its heading says what it is', /Add several/.test(again.heading), again.heading);

  const before = await p.evaluate(() => data.paints.length);
  await p.evaluate(() => [...document.querySelectorAll('.prow')].slice(0,6).forEach(r => r.click()));
  await p.waitForTimeout(300);
  await p.click('[data-act="setupFinish"]'); await p.waitForTimeout(700);
  const dup = await p.evaluate(() => ({
    paints: data.paints.length,
    names: data.paints.map(x => x.brand + '|' + x.range + '|' + x.name),
    tab: state.tab
  }));
  ok('a pot you already own is not added twice',
     dup.names.length === new Set(dup.names).size,
     `${dup.names.length} rows, ${new Set(dup.names).size} unique`);
  ok('only the new ones went in', dup.paints === before + 2,
     `${before} -> ${dup.paints}`);
  ok('it returns you to Paints', dup.tab === 'paints', dup.tab);

  /* ---------- skipping leaves nothing behind ---------- */
  await p.evaluate(EMPTY); await p.waitForTimeout(500);
  const sysBefore = await p.evaluate(() => data.systems.length);
  await p.click('[data-act="setupNext"]'); await p.waitForTimeout(400);
  await p.fill('#suUnit', 'Never saved'); await p.waitForTimeout(150);
  await p.click('[data-act="setupSkip"]'); await p.waitForTimeout(500);
  const skipped = await p.evaluate(() => ({
    step: state.setup.step, minis: data.minis.length,
    systems: data.systems.length, units: state.setup.units.length,
    setupDone: data.settings.setupDone
  }));
  ok('skipping closes the flow', skipped.step === 0);
  ok('skipping saves no half-typed model', skipped.minis === 0, String(skipped.minis));
  ok('skipping leaves no leftover state', skipped.units === 0);
  ok('skipping does not invent game systems', skipped.systems === sysBefore,
     `${sysBefore} -> ${skipped.systems}`);
  ok('skipping counts as dismissing it', skipped.setupDone === true);

  /* ---------- a way out of every setup screen ---------- */
  for (const [label, js] of [
      ['step one',   `startSetup();`],
      ['step two',   `startSetup(); state.setup.step=2; render();`],
      ['step three', `startSetup(); state.setup.step=3; render();`],
      ['the finish', `startSetup(); state.setup.step=4; render();`],
      ['the paint picker alone', `startSetup('paints');`]]){
    await p.evaluate(js); await p.waitForTimeout(350);
    const esc = await p.evaluate(() => {
      const out = [...document.querySelectorAll(
        '[data-act="setupSkip"],[data-act="setupGo"],[data-act="setupSkipStep"]')]
        .filter(e => e.getBoundingClientRect().height > 0);
      const top = out.filter(e => e.getBoundingClientRect().top < window.innerHeight / 3);
      return { any: out.length, atTop: top.length,
               tall: out[0] ? Math.round(out[0].getBoundingClientRect().height) : 0 };
    });
    ok(`${label} has a way out`, esc.any > 0, JSON.stringify(esc));
    ok(`  ...near the top of the screen`, esc.atTop > 0, JSON.stringify(esc));
    ok(`  ...at a real tap target size`, esc.tall >= 44, String(esc.tall));
  }

  /* ---------- layout ---------- */
  for (const [label, js] of [['step one', `startSetup();`],
                             ['step three', `startSetup(); state.setup.step=3; render();`]]){
    await p.evaluate(js); await p.waitForTimeout(400);
    const r = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth,
                                        cw: document.documentElement.clientWidth }));
    ok(`${label} does not scroll sideways at 390px`, r.sw <= r.cw, `${r.sw} vs ${r.cw}`);
  }
  await p.close();

  const p2 = await b.newPage({ viewport:{ width:320, height:640 } });
  await p2.goto(URL); await p2.waitForTimeout(2000);
  await p2.evaluate(EMPTY);
  await p2.evaluate(() => { document.documentElement.style.fontSize = '32px';
                            startSetup(); state.setup.step = 3; render(); });
  await p2.waitForTimeout(500);
  const r2 = await p2.evaluate(() => ({ sw: document.documentElement.scrollWidth,
                                        cw: document.documentElement.clientWidth }));
  ok('the paint picker reflows at 320px and 200% text', r2.sw <= r2.cw, `${r2.sw} vs ${r2.cw}`);
  await p2.close();

  /* ---------------------------------------------------------------------
     Every DIALOG must have a way out too, visible without scrolling.

     This was missed first time round: the screen audit walked screens and
     never opened a dialog. The "More" menu ends with the full MIT licence
     and the trademark notice, so its only way out sat below a wall of legal
     text — you had to scroll to leave, which is exactly getting lost.
  --------------------------------------------------------------------- */
  const p3 = await b.newPage({ viewport:{ width:390, height:844 } });
  const errs3 = []; p3.on('pageerror', e => errs3.push(e.message));
  await p3.goto(URL); await p3.waitForTimeout(2200);
  await p3.evaluate(EMPTY);
  await p3.evaluate(`state.setup.step=0; data.settings.setupDone=true;
    data.minis=[{id:'m1',name:'A',stage:data.stages[0],total:1,done:0,updated:1}];
    data.paints=[{id:'q1',name:'P',brand:'Citadel',range:'Base',hex:'#777',stock:'Have it',updated:1}];
    data.recipes=[{id:'r1',title:'R',steps:[],updated:1}];
    state.tab='home'; render();`);
  await p3.waitForTimeout(400);

  const DIALOGS = [
    ['the More menu',        `document.getElementById('moreBtn').click();`],
    ['add a miniature',      `dlgAddMini();`],
    ['add a game system',    `dlgAddSystem();`],
    ['add a paint',          `dlgAddPaint();`],
    ['add a supply',         `dlgAddSupply();`],
    ['add to the wishlist',  `dlgAddWish();`],
    ['new recipe',           `dlgNewRecipe();`],
    ['delete your account',  `dlgDeleteAccount();`]
  ];
  for (const [label, js] of DIALOGS){
    await p3.evaluate(`try{ document.getElementById('dlg').close(); }catch(e){}`);
    await p3.evaluate(js);
    await p3.waitForTimeout(350);
    const esc = await p3.evaluate(() => {
      const dlg = document.getElementById('dlg');
      if (!dlg || !dlg.open) return { open:false };
      const body = dlg.querySelector('.dlgbody');
      const head = dlg.querySelector('.dlghead');
      const x = head && head.querySelector('[data-dlg="cancel"]');
      const r = x ? x.getBoundingClientRect() : null;
      const dr = dlg.getBoundingClientRect();
      return {
        open: true,
        hasHeadClose: !!x,
        /* visible without scrolling the dialog body at all */
        visibleAtRest: !!r && r.top >= dr.top - 1 && r.bottom <= dr.bottom + 1 && r.height > 0,
        tall: r ? Math.round(r.height) : 0,
        wide: r ? Math.round(r.width) : 0,
        sticky: head ? getComputedStyle(head).position : null,
        scrolls: body ? body.scrollHeight > body.clientHeight + 1 : false
      };
    });
    ok(`${label} opens`, esc.open === true);
    ok(`${label} has a close in its header`, esc.hasHeadClose === true, JSON.stringify(esc));
    ok(`${label}: the close is visible without scrolling`, esc.visibleAtRest === true, JSON.stringify(esc));
    ok(`${label}: the close is a 44px target`,
       esc.tall >= 44 && esc.wide >= 44, `${esc.tall}x${esc.wide}`);
    ok(`${label}: its header stays pinned while the body scrolls`,
       esc.sticky === 'sticky', String(esc.sticky));
  }

  /* the long one, specifically: scroll to the very bottom and the close is
     STILL there, which is the whole point of pinning it */
  await p3.evaluate(`try{ document.getElementById('dlg').close(); }catch(e){}
    document.getElementById('moreBtn').click();`);
  await p3.waitForTimeout(400);
  const longOne = await p3.evaluate(async () => {
    const dlg = document.getElementById('dlg');
    const body = dlg.querySelector('.dlgbody');
    const wasScrollable = body.scrollHeight > body.clientHeight + 1;
    body.scrollTop = body.scrollHeight;
    await new Promise(r => setTimeout(r, 200));
    const x = dlg.querySelector('.dlghead [data-dlg="cancel"]');
    const r = x.getBoundingClientRect(), dr = dlg.getBoundingClientRect();
    return { wasScrollable, stillVisible: r.top >= dr.top - 1 && r.bottom <= dr.bottom + 1,
             okButtons: dlg.querySelectorAll('[data-dlg="ok"]').length,
             footLabel: (dlg.querySelector('.row [data-dlg="cancel"]')||{}).textContent };
  });
  ok('the More menu really is long enough to scroll', longOne.wasScrollable);
  ok('its close is STILL visible at the very bottom', longOne.stillVisible === true,
     JSON.stringify(longOne));
  ok('a menu offers no Save button', longOne.okButtons === 0, String(longOne.okButtons));
  ok('and its foot button says Close, not Cancel',
     (longOne.footLabel || '').trim() === 'Close', longOne.footLabel);

  /* the close must actually close */
  await p3.evaluate(() => document.querySelector('.dlghead [data-dlg="cancel"]').click());
  await p3.waitForTimeout(300);
  ok('tapping the header close shuts the dialog',
     await p3.evaluate(() => !document.getElementById('dlg').open));

  ok('no errors while walking every dialog', errs3.length === 0, errs3.slice(0,2).join(' | '));
  await p3.close();

  ok('no uncaught errors anywhere in this run', errs.length === 0, errs.slice(0,2).join(' | '));

  await b.close();
  console.log(`\n  ${pass} passed, ${fail.length} failed`);
  if (fail.length){ console.log('\n  FAILURES:'); fail.forEach(f => console.log('    - ' + f)); process.exit(1); }
})();
